<?php 
/*
LAST UPDATED: 27th March 2011
EDITED BY: MARK FAIL
*/ 

get_header();
?>
<div style="width: 100%; float: left; border: 0px solid #000000;">
    <?php echo right_sidebar_custom(); ?>
    <div style="width: 78%; float: left;">
	<div id="middle_content" style="width: 99%; float: left; padding:10px;">
	    <div style="width:100%; float:left;">
	    <?php
		$postslist = query_posts('meta_key=featured&posts_per_page=12');
		foreach ( $postslist as $post ) {
		    
	    ?>
		<div style="width:25%; float: left; height: 236px; font-size:13px;">
			    <div style="padding: 5px;">
				<div style="border: 7px solid #F0F0F0; padding: 8px;">
				    <a href="<?php echo get_permalink($post->ID); ?>" title="<?php echo $post->post_title; ?>">
					    <img src="<?php echo $PPT->Image($post,"m"); ?>&amp;w=155&amp;h=125" width="155" height="125" style="cursor:pointer;" alt="<?php echo $post->post_title ?>" />
				    </a>    
				</div>
				<div style=" padding-left: 15px; padding-top:5px;">
					    <?php echo $post->post_title ?>
				</div>
				<div style=" padding-left: 15px; padding-top:2px;">
					    <em class="price"><?php echo $PPT->Price(get_post_meta($post->ID, "price", true),$GLOBALS['premiumpress']['currency_symbol'],$GLOBALS['premiumpress']['currency_position'],1); ?></em>   
				</div>
			    </div>
			</div>
		<?php } ?>
		</div>
		
	    </div>
	</div>
    </div>
   

<?php get_footer(); ?>