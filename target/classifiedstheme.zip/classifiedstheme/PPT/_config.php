<?php

	// DEFAULT SYSTEM GLOBALS
	$GLOBALS['bloginfo_url'] = get_bloginfo('url');
	$GLOBALS['template_url'] = get_bloginfo('template_url');

 	// DEFINE PATHS
	$functions_path = TEMPLATEPATH . '/functions/';
	define('PPT_PATH',get_bloginfo ( 'template_url' ).'/PPT/');
	define('IMAGE_PATH',get_bloginfo ( 'template_url' )."/template_".strtolower(constant('PREMIUMPRESS_SYSTEM'))."/images/");
	define("THEME_PATH","".$functions_path."");		
	
	// CORE THEME CLASS FILES
	require_once (TEMPLATEPATH ."/PPT/class/class_design.php");
	require_once (TEMPLATEPATH ."/PPT/class/class_function.php");
	require_once (TEMPLATEPATH ."/PPT/class/class_member.php");
	require_once (TEMPLATEPATH ."/PPT/class/class_premiumpress.php");
	require_once (TEMPLATEPATH ."/PPT/class/class_import.php");
		
	$PPT 			= new PremiumPressTheme;
	$PPTFunction 	= new PremiumPressTheme_Function; 	
	$PPTDesign 		= new PremiumPressTheme_Design;	
	$PPTImport 		= new PremiumPressTheme_Import;	
	
	// ALLOW CUSTOM MENUS
	add_theme_support('nav_menus');
	register_nav_menu('PPT-CUSTOM-MENU-PAGES', 'Main Navigation Bar');

	// ALLOW CUSTOM BACKGROUNDS
	add_custom_background();		
 
	// SERACH PLUGIN
	require_once (TEMPLATEPATH ."/PPT/class/class_search.php");	
	add_action('init',array('PPT_S','init'));
	add_shortcode( 'premiumpress_search', array(&$this,'process_shortcode') );
		
	// CUSTOM THEME OPTIONS 
	require_once (TEMPLATEPATH ."/template_".strtolower(constant('PREMIUMPRESS_SYSTEM'))."/system_customlogins.php");	
	require_once (TEMPLATEPATH ."/template_".strtolower(constant('PREMIUMPRESS_SYSTEM'))."/system_customfields.php");
	require_once (TEMPLATEPATH ."/template_".strtolower(constant('PREMIUMPRESS_SYSTEM'))."/system_customdesign.php");
	
	$ThemeDesign 		= new Theme_Design;			
	
	// CUSTOM THEME FUNCTIONS
	require_once (TEMPLATEPATH ."/PPT/func/funcs_premiumpress.php");		

	// ADMIN AREA INCLUDES
	require_once (TEMPLATEPATH . '/admin/admin-save.php');	
	require_once (TEMPLATEPATH . '/admin/admin-styles.php');
	require_once (TEMPLATEPATH . '/admin/admin-menus.php');
		
	// CUSTOM WORDPRESS TAXOMONY
	require_once (TEMPLATEPATH ."/PPT/wordpress/_taxomony.php"); 
 
	// WORDPRESS THEME HOOKS	
	if ( function_exists('add_action') ){
	
	add_action('admin_head', 'admin_head');
	add_action('admin_menu', 'admin_menu_options'); 
	add_action('admin_menu', 'remove_the_dashboard');
	add_action('admin_menu', 'change_post_menu_label' );
	add_action( 'admin_head', 'ppt_head' );
	add_action( 'post_submitbox_misc_actions', 'ppt_metabox' );

	add_action( 'init', 'create_post_type' );	
	add_action( 'init', 'change_post_object_label' );
	
	// IMPORTANT, DO NOT REMOVE
	add_filter('posts_where',   array($PPT, 'query_where'));
	add_filter('posts_join',   array($PPT, 'query_join') );
	add_filter('posts_orderby', array($PPT, 'query_orderby') );
	add_filter('post_limits', array($PPT, 'query_limits') );
	
	/* Disable the Admin Bar. */
	//add_filter( 'show_admin_bar', '__return_false' );
	
	// WORDPRESS RECOMMENDED REMOVALS
	remove_action('wp_head', 'rsd_link');
	remove_action('wp_head', 'wlwmanifest_link');
	remove_action('wp_head', 'wp_generator');
	
	// SETUP WORDPRESS SCHEDULES
	function ppt_event_activation() {
	
		if ( !wp_next_scheduled( 'ppt_hourly_event' ) ) {
			wp_schedule_event(time(), 'hourly', 'ppt_hourly_event');
		}	
		if ( !wp_next_scheduled( 'ppt_twicedaily_event' ) ) {		
			wp_schedule_event(time(), 'twicedaily', 'ppt_twicedaily_event');
		}	
		if ( !wp_next_scheduled( 'ppt_daily_event' ) ) {	
			wp_schedule_event(time(), 'daily', 'ppt_daily_event');		
		}
	}
	 
	//print date('l jS \of F Y h:i:s A',wp_next_scheduled( "ppt_hourly_event"))."<br><br>".date('l jS \of F Y h:i:s A',wp_next_scheduled( "ppt_twicedaily_event"))."<br><br>".date('l jS \of F Y h:i:s A',wp_next_scheduled( "ppt_daily_event")); 
	
	function do_this_event_hourly() { 		global $PPTImport; $PPTImport->IMPORTSWITCH('hourly');	}		
	function do_this_event_twicedaily() { 	global $PPTImport; $PPTImport->IMPORTSWITCH('twicedaily');	}
	function do_this_event_daily() { 		global $PPTImport; $PPTImport->IMPORTSWITCH('daily');	}	
					
	add_action('ppt_hourly_event', 'do_this_event_hourly');
	add_action('ppt_twicedaily_event', 'do_this_event_twicedaily');
	add_action('ppt_daily_event', 'do_this_event_daily');  
	
	}
 

	// REMOVE DASHBOARD FROM USER ACCESS	
	function remove_the_dashboard () {
		if (current_user_can('level_10')) {
			return;
		} else {
			global $menu, $submenu, $user_ID;
			$the_user = new WP_User($user_ID);
			reset($menu); $page = key($menu);
			while ((__('Dashboard') != $menu[$page][0]) && next($menu))
					$page = key($menu);
			if (__('Dashboard') == $menu[$page][0]) unset($menu[$page]);
			reset($menu); $page = key($menu);
			while (!$the_user->has_cap($menu[$page][1]) && next($menu))
					$page = key($menu);
			if (preg_match('#wp-admin/?(index.php)?$#',$_SERVER['REQUEST_URI']) && ('index.php' != $menu[$page][2]))
					wp_redirect(get_option('siteurl') . '/wp-admin/post-new.php');
		}
	}
?>