<?php

class PREMIUMPRESS_SETUP_TEST {


function test_plugin_exists($p,$exp=""){
	if(function_exists($p)){
	return array("ok"=>true,"result"=> "Installed");
	}else{
	return array("ok"=>false,"result"=> "Not Installed");
	}
}

function text_php_directives_higher($p,$exp=""){

	$reqInt = $exp;
	$curInt = ini_get($p);
	settype($reqInt, 'integer');
	settype($curInt, 'integer');
	 
	if($curInt >= $reqInt){
		return array("ok"=>true,"result"=> $curInt."M");		
	}else{
		return array("ok"=>false,"result"=> $curInt."M");
	}


}

function text_php_directives($p,$exp=""){

	$value = ini_get($p);	
	
	if($value == "" || $exp == $value){
	
	if($exp =="1"){ $value = "On"; }else{ $value = "Off";}
		return array("ok"=>true,"result"=> $value);		
	}else{
	$value ="Off";
		return array("ok"=>false,"result"=> $value);
	}


}

function test_php_version ($p,$exp=""){ 

	$bounds = $this->GetVersionBounds($exp, false);
	$CurLow = $this->CompareVersons($bounds['current'], $bounds['lower']);
	$CurHig = $this->CompareVersons($bounds['current'], $bounds['upper']);	 
	
	if ($CurLow >= 0 && $CurHig < 0){
	return array("ok"=>true,"result"=> phpversion());
	}else{	
	return array("ok"=>false,"result"=> phpversion());					
	}
}

function test_page($p,$exp=""){

	global $wpdb; 
	 
	$result = mysql_query("SELECT count(post_id) AS total FROM $wpdb->postmeta WHERE meta_value = ('".PPTCLEAN($p)."' ) LIMIT 1", $wpdb->dbh) or die(mysql_error().' on line: '.__LINE__);
	$array = mysql_fetch_assoc($result);
	if ( $array['total'] > 0){
		
		return array("ok"=>true,"result"=> "Page Created");
		
	}else{
		
		return array("ok"=>false,"result"=> "No Page Exists");
			
	}


}

function test_blank($p,$exp=""){

	global $wpdb; 
	$found = get_option($p);
	
	if($found == ""){
	return array("ok"=>false,"result"=> "Not Setup");
	}else{
	return array("ok"=>true,"result"=> "Created");
	}
	

}

function test_info($p,$exp=""){

	global $wpdb; 
	$found = get_option($p);
	return array("ok"=>true,"result"=> "");

}

function test_option($p,$exp=""){

	global $wpdb; 
	$found = get_option($p);
	//die($found ."!=". $exp);
	
	if($found == $exp){
	if($found == "1"){ $found = "On"; }
	return array("ok"=>true,"result"=> $found);
	}else{
	return array("ok"=>false,"result"=> $found);
	}

}

function test_blog_data($p,$exp=""){

global $wpdb; 

$found = get_bloginfo( $p );

	if($exp !=""){
	 
		if($found > $exp){
		
		return array("ok"=>true,"result"=> $found);
		
		}else{
		
		return array("ok"=>false,"result"=> $found);
		
		}	
	
	}else{
	
		if($found == ""){
			return array("ok"=>false,"result"=> $found);	
		}else{
			return array("ok"=>true,"result"=> $found);	
		}
	
	}
} 

function test_install_path($p,$exp=""){

	global $wpdb; 

	//die(get_bloginfo( "template_url" ). "/". " == /".strtolower(constant('PREMIUMPRESS_SYSTEM'))."/" );

	$pos = strpos(get_bloginfo( "template_url" )."/", "/".strtolower(constant('PREMIUMPRESS_SYSTEM'))."/");
	 
	if ($pos !== false) {
		return array("ok"=>true,"result"=> "ok");
	} else {
		 return array("ok"=>false,"result"=> "Incorrect");
	}

}
 
function test_is_link($p,$exp=""){

	global $wpdb; 
	 
	if($p !="" && preg_match('|^http(s)?://[a-z0-9-]+(.[a-z0-9-]+)*(:[0-9]+)?(/.*)?$|i', $p) ){
		return array("ok"=>true,"result"=>"is valid");
	}else{
		return array("ok"=>false,"result"=>"is not valid".$p);
	} 
}
 
function test_is_writable($p,$exp=""){

	global $wpdb; 
	 
	if($p !="" && is_dir($p) && is_writable($p)){
		return array("ok"=>true,"result"=>"is writable");
	}else{
		return array("ok"=>false,"result"=>"is not writable".$p);
	} 
}

















/* =========================[ VERSION AND EXTENSIONS ]========================= */
	function CheckThis($funcName,$value="",$exp){	
		//if(!function_exists($this->$funcName())){		
		//	return "no function ".$funcName;			
		//}
		 
		 if($funcName !=""){ 
		 	return $this->$funcName($value,$exp);	
		 }else{
			 return array("ok"=>false,"result"=>"missing function");
		 }
	
	}
	
function BuildTable($PPTtest){
 

$STRING = "";  $STRING1 = ""; $OUTPUT="";    $OUTPUT=""; 
 
foreach($PPTtest as $blocktest){ 

	$countErrors = 0;
	
	$TABLEid=$blocktest['tag'];


	foreach($blocktest['tests'] as $test){ $msg ="";  $rmsg=""; 
	
		$f = $this->CheckThis($test['tfunc'],$test['tvalue'], $test['texpected']);
	 
	
		if($f['ok']){ 
		
			if($test['tgood'] !=""){ $msg = "<div class='msg msg-ok'><p>".$test['tgood']."</p></div>"; }
			$rmsg = '<img src="'.PPT_PATH.'/img/admin/ok.png" align="absmiddle"> '.$f['result']; 	
		
		}else{  
		
			$countErrors++;
			$msg = "<div class='msg msg-error'><p>".$test['tbad']."</p></div>";
			$rmsg = '<img src="'.PPT_PATH.'/img/admin/no.png" align="absmiddle"> '.$f['result']."";
		
		}
		
		$STRING1 .= '<tr class="mainrow"><td class="titledesc">'.$test['tname'].'  </td><td class="titledesc"><em style="font-size:10px; color:#999;">Currently</em> '.$rmsg.'</td><td> '.$msg.'</td></tr>';
		 
	
	}
	

	
	if($countErrors == 0){ $errMsg = "ok"; $displ ="none"; }else{ $errMsg = "error"; $displ ="visible";  } 

	if($countErrors > 0){ $STRING1 .= '<tr class="mainrow"><td colspan=3><div class="msg msg-info" style="width:730px;"><p>'.$blocktest['notice'].'</p></div></td></tr>'; }  $countErrors = 0;
	
 
	
		
	$STRING .= '<div style="height:40px; margin-bottom:10px; background:#efefef; border:1px solid #ddd;padding:10px;">

    <div class="msg msg-'.$errMsg.'" style="float:right; width:200px;"><p>'.$errMsg.' - 
	<span id="show_'.$TABLEid.'"><a href="#" onClick="$(\'#table_'.$TABLEid.'\').show();$(\'#hide_'.$TABLEid.'\').show();$(\'#show_'.$TABLEid.'\').hide();" style="font-weight:bold; text-decoration:underline">Show Details</a></span>
	<span id="hide_'.$TABLEid.'" style="display:none;"><a href="#" onClick="$(\'#table_'.$TABLEid.'\').hide();$(\'#show_'.$TABLEid.'\').show();$(\'#hide_'.$TABLEid.'\').hide();" style="font-weight:bold; text-decoration:underline">Hide Details</a></span> </p></div> 
    
    <b style="font-size:18px;">'.$blocktest['name'].'</b> <br /> 
    
    <small style="font-size:12px;">'.$blocktest['desc'].'</small>

	</div><div class="clearfix"></div> ';	 // 
	
	
	$OUTPUT .= $STRING.'<table class="maintable" id="table_'.$TABLEid.'" style="display:'.$displ.'">'.$STRING1. '</table>';  $STRING=""; $STRING1="";

} 

 

return $OUTPUT;

}


































	/**
	 *  Is some extensions loaded or not
	 */
	function IsExtensionInstalled($moduleName)
	{
		// The faster "less-reliable" alternative which is not used because
		// a module (or extension) names could be in different casing, so
		// 'Mysql' should be approved even though only 'mysql' is loaded		
		## return extension_loaded($moduleName);

		// Set the module name to lower case and get all loaded extensions 
		$moduleName = strtolower($moduleName);
		$extensions = get_loaded_extensions();
		foreach($extensions as $ext)
		{
			if($moduleName == strtolower($ext))
				return true;
		}

		return false;
	}

	/**
	 *  Convert version string to parts array
	 */
	function VersionStringToArray($anyVersion, $paddedValue='x')
	{
		$anyVersion = str_replace('x', $paddedValue, $anyVersion);
		$parts = explode('.', $anyVersion);
		while(count($parts) < 3)
			$parts[] = $paddedValue;
		return $parts;
	}

	/**
	 *  Get version bounds from two version strings, that can be on the
	 *  format '5', '5.2', '5.x.x' even be 'false'
	 */
	function GetVersionBounds($minimumVersion, $maximumVersion)
	{
		$current = $this->VersionStringToArray(phpversion()); # PHP ALWAYS HAS FULL VERSION STRING!!
		$minimum = $this->VersionStringToArray($minimumVersion, '0');

		// Any higher version is accepted!
		if($maximumVersion === false)
		{
			return array(
				'current' => $current,
				'lower' => $minimum,
				'upper' => $this->VersionStringToArray('99.99.99'));
		}

		// If max version is defined - check within range
		else if($maximumVersion !== false)
		{
			return array(
				'current' => $current,
				'lower' => $minimum,
				'upper' => $this->VersionStringToArray($maximumVersion, '99'));
		}

		// Only validate the defined minimum version string (which can NEVER
		// occur because the first if catches FALSE, and the other if catches
		// ANY other state - so this is kept here for future versions if needed
		else 
		{
			// Create upper bounds from the required version, such that
			// any undefined values will be maximum
			return array(
				'current' => $current,
				'lower' => $minimum,
				'upper' => $this->VersionStringToArray($minversion, '99'));
		}
	}

	/**
	 *  Check if version is within bounds of lower and upper, in mathematical
	 *  sens it would be:  $lowerBound <= $currentVersion < $upperBound
	 */
	function VersionInBounds($currentVersion, $lowerBound, $upperBound)
	{
		$CurLow = $this->CompareVersons($currentVersion, $lowerBound);
		$CurHig = $this->CompareVersons($currentVersion, $upperBound);

		// If current version is equal or higher than lower bound
		// and is below the upper bound - then accepted!
		if ($CurLow >= 0 && $CurHig < 0)
			 return true;
		else return false;
	}
	
	/** 
	 *  Compare two versions and get which is higher
	 *  returns are:  A<B : -1, A=B : 0, A>B : 1
	 */
	function CompareVersons($versionA, $versionB)
	{
		if($versionA[0] < $versionB[0]) 
			return -1;
		else if($versionA[0] == $versionB[0])
		{
			if($versionA[1] < $versionB[1]) 
				return -1;
			else if($versionA[1] == $versionB[1])
			{
				if($versionA[2] < $versionB[2]) 
					return -1;
				else if($versionA[2] == $versionB[2])
					return 0;
				else if($versionA[2] > $versionB[2])
					return 1;
			}
			else if($versionA[1] > $versionB[1])
				return 1;
		}
		else if($versionA[0] > $versionB[0])
			return 1;
	}



}

?>