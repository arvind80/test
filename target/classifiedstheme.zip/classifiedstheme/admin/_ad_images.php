<?php 
if (!defined('PREMIUMPRESS_SYSTEM')) {	header('HTTP/1.0 403 Forbidden'); exit; } 


// IMAGE UPLOAD
if(isset($_FILES['ufile'])){ 
	if(strlen($_FILES['ufile']['tmp_name'][0]) > 5){ 
	copy($_FILES['ufile']['tmp_name'][0], get_option("imagestorage_path").str_replace(" ","",$_FILES['ufile']['name'][0]));
	}
	if(strlen($_FILES['ufile']['tmp_name'][1]) > 5){ 
	copy($_FILES['ufile']['tmp_name'][1], get_option("imagestorage_path").str_replace(" ","",$_FILES['ufile']['name'][1]));
	}
	if(strlen($_FILES['ufile']['tmp_name'][2]) > 5){ 
	copy($_FILES['ufile']['tmp_name'][2], get_option("imagestorage_path").str_replace(" ","",$_FILES['ufile']['name'][2]));
	}
$GLOBALS['error'] 		= 1;
$GLOBALS['error_type'] 	= "ok"; //ok,warn,error,info
$GLOBALS['error_msg'] 	= "Image Saved Successfully";
}

if(strlen(get_option("imagestorage_path")) < 5 || !is_writable(get_option("imagestorage_path")) ){

?>
	<div class="wrap">
	<h1> Image Configuration Incorrect </h1>
	<p> Your image configuration settings are correct and your image path is not correct and/or not CHMOD 777</p>
	<p><a href="admin.php?page=setup">Please click here to adjust the settings under Image Configuration.</a></p>
	</div>
<?php

}elseif( isset($_GET['tab']) && $_GET['tab'] == "nw" ) {

if(isset($GLOBALS['error_msg']) && strlen($GLOBALS['error_msg']) > 4){ print "<p style='background:green; color:white; padding:5px;'>".$GLOBALS['error_msg']."</p>"; }

?>
<style>
#adminmenu,#wphead,#footer,.update-nag { display:none;}
 #wpbody { margin-left:0px; }
</style>
<form action="" method="post" enctype="multipart/form-data" name="form1" id="form1">
<input type="hidden" name"upload" value="1">
<td>
<table width="250px" border="0" cellpadding="3" cellspacing="1" bgcolor="#FFFFFF">
 
<tr>
<td>Select file
<input name="ufile[]" type="file" id="ufile[]" size="50" style="width:200px;" /></td>
</tr>
<tr>
<td>Select file
<input name="ufile[]" type="file" id="ufile[]" size="50" style="width:200px;" /></td>
</tr>
<tr>
<td>Select file
<input name="ufile[]" type="file" id="ufile[]" size="50" style="width:200px;" /></td>
</tr>
<tr>
<td align="center"><input type="submit" class="premiumpress_button" name="Submit" value="Save Images" style="color:#fff;" /></td>
</tr>
</table>
</td>
</form>
<?php 

}else{

$GLOBALS['image_http'] = get_option("imagestorage_link");

// IMAGE DELETION
if(isset($_GET['del'])){
unlink(get_option("imagestorage_path").$_GET['del']);
$GLOBALS['error'] 		= 1;
$GLOBALS['error_type'] 	= "ok"; //ok,warn,error,info
$GLOBALS['error_msg'] 	= "Image Deleted Successfully";
}


$d = dir(get_option("imagestorage_path"));
while (false !== ($entry = $d->read())) {
 
	if (preg_match("/(\.gif$)/i", strtolower($entry)) || preg_match("/(\.jpg$)/i", strtolower($entry)) || preg_match("/(\.jpeg$)/i", strtolower($entry)) || preg_match("/(\.png$)/i", strtolower($entry))){
	
		if(isset($_GET['search'])){
		
		$pos = strpos($entry, $_GET['search']); 
		if ($pos === false) {}else{$pics[] = $entry;}
		
		}else{
			$pics[] = $entry;
		}
	}
}

$d->close();
$checkbox=1;
$numPerRow = 25;
$numPics = count($pics);
if(!isset($_GET['p'])){ $c_page = 0; }else { $c_page = $_GET['p']*$numPerRow; } 
$dd = ceil($numPics/$numPerRow);

PremiumPress_Header();  ?>

        <script type="text/javascript" src="<?php echo $GLOBALS['template_url']; ?>/admin/crop/_js/utilities.js"></script>
		<script language="javascript" type="text/javascript">
			
			function launchCropper(image){
				var srcFile = '<?php echo str_replace("http://","",get_option("imagestorage_link")); ?>'+image;
				var startWidth = findDOM('startWidth').value;
				var startHeight = findDOM('startHeight').value;			
				var minWidth = findDOM('minWidth').value;
				var minHeight = findDOM('minHeight').value;
				var maxWidth = findDOM('maxWidth').value;
				var maxHeight = findDOM('maxHeight').value;
				var resizeWidth = findDOM('resizeWidth').checked;
				var resizeHeight = findDOM('resizeHeight').checked;
				var imageQuality = findDOM('imageQuality').value;
				var forceAspect = findDOM('forceAspect').checked;
				var fullScreen = findDOM('fullScreen').checked;
				var saveAsLocal = findDOM('saveAsLocal').checked;
				var processInBackground = findDOM('processInBackground').checked;
				
				if(fullScreen == true){
					cropWindow = window.open('<?php echo $GLOBALS['template_url']; ?>/admin/crop/crop.php?imageSrc='+srcFile+'&startWidth='+startWidth+'&startHeight='+startHeight+'&minWidth='+minWidth+'&minHeight='+minHeight+'&maxWidth='+maxWidth+'&maxHeight='+maxHeight+'&resizeWidth='+resizeWidth+'&resizeHeight='+resizeHeight+'&forceAspect='+forceAspect+'&imageQuality='+imageQuality+'&saveAsLocal='+saveAsLocal+'&processInBackground='+processInBackground,'cropwindow','fullscreen=yes');
				}
				else{
					cropWindow = window.open('<?php echo $GLOBALS['template_url']; ?>/admin/crop/crop.php?imageSrc='+srcFile+'&startWidth='+startWidth+'&startHeight='+startHeight+'&minWidth='+minWidth+'&minHeight='+minHeight+'&maxWidth='+maxWidth+'&maxHeight='+maxHeight+'&resizeWidth='+resizeWidth+'&resizeHeight='+resizeHeight+'&forceAspect='+forceAspect+'&imageQuality='+imageQuality+'&saveAsLocal='+saveAsLocal+'&processInBackground='+processInBackground,'cropwindow','toolbar=0,location=0, directories=0, status=0, menubar=0,scrollbars=0, resizable=1,left=500,top=250,width=750,height=600');
				}
			}	
		</script>

<input type="hidden" id="startWidth" value="400"/>
<input type="hidden" id="startHeight" value="300"/>
<input type="hidden" id="minWidth" value="0"/>
<input type="hidden" id="minHeight" value="0"/>
<input type="hidden" id="maxWidth" value="5000" />
<input type="hidden" id="maxHeight" value="5000"/>
<input type="hidden" id="imageQuality" value="100" />
<input type="hidden" id="saveAsLocal" />
<input type="hidden" id="resizeWidth" checked="checked"/>
<input type="hidden" id="resizeHeight" checked="checked"/>
<input type="hidden" id="forceAspect" />
<input type="hidden" id="fullScreen" />
<input type="hidden" id="processInBackground" />

<div id="premiumpress_box1" class="premiumpress_box premiumpress_box-100"><div class="premiumpress_boxin"><div class="header">
<h3><img src="<?php echo $GLOBALS['template_url']; ?>/images/premiumpress/h-ico/picture.png" align="absmiddle"> Image Manager</h3>							 
<ul>
	<li><a rel="premiumpress_tab1" href="#" class="active">Images</a></li>
	<li><a rel="premiumpress_tab2" href="#">Upload Images</a></li>
 
</ul>
</div>

<form method="get" name="SearchForm" action="admin.php" style="padding:5px;">
<input type="hidden" name="page" value="images" />
<input type="hidden" name="p" value="0" />
<input name="search" type="text" style="font-size:18px; width:200px; background:#efefef" id="search">
<input name="" type="submit" style="font-size:18px; background:#a70303; color:white;padding:5px;" value="Search">

</form>

<form class="plain" method="post" name="orderform" id="orderform">
<input type="hidden" name="deleteimages" value="1">
<div id="premiumpress_tab1" class="content">

	<?php 
	$thispic=-1;
	for ($i=0; $i < $numPics; $i++){ 
	if($i > $c_page-1 && $i < $c_page+$numPerRow ){
	$currThumb = $thispic + $i + 1; if(strlen($pics[$currThumb]) > 1){ ?>
	<div style="float:left; width:150px; margin:4px; margin-top:0px;border:1px solid #dddddd; background:#fff; padding:5px;">
	<div style="height:110px; overflow:hidden;">
	<a href="<?php echo $GLOBALS['image_http'].$pics[$currThumb] ?>" rel="image_group">
	<img src="<?php echo $GLOBALS['image_http'].$pics[$currThumb] ?>" style="max-width:150px;" border="0" />
	</a>
	</div>
	<div style="background:#efefef; border:1px solid #ddd; padding:5px; margin-top:8px;"> 
	<input type="checkbox" value="on" name="d<?php echo $checkbox; ?>" id="d<?php echo $checkbox; ?>"/>
	<input type="hidden" name="d<?php echo $checkbox; ?>-id" value="<?php echo $pics[$currThumb]; ?>">
	  <a href="admin.php?page=images&del=<?php echo $pics[$currThumb] ?>"><img src="<?php echo $GLOBALS['template_url']; ?>/images/premiumpress/led-ico/cross.png" align="absmiddle"> Delete</a> <a href="javascript:void(0);" onclick="launchCropper('<?php echo $pics[$currThumb]; ?>');return false";><img src="<?php echo $GLOBALS['template_url']; ?>/images/premiumpress/led-ico/pencil.png" align="absmiddle"> Edit</a> </div>
	<small><b><?php echo $pics[$currThumb] ?></b></small>
	</div>
	<?php $checkbox++; } } } ?>


<div class="clearfix"></div>

<div class="pagination">
<ul>
<li><b>Showing Page <?php echo $_GET['p']+1; ?> of <?php if($dd ==0){ echo "1"; }else{ echo $dd; }; ?></b></li>

<?php
$pc = $dd;
if($dd > 1){
while($pc > 0){
$pnum = $pc; 
?>
<li><a href="admin.php?page=images&p=<?php echo $pnum-1; ?>"><?php echo $pc; ?></a></li>
<?php $pc--; } } ?>
</ul>
</div>
<label>with selected image do:
<select name="data-1-groupaction"><option value="bigdelete">delete</option></select></label>
<input class="button altbutton" type="submit" value="OK" style="color:white;" />
</form>
</div>








<div id="premiumpress_tab2" class="content">
<table width="500" border="0" align="center" cellpadding="0" cellspacing="1" bgcolor="#CCCCCC">
<tr>
<form action="" method="post" enctype="multipart/form-data" name="form1" id="form1">
<input type="hidden" name"upload" value="1">
<td>
<table width="100%" border="0" cellpadding="3" cellspacing="1" bgcolor="#FFFFFF">
 
<tr>
<td>Select file
<input name="ufile[]" type="file" id="ufile[]" size="50" /></td>
</tr>
<tr>
<td>Select file
<input name="ufile[]" type="file" id="ufile[]" size="50" /></td>
</tr>
<tr>
<td>Select file
<input name="ufile[]" type="file" id="ufile[]" size="50" /></td>
</tr>
<tr>
<td align="center"><input type="submit" class="premiumpress_button" name="Submit" value="Save Images" style="color:#fff;" /></td>
</tr>
</table>
</td>
</form>
</tr>
</table>
</div>
<div id="premiumpress_tab3" class="content"></div>
<div id="premiumpress_tab4" class="content"></div>
<div id="premiumpress_tab5" class="content"></div>
<div id="premiumpress_tab6" class="content"></div>            
					 
                        
</div>
</div>
<div class="clearfix"></div>  

 

<?php } ?>