//////////////////////////////////////////////////////////////////////// SWFObject ////////////////////////////////////////////////////////////////////////
		
		/* SWFObject v2.1 <http://code.google.com/p/swfobject/>
			Copyright (c) 2007-2008 Geoff Stearns, Michael Williams, and Bobby van der Sluis
			This software is released under the MIT License <http://www.opensource.org/licenses/mit-license.php>
		*/
		var swfobject=function(){var b="undefined",Q="object",n="Shockwave Flash",p="ShockwaveFlash.ShockwaveFlash",P="application/x-shockwave-flash",m="SWFObjectExprInst",j=window,K=document,T=navigator,o=[],N=[],i=[],d=[],J,Z=null,M=null,l=null,e=false,A=false;var h=function(){var v=typeof K.getElementById!=b&&typeof K.getElementsByTagName!=b&&typeof K.createElement!=b,AC=[0,0,0],x=null;if(typeof T.plugins!=b&&typeof T.plugins[n]==Q){x=T.plugins[n].description;if(x&&!(typeof T.mimeTypes!=b&&T.mimeTypes[P]&&!T.mimeTypes[P].enabledPlugin)){x=x.replace(/^.*\s+(\S+\s+\S+$)/,"$1");AC[0]=parseInt(x.replace(/^(.*)\..*$/,"$1"),10);AC[1]=parseInt(x.replace(/^.*\.(.*)\s.*$/,"$1"),10);AC[2]=/r/.test(x)?parseInt(x.replace(/^.*r(.*)$/,"$1"),10):0}}else{if(typeof j.ActiveXObject!=b){var y=null,AB=false;try{y=new ActiveXObject(p+".7")}catch(t){try{y=new ActiveXObject(p+".6");AC=[6,0,21];y.AllowScriptAccess="always"}catch(t){if(AC[0]==6){AB=true}}if(!AB){try{y=new ActiveXObject(p)}catch(t){}}}if(!AB&&y){try{x=y.GetVariable("$version");if(x){x=x.split(" ")[1].split(",");AC=[parseInt(x[0],10),parseInt(x[1],10),parseInt(x[2],10)]}}catch(t){}}}}var AD=T.userAgent.toLowerCase(),r=T.platform.toLowerCase(),AA=/webkit/.test(AD)?parseFloat(AD.replace(/^.*webkit\/(\d+(\.\d+)?).*$/,"$1")):false,q=false,z=r?/win/.test(r):/win/.test(AD),w=r?/mac/.test(r):/mac/.test(AD);/*@cc_on q=true;@if(@_win32)z=true;@elif(@_mac)w=true;@end@*/return{w3cdom:v,pv:AC,webkit:AA,ie:q,win:z,mac:w}}();var L=function(){if(!h.w3cdom){return }f(H);if(h.ie&&h.win){try{K.write("<script id=__ie_ondomload defer=true src=//:><\/script>");J=C("__ie_ondomload");if(J){I(J,"onreadystatechange",S)}}catch(q){}}if(h.webkit&&typeof K.readyState!=b){Z=setInterval(function(){if(/loaded|complete/.test(K.readyState)){E()}},10)}if(typeof K.addEventListener!=b){K.addEventListener("DOMContentLoaded",E,null)}R(E)}();function S(){if(J.readyState=="complete"){J.parentNode.removeChild(J);E()}}function E(){if(e){return }if(h.ie&&h.win){var v=a("span");try{var u=K.getElementsByTagName("body")[0].appendChild(v);u.parentNode.removeChild(u)}catch(w){return }}e=true;if(Z){clearInterval(Z);Z=null}var q=o.length;for(var r=0;r<q;r++){o[r]()}}function f(q){if(e){q()}else{o[o.length]=q}}function R(r){if(typeof j.addEventListener!=b){j.addEventListener("load",r,false)}else{if(typeof K.addEventListener!=b){K.addEventListener("load",r,false)}else{if(typeof j.attachEvent!=b){I(j,"onload",r)}else{if(typeof j.onload=="function"){var q=j.onload;j.onload=function(){q();r()}}else{j.onload=r}}}}}function H(){var t=N.length;for(var q=0;q<t;q++){var u=N[q].id;if(h.pv[0]>0){var r=C(u);if(r){N[q].width=r.getAttribute("width")?r.getAttribute("width"):"0";N[q].height=r.getAttribute("height")?r.getAttribute("height"):"0";if(c(N[q].swfVersion)){if(h.webkit&&h.webkit<312){Y(r)}W(u,true)}else{if(N[q].expressInstall&&!A&&c("6.0.65")&&(h.win||h.mac)){k(N[q])}else{O(r)}}}}else{W(u,true)}}}function Y(t){var q=t.getElementsByTagName(Q)[0];if(q){var w=a("embed"),y=q.attributes;if(y){var v=y.length;for(var u=0;u<v;u++){if(y[u].nodeName=="DATA"){w.setAttribute("src",y[u].nodeValue)}else{w.setAttribute(y[u].nodeName,y[u].nodeValue)}}}var x=q.childNodes;if(x){var z=x.length;for(var r=0;r<z;r++){if(x[r].nodeType==1&&x[r].nodeName=="PARAM"){w.setAttribute(x[r].getAttribute("name"),x[r].getAttribute("value"))}}}t.parentNode.replaceChild(w,t)}}function k(w){A=true;var u=C(w.id);if(u){if(w.altContentId){var y=C(w.altContentId);if(y){M=y;l=w.altContentId}}else{M=G(u)}if(!(/%$/.test(w.width))&&parseInt(w.width,10)<310){w.width="310"}if(!(/%$/.test(w.height))&&parseInt(w.height,10)<137){w.height="137"}K.title=K.title.slice(0,47)+" - Flash Player Installation";var z=h.ie&&h.win?"ActiveX":"PlugIn",q=K.title,r="MMredirectURL="+j.location+"&MMplayerType="+z+"&MMdoctitle="+q,x=w.id;if(h.ie&&h.win&&u.readyState!=4){var t=a("div");x+="SWFObjectNew";t.setAttribute("id",x);u.parentNode.insertBefore(t,u);u.style.display="none";var v=function(){u.parentNode.removeChild(u)};I(j,"onload",v)}U({data:w.expressInstall,id:m,width:w.width,height:w.height},{flashvars:r},x)}}function O(t){if(h.ie&&h.win&&t.readyState!=4){var r=a("div");t.parentNode.insertBefore(r,t);r.parentNode.replaceChild(G(t),r);t.style.display="none";var q=function(){t.parentNode.removeChild(t)};I(j,"onload",q)}else{t.parentNode.replaceChild(G(t),t)}}function G(v){var u=a("div");if(h.win&&h.ie){u.innerHTML=v.innerHTML}else{var r=v.getElementsByTagName(Q)[0];if(r){var w=r.childNodes;if(w){var q=w.length;for(var t=0;t<q;t++){if(!(w[t].nodeType==1&&w[t].nodeName=="PARAM")&&!(w[t].nodeType==8)){u.appendChild(w[t].cloneNode(true))}}}}}return u}function U(AG,AE,t){var q,v=C(t);if(v){if(typeof AG.id==b){AG.id=t}if(h.ie&&h.win){var AF="";for(var AB in AG){if(AG[AB]!=Object.prototype[AB]){if(AB.toLowerCase()=="data"){AE.movie=AG[AB]}else{if(AB.toLowerCase()=="styleclass"){AF+=' class="'+AG[AB]+'"'}else{if(AB.toLowerCase()!="classid"){AF+=" "+AB+'="'+AG[AB]+'"'}}}}}var AD="";for(var AA in AE){if(AE[AA]!=Object.prototype[AA]){AD+='<param name="'+AA+'" value="'+AE[AA]+'" />'}}v.outerHTML='<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"'+AF+">"+AD+"</object>";i[i.length]=AG.id;q=C(AG.id)}else{if(h.webkit&&h.webkit<312){var AC=a("embed");AC.setAttribute("type",P);for(var z in AG){if(AG[z]!=Object.prototype[z]){if(z.toLowerCase()=="data"){AC.setAttribute("src",AG[z])}else{if(z.toLowerCase()=="styleclass"){AC.setAttribute("class",AG[z])}else{if(z.toLowerCase()!="classid"){AC.setAttribute(z,AG[z])}}}}}for(var y in AE){if(AE[y]!=Object.prototype[y]){if(y.toLowerCase()!="movie"){AC.setAttribute(y,AE[y])}}}v.parentNode.replaceChild(AC,v);q=AC}else{var u=a(Q);u.setAttribute("type",P);for(var x in AG){if(AG[x]!=Object.prototype[x]){if(x.toLowerCase()=="styleclass"){u.setAttribute("class",AG[x])}else{if(x.toLowerCase()!="classid"){u.setAttribute(x,AG[x])}}}}for(var w in AE){if(AE[w]!=Object.prototype[w]&&w.toLowerCase()!="movie"){F(u,w,AE[w])}}v.parentNode.replaceChild(u,v);q=u}}}return q}function F(t,q,r){var u=a("param");u.setAttribute("name",q);u.setAttribute("value",r);t.appendChild(u)}function X(r){var q=C(r);if(q&&(q.nodeName=="OBJECT"||q.nodeName=="EMBED")){if(h.ie&&h.win){if(q.readyState==4){B(r)}else{j.attachEvent("onload",function(){B(r)})}}else{q.parentNode.removeChild(q)}}}function B(t){var r=C(t);if(r){for(var q in r){if(typeof r[q]=="function"){r[q]=null}}r.parentNode.removeChild(r)}}function C(t){var q=null;try{q=K.getElementById(t)}catch(r){}return q}function a(q){return K.createElement(q)}function I(t,q,r){t.attachEvent(q,r);d[d.length]=[t,q,r]}function c(t){var r=h.pv,q=t.split(".");q[0]=parseInt(q[0],10);q[1]=parseInt(q[1],10)||0;q[2]=parseInt(q[2],10)||0;return(r[0]>q[0]||(r[0]==q[0]&&r[1]>q[1])||(r[0]==q[0]&&r[1]==q[1]&&r[2]>=q[2]))?true:false}function V(v,r){if(h.ie&&h.mac){return }var u=K.getElementsByTagName("head")[0],t=a("style");t.setAttribute("type","text/css");t.setAttribute("media","screen");if(!(h.ie&&h.win)&&typeof K.createTextNode!=b){t.appendChild(K.createTextNode(v+" {"+r+"}"))}u.appendChild(t);if(h.ie&&h.win&&typeof K.styleSheets!=b&&K.styleSheets.length>0){var q=K.styleSheets[K.styleSheets.length-1];if(typeof q.addRule==Q){q.addRule(v,r)}}}function W(t,q){var r=q?"visible":"hidden";if(e&&C(t)){C(t).style.visibility=r}else{V("#"+t,"visibility:"+r)}}function g(s){var r=/[\\\"<>\.;]/;var q=r.exec(s)!=null;return q?encodeURIComponent(s):s}var D=function(){if(h.ie&&h.win){window.attachEvent("onunload",function(){var w=d.length;for(var v=0;v<w;v++){d[v][0].detachEvent(d[v][1],d[v][2])}var t=i.length;for(var u=0;u<t;u++){X(i[u])}for(var r in h){h[r]=null}h=null;for(var q in swfobject){swfobject[q]=null}swfobject=null})}}();return{registerObject:function(u,q,t){if(!h.w3cdom||!u||!q){return }var r={};r.id=u;r.swfVersion=q;r.expressInstall=t?t:false;N[N.length]=r;W(u,false)},getObjectById:function(v){var q=null;if(h.w3cdom){var t=C(v);if(t){var u=t.getElementsByTagName(Q)[0];if(!u||(u&&typeof t.SetVariable!=b)){q=t}else{if(typeof u.SetVariable!=b){q=u}}}}return q},embedSWF:function(x,AE,AB,AD,q,w,r,z,AC){if(!h.w3cdom||!x||!AE||!AB||!AD||!q){return }AB+="";AD+="";if(c(q)){W(AE,false);var AA={};if(AC&&typeof AC===Q){for(var v in AC){if(AC[v]!=Object.prototype[v]){AA[v]=AC[v]}}}AA.data=x;AA.width=AB;AA.height=AD;var y={};if(z&&typeof z===Q){for(var u in z){if(z[u]!=Object.prototype[u]){y[u]=z[u]}}}if(r&&typeof r===Q){for(var t in r){if(r[t]!=Object.prototype[t]){if(typeof y.flashvars!=b){y.flashvars+="&"+t+"="+r[t]}else{y.flashvars=t+"="+r[t]}}}}f(function(){U(AA,y,AE);if(AA.id==AE){W(AE,true)}})}else{if(w&&!A&&c("6.0.65")&&(h.win||h.mac)){A=true;W(AE,false);f(function(){var AF={};AF.id=AF.altContentId=AE;AF.width=AB;AF.height=AD;AF.expressInstall=w;k(AF)})}}},getFlashPlayerVersion:function(){return{major:h.pv[0],minor:h.pv[1],release:h.pv[2]}},hasFlashPlayerVersion:c,createSWF:function(t,r,q){if(h.w3cdom){return U(t,r,q)}else{return undefined}},removeSWF:function(q){if(h.w3cdom){X(q)}},createCSS:function(r,q){if(h.w3cdom){V(r,q)}},addDomLoadEvent:f,addLoadEvent:R,getQueryParamValue:function(v){var u=K.location.search||K.location.hash;if(v==null){return g(u)}if(u){var t=u.substring(1).split("&");for(var r=0;r<t.length;r++){if(t[r].substring(0,t[r].indexOf("="))==v){return g(t[r].substring((t[r].indexOf("=")+1)))}}}return""},expressInstallCallback:function(){if(A&&M){var q=C(m);if(q){q.parentNode.replaceChild(M,q);if(l){W(l,true);if(h.ie&&h.win){M.style.display="block"}}M=null;l=null;A=false}}}}}();


//////////////////////////////////////////////////////////////////////// SWFAddress ////////////////////////////////////////////////////////////////////////

/**
 * SWFAddress 2.2: Deep linking for Flash and Ajax <http://www.asual.com/swfaddress/>
 *
 * SWFAddress is (c) 2006-2008 Rostislav Hristov and contributors
 * This software is released under the MIT License <http://www.opensource.org/licenses/mit-license.php>
 *
 */
if(typeof asual=="undefined"){asual={};}if(typeof asual.swfaddress=="undefined"){asual.swfaddress={};}if(typeof asual.util=="undefined"){asual.util={};}asual.util.Browser=new function(){var B=-1,D=navigator.userAgent,H=false,G=false,F=false,A=false,C=false,I=false;var E=function(K,J){return parseFloat(D.substr(D.indexOf(K)+J));};if(A=/Opera/.test(D)){B=parseFloat(navigator.appVersion);}if(H=/MSIE/.test(D)){B=E("MSIE",4);}if(I=/Chrome/.test(D)){B=E("Chrome",7);}if(G=/Camino/.test(D)){B=E("Camino",7);}if(F=(/AppleWebKit/.test(D)&&!I)){B=E("Safari",7);}if(C=(/Firefox/.test(D)&&!G)){B=E("Firefox",8);}this.toString=function(){return "[class Browser]";};this.getVersion=function(){return B;};this.isIE=function(){return H;};this.isSafari=function(){return F;};this.isOpera=function(){return A;};this.isCamino=function(){return G;};this.isFirefox=function(){return C;};this.isChrome=function(){return I;};};asual.util.Events=new function(){var C="DOMContentLoaded",G="onstop",I=window,F=document,B=[],A=asual.util,D=A.Browser;this.toString=function(){return "[class Events]";};this.addListener=function(L,J,K){B.push({o:L,t:J,l:K});if(!(J==C&&(D.isIE()||D.isSafari()))){if(L.addEventListener){L.addEventListener(J,K,false);}else{if(L.attachEvent){L.attachEvent("on"+J,K);}}}};this.removeListener=function(N,K,L){for(var J=0,M;M=B[J];J++){if(M.o==N&&M.t==K&&M.l==L){B.splice(J,1);break;}}if(!(K==C&&(D.isIE()||D.isSafari()))){if(N.removeEventListener){N.removeEventListener(K,L,false);}else{if(N.detachEvent){N.detachEvent("on"+K,L);}}}};var H=function(){for(var K=0,J;J=B[K];K++){if(J.t!=C){A.Events.removeListener(J.o,J.t,J.l);}}};var E=function(){if(F.readyState=="interactive"){function J(){F.detachEvent(G,J);H();};F.attachEvent(G,J);I.setTimeout(function(){F.detachEvent(G,J);},0);}};if(D.isIE()||D.isSafari()){(function(){try{if((D.isIE()&&F.body)||!/loaded|complete/.test(F.readyState)){F.documentElement.doScroll("left");}}catch(K){return setTimeout(arguments.callee,0);}for(var J=0,K;K=B[J];J++){if(K.t==C){K.l.call(null);}}})();}if(D.isIE()){I.attachEvent("onbeforeunload",E);}this.addListener(I,"unload",H);};asual.util.Functions=new function(){this.toString=function(){return "[class Functions]";};this.extend=function(C,A){function B(){};B.prototype=C.prototype;A.prototype=new B();A.prototype.constructor=A;A.superConstructor=C;A.superClass=C.prototype;return A;};this.bind=function(F,B,E){for(var C=2,D,A=[];D=arguments[C];C++){A.push(D);}return function(){return F.apply(B,A);};};};asual.swfaddress.WEBAddressEvent=function(D){var A=asual.swfaddress.WEBAddress;this.toString=function(){return "[object WEBAddressEvent]";};this.type=D;this.target=[A][0];this.value=A.getValue();this.path=A.getPath();this.pathNames=A.getPathNames();this.parameters={};var E=A.getParameterNames();for(var C=0,B=E.length;C<B;C++){this.parameters[E[C]]=A.getParameter(E[C]);}this.parametersNames=E;};asual.swfaddress.WEBAddressEvent.INIT="init";asual.swfaddress.WEBAddressEvent.CHANGE="change";asual.swfaddress.WEBAddress=new function(){var ID="",_2f="function",_30="undefined",_31=asual.swfaddress,_32=asual.util,_33=_32.Browser,_34=_32.Events,_35=_32.Functions,_36=_33.getVersion(),_37=false,_t=top,_d=_t.document,_h=_t.history,_l=_t.location,_si=setInterval,_st=setTimeout,_dc=decodeURIComponent,_ec=encodeURIComponent,_40,_41,_42,_43,_44=_d.title,_45=_h.length,_46=false,_47=false,_48=true,_49=true,_4a=[],_4b={},_4c={history:true,html:false,strict:true,tracker:"_trackDefault"};if(_33.isOpera()){_37=_36>=9.02;}if(_33.isIE()){_37=_36>=6;}if(_33.isSafari()){_37=_36>=312;}if(_33.isChrome()){_37=_36>=0.2;}if(_33.isCamino()){_37=_36>=1;}if(_33.isFirefox()){_37=_36>=1;}if((!_37&&_l.href.indexOf("#")!=-1)||(_33.isSafari()&&_36<418&&_l.href.indexOf("#")!=-1&&_l.search!="")){_d.open();_d.write("<html><head><meta http-equiv=\"refresh\" content=\"0;url="+_l.href.substr(0,_l.href.indexOf("#"))+"\" /></head></html>");_d.close();}var _4d=function(){var _4e=_l.href.indexOf("#");return _4e!=-1?_l.href.substr(_4e+1):"";};var _4f=_4d();var _50=function(_51,_52){if(_4c.strict){_51=_52?(_51.substr(0,1)!="/"?"/"+_51:_51):(_51==""?"/":_51);}return _51;};var _53=function(_54){return (_33.isIE()&&_l.protocol=="file:")?_4f.replace(/\?/,"%3F"):_54;};var _55=function(el){for(var i=0,l=el.childNodes.length,s;i<l;i++){if(el.childNodes[i].src){_42=String(el.childNodes[i].src);}if(s=_55(el.childNodes[i])){return s;}}};var _5a=function(){if(_33.isIE()&&_d.title!=_44&&_d.title.indexOf("#")!=-1){_d.title=_44;if(_4c.html&&_40&&_40.contentWindow&&_40.contentWindow.document){_40.contentWindow.document.title=_44;}}};var _5b=function(){if(!_46){var _5c=_4d();var _5d=!(_4f==_5c||_4f==_dc(_5c)||_dc(_4f)==_5c);if(_33.isSafari()&&_36<523){if(_45!=_h.length){_45=_h.length;if(typeof _4a[_45-1]!=_30){_4f=_4a[_45-1];}_5e.call(this);}}else{if(_33.isIE()&&_5d){if(_36<7){_l.reload();}else{this.setValue(_5c);}}else{if(_5d){_4f=_5c;_5e.call(this);}}}_5a.call(this);}};var _5f=function(_60){this.dispatchEvent(new _31.WEBAddressEvent(_60));_60=_60.substr(0,1).toUpperCase()+_60.substr(1);if(typeof this["on"+_60]==_2f){this["on"+_60]();}};var _61=function(){_5f.call(this,"init");};var _62=function(){_5f.call(this,"change");};var _5e=function(){_62.call(this);_st(_35.bind(_63,this),10);};var _64=function(_65){if(typeof urchinTracker==_2f){urchinTracker(_65);}if(typeof pageTracker!=_30&&typeof pageTracker._trackPageview==_2f){pageTracker._trackPageview(_65);}};eval("var _trackDefault = "+_64+";");var _63=function(){if(typeof _4c.tracker!=_30&&eval("typeof "+_4c.tracker+" != \""+_30+"\"")){var fn=eval(_4c.tracker);if(typeof fn==_2f){fn(_dc((_l.pathname+(/\/$/.test(_l.pathname)?"":"/")+this.getValue()).replace(/\/\//,"/").replace(/^\/$/,"")));}}};var _67=function(){var doc=_40.contentWindow.document;doc.open();doc.write("<html><head><title>"+_d.title+"</title><script>var "+ID+" = \""+_ec(_4d())+"\";</script></head></html>");doc.close();};var _69=function(){var win=_40.contentWindow;var src=win.location.href;_4f=(_4c.html)?(src.indexOf("?")>-1?_dc(src.substr(src.indexOf("?")+1)):""):(typeof win[ID]!=_30?_dc(win[ID]):"");if(_4c.html){win.document.title=_44;}if(_4f!=_4d()){_5e.call(_31.WEBAddress);_l.hash=_53(_4f);}};var _6c=function(){if(!_47){_47=true;var _6d="id=\""+ID+"\" style=\"position:absolute;top:-9999px;\"";if(_33.isIE()&&_36<8){_d.body.appendChild(_d.createElement("div")).innerHTML="<iframe "+_6d+" src=\""+(_4c.html?_42.replace(/\.js(\?.*)?$/,".html")+"?"+_ec(_4d()):"javascript:false;")+"\" width=\"0\" height=\"0\"></iframe>";_40=_d.getElementById(ID);_st(function(){_34.addListener(_40,"load",_69);if(!_4c.html&&typeof _40.contentWindow[ID]==_30){_67();}},50);}else{if(_33.isSafari()){if(_36<418){_d.body.innerHTML+="<form "+_6d+" method=\"get\"></form>";_41=_d.getElementById(ID);}if(typeof _l[ID]==_30){_l[ID]={};}if(typeof _l[ID][_l.pathname]!=_30){_4a=_l[ID][_l.pathname].split(",");}}}_st(_35.bind(_61,this),1);_st(_35.bind(_62,this),2);_st(_35.bind(_63,this),10);if(_33.isIE()&&_36>=8){_d.body.onhashchange=_35.bind(_5b,this);_43=_si(_35.bind(_5a,this),50);}else{_43=_si(_35.bind(_5b,this),50);}}};var _6e=function(){clearInterval(_43);};this.onInit=null;this.onChange=null;this.toString=function(){return "[class WEBAddress]";};this.back=function(){_h.back();};this.forward=function(){_h.forward();};this.up=function(){var _6f=this.getPath();this.setValue(_6f.substr(0,_6f.lastIndexOf("/",_6f.length-2)+(_6f.substr(_6f.length-1)=="/"?1:0)));};this.go=function(_70){_h.go(_70);};this.addEventListener=function(_71,_72){if(typeof _4b[_71]==_30){_4b[_71]=[];}_4b[_71].push(_72);};this.removeEventListener=function(_73,_74){if(typeof _4b[_73]!=_30){for(var i=0,l;l=_4b[_73][i];i++){if(l==_74){break;}}_4b[_73].splice(i,1);}};this.dispatchEvent=function(_77){if(this.hasEventListener(_77.type)){_77.target=this;for(var i=0,l;l=_4b[_77.type][i];i++){l(_77);}return true;}return false;};this.hasEventListener=function(_7a){return (typeof _4b[_7a]!=_30&&_4b[_7a].length>0);};this.getBaseURL=function(){var url=_l.href;if(url.indexOf("#")!=-1){url=url.substr(0,url.indexOf("#"));}if(url.substr(url.length-1)=="/"){url=url.substr(0,url.length-1);}return url;};this.getStrict=function(){return _4c.strict;};this.setStrict=function(_7c){_4c.strict=_7c;};this.getHistory=function(){return _4c.history;};this.setHistory=function(_7d){_4c.history=_7d;};this.getTracker=function(){return _4c.tracker;};this.setTracker=function(_7e){_4c.tracker=_7e;};this.getTitle=function(){return _d.title;};this.setTitle=function(_7f){if(!_37){return null;}if(typeof _7f==_30){return;}if(_7f=="null"){_7f="";}_44=_d.title=_7f;_st(function(){if((_49||_4c.html)&&_40&&_40.contentWindow&&_40.contentWindow.document){_40.contentWindow.document.title=_7f;_49=false;}if(!_48&&(_33.isCamino()||_33.isFirefox())){_l.replace(_l.href.indexOf("#")!=-1?_l.href:_l.href+"#");}_48=false;},50);};this.getStatus=function(){return _t.status;};this.setStatus=function(_80){if(typeof _80==_30){return;}if(!_33.isSafari()){_80=_50((_80!="null")?_80:"",true);if(_80=="/"){_80="";}if(!(/http(s)?:\/\//.test(_80))){var _81=_l.href.indexOf("#");_80=(_81==-1?_l.href:_l.href.substr(0,_81))+"#"+_80;}_t.status=_80;}};this.resetStatus=function(){_t.status="";};this.getValue=function(){if(!_37){return null;}return _50(_4f,false);};this.setValue=function(_82){if(!_37){return null;}if(typeof _82==_30){return;}if(_82=="null"){_82="";}_82=_50(_82,true);if(_82=="/"){_82="";}if(_4f==_82||_4f==_dc(_82)||_dc(_4f)==_82){return;}_48=true;_4f=_82;_46=true;_5e.call(_31.WEBAddress);_4a[_h.length]=_4f;if(_33.isSafari()){if(_4c.history){_l[ID][_l.pathname]=_4a.toString();_45=_h.length+1;if(_36<418){if(_l.search==""){_41.action="#"+_4f;_41.submit();}}else{if(_36<523||_4f==""){var evt=_d.createEvent("MouseEvents");evt.initEvent("click",true,true);var _84=_d.createElement("a");_84.href="#"+_4f;_84.dispatchEvent(evt);}else{_l.hash="#"+_4f;}}}else{_l.replace("#"+_4f);}}else{if(_4f!=_4d()){if(_4c.history){_l.hash=(_33.isChrome()?"":"#")+_53(_4f);}else{_l.replace("#"+_4f);}}}if((_33.isIE()&&_36<8)&&_4c.history){if(_4c.html){var loc=_40.contentWindow.location;loc.assign(loc.pathname+"?"+_4d());}else{_st(_67,50);}}if(_33.isSafari()){_st(function(){_46=false;},1);}else{_46=false;}};this.getPath=function(){var _86=this.getValue();return (_86.indexOf("?")!=-1)?_86.split("?")[0]:_86;};this.getPathNames=function(){var _87=this.getPath();var _88=_87.split("/");if(_87.substr(0,1)=="/"||_87.length==0){_88.splice(0,1);}if(_87.substr(_87.length-1,1)=="/"){_88.splice(_88.length-1,1);}return _88;};this.getQueryString=function(){var _89=this.getValue();var _8a=_89.indexOf("?");return (_8a!=-1&&_8a<_89.length)?_89.substr(_8a+1):"";};this.getParameter=function(_8b){var _8c=this.getValue();var _8d=_8c.indexOf("?");if(_8d!=-1){_8c=_8c.substr(_8d+1);var _8e=_8c.split("&");var p,i=_8e.length;while(i--){p=_8e[i].split("=");if(p[0]==_8b){return p[1];}}}return "";};this.getParameterNames=function(){var _91=this.getValue();var _92=_91.indexOf("?");var _93=[];if(_92!=-1){_91=_91.substr(_92+1);if(_91!=""&&_91.indexOf("=")!=-1){var _94=_91.split("&");var i=0;while(i<_94.length){_93.push(_94[i].split("=")[0]);i++;}}}return _93;};if(_37){for(var i=1;i<_45;i++){_4a.push("");}_4a.push(_4d());if(_33.isIE()&&_l.hash!=_4d()){_l.hash="#"+_53(_4d());}_55(document);var _qi=_42.indexOf("?");if(_42&&_qi>-1){var _98,_99=_42.substr(_qi+1).split("&");for(var i=0,p;p=_99[i];i++){_98=p.split("=");if(/^(history|html|strict)$/.test(_98[0])){_4c[_98[0]]=(isNaN(_98[1])?eval(_98[1]):(parseFloat(_98[1])>0));}if(/^tracker$/.test(_98[0])){_4c[_98[0]]=_98[1];}}}if(/file:\/\//.test(_l.href)){_4c.html=false;}var _ei=_42.indexOf(".js"),l;if(_42&&_ei>-1){while(_ei--){l=_42.substr(_ei,1);if(/(\/|\\)/.test(l)){break;}ID=l+ID;}}_5a.call(this);if(window==_t){_34.addListener(document,"DOMContentLoaded",_35.bind(_6c,this));}_34.addListener(_t,"load",_35.bind(_6c,this));_34.addListener(_t,"unload",_35.bind(_6e,this));}else{_63();}};SWFAddressEvent=asual.swfaddress.SWFAddressEvent=function(A){SWFAddressEvent.superConstructor.apply(this,arguments);this.target=[SWFAddress][0];this.toString=function(){return "[object SWFAddressEvent]";};};asual.util.Functions.extend(asual.swfaddress.WEBAddressEvent,SWFAddressEvent);asual.swfaddress.SWFAddressEvent.INIT="init";asual.swfaddress.SWFAddressEvent.CHANGE="change";SWFAddress=asual.swfaddress.SWFAddress=new function(){var _9e="undefined",_t=top,_l=_t.location,_a1=this,_a2=[],_a3=[],_a4={},_a5=asual.util,_a6=asual.util.Functions,_a7=asual.swfaddress.WEBAddress;for(var p in _a7){this[p]=_a7[p];}var _a9=function(_aa){this.dispatchEvent(new SWFAddressEvent(_aa));_aa=_aa.substr(0,1).toUpperCase()+_aa.substr(1);if(typeof this["on"+_aa]=="function"){this["on"+_aa]();}};var _ab=function(e){if(_a3.length>0){var _ad=window.open(_a3[0],_a3[1],eval(_a3[2]));if(typeof _a3[3]!=_9e){eval(_a3[3]);}}_a3=[];};var _ae=function(){if(_a5.Browser.isSafari()){document.body.addEventListener("click",_ab);}_a9.call(this,"init");};var _af=function(){_b0();_a9.call(this,"change");};var _b0=function(){for(var i=0,id,obj,_b4=SWFAddress.getValue(),_b5="setSWFAddressValue";id=_a2[i];i++){obj=document.getElementById(id);if(obj){if(obj.parentNode&&typeof obj.parentNode.so!=_9e){obj.parentNode.so.call(_b5,_b4);}else{if(!(obj&&typeof obj[_b5]!=_9e)){var _b6=obj.getElementsByTagName("object");var _b7=obj.getElementsByTagName("embed");obj=((_b6[0]&&typeof _b6[0][_b5]!=_9e)?_b6[0]:((_b7[0]&&typeof _b7[0][_b5]!=_9e)?_b7[0]:null));}if(obj){obj[_b5](decodeURIComponent(_b4));}}}else{if(obj=document[id]){if(typeof obj[_b5]!=_9e){obj[_b5](_b4);}}}}};this.toString=function(){return "[class SWFAddress]";};this.addEventListener=function(_b8,_b9){if(typeof _a4[_b8]==_9e){_a4[_b8]=[];}_a4[_b8].push(_b9);};this.removeEventListener=function(_ba,_bb){if(typeof _a4[_ba]!=_9e){for(var i=0,l;l=_a4[_ba][i];i++){if(l==_bb){break;}}_a4[_ba].splice(i,1);}};this.dispatchEvent=function(_be){if(typeof _a4[_be.type]!=_9e&&_a4[_be.type].length){_be.target=this;for(var i=0,l;l=_a4[_be.type][i];i++){l(_be);}return true;}return false;};this.hasEventListener=function(_c1){return (typeof _a4[_c1]!=_9e&&_a4[_c1].length>0);};this.href=function(url,_c3){_c3=typeof _c3!=_9e?_c3:"_self";if(_c3=="_self"){self.location.href=url;}else{if(_c3=="_top"){_l.href=url;}else{if(_c3=="_blank"){window.open(url);}else{_t.frames[_c3].location.href=url;}}}};this.popup=function(url,_c5,_c6,_c7){try{var _c8=window.open(url,_c5,eval(_c6));if(typeof _c7!=_9e){eval(_c7);}}catch(ex){}_a3=arguments;};this.getIds=function(){return _a2;};this.getId=function(_c9){return _a2[0];};this.setId=function(id){_a2[0]=id;};this.addId=function(id){this.removeId(id);_a2.push(id);};this.removeId=function(id){for(var i=0;i<_a2.length;i++){if(id==_a2[i]){_a2.splice(i,1);break;}}};this.setValue=function(_ce){if(_a2.length>0!=0&&_a5.Browser.isFirefox()&&navigator.userAgent.indexOf("Mac")!=-1){setTimeout(function(){_a7.setValue.call(SWFAddress,_ce);},500);}else{_a7.setValue.call(this,_ce);}};_a7.addEventListener("init",_a6.bind(_ae,this));_a7.addEventListener("change",_a6.bind(_af,this));(function(){var _cf;if(typeof FlashObject!=_9e){SWFObject=FlashObject;}if(typeof SWFObject!=_9e&&SWFObject.prototype&&SWFObject.prototype.write){var _s1=SWFObject.prototype.write;SWFObject.prototype.write=function(){_cf=arguments;if(this.getAttribute("version").major<8){this.addVariable("$swfaddress",SWFAddress.getValue());((typeof _cf[0]=="string")?document.getElementById(_cf[0]):_cf[0]).so=this;}var _d1;if(_d1=_s1.apply(this,_cf)){_a1.addId(this.getAttribute("id"));}return _d1;};}if(typeof swfobject!=_9e){var _d2=swfobject.registerObject;swfobject.registerObject=function(){_cf=arguments;_d2.apply(this,_cf);_a1.addId(_cf[0]);};var _d3=swfobject.createSWF;swfobject.createSWF=function(){_cf=arguments;_d3.apply(this,_cf);_a1.addId(_cf[0].id);};var _d4=swfobject.embedSWF;swfobject.embedSWF=function(){_cf=arguments;_d4.apply(this,_cf);_a1.addId(_cf[8].id);};}if(typeof UFO!=_9e){var _u=UFO.create;UFO.create=function(){_cf=arguments;_u.apply(this,_cf);_a1.addId(_cf[0].id);};}if(typeof AC_FL_RunContent!=_9e){var _a=AC_FL_RunContent;AC_FL_RunContent=function(){_cf=arguments;_a.apply(this,_cf);for(var i=0,l=_cf.length;i<l;i++){if(_cf[i]=="id"){_a1.addId(_cf[i+1]);}}};}})();};

//////////////////////////////////////////////////////////////////////// SWFMacMouseWheel ////////////////////////////////////////////////////////////////////////

		/**
		 * SWFMacMouseWheel v2.0: Mac Mouse Wheel functionality in flash - http://blog.pixelbreaker.com/
		 *
		 * SWFMacMouseWheel is (c) 2007 Gabriel Bucknall and is released under the MIT License:
		 * http://www.opensource.org/licenses/mit-license.php
		 *
		 * Dependencies: 
		 * SWFObject v2.0 rc2 <http://code.google.com/p/swfobject/>
		 * Copyright (c) 2007 Geoff Stearns, Michael Williams, and Bobby van der Sluis
		 * This software is released under the MIT License <http://www.opensource.org/licenses/mit-license.php>
		 */
		var swfmacmousewheel=function(){if(!swfobject)return null;var u=navigator.userAgent.toLowerCase();var p=navigator.platform.toLowerCase();var d=p?/mac/.test(p):/mac/.test(u);if(!d)return null;var k=[];var r=function(event){var o=0;if(event.wheelDelta){o=event.wheelDelta/120;if(window.opera)o= -o;}else if(event.detail){o= -event.detail;}if(event.preventDefault)event.preventDefault();return o;};var l=function(event){var o=r(event);var c;for(var i=0;i<k.length;i++){c=swfobject.getObjectById(k[i]);if(typeof(c.externalMouseEvent)=='function')c.externalMouseEvent(o);}};if(window.addEventListener)window.addEventListener('DOMMouseScroll',l,false);window.onmousewheel=document.onmousewheel=l;return{registerObject:function(m){k[k.length]=m;}};}();

//////////////////////////////////////////////////////////////////////// SWFMacMouseWheel ////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////// SWFFit ////////////////////////////////////////////////////////////////////////

		/**
		*	swffit v2.1 (01/18/2009) <http://swffit.millermedeiros.com/>
		*	Copyright (c) 2008 Miller Medeiros <http://www.millermedeiros.com/>
		*	This software is released under the MIT License <http://www.opensource.org/licenses/mit-license.php>
		*/
		var swffit=function(){var NS=(navigator.appName=="Netscape")?true:false,WK=(navigator.userAgent.indexOf("WebKit")>0)?true:false,UNDEF="undefined",win=window,doc=document,html=doc.getElementsByTagName("html")[0],_ft,_re,_t,_mw,_mh,_xw,_xh,_hc,_vc;swfobject.createCSS("object","position:absolute");function fit(t,mw,mh,xw,xh,hc,vc){var xw=(xw)?xw:null,xh=(xh)?xh:null,hc=(hc||hc==null)?true:false,vc=(vc||vc==null)?true:false;configure({target:t,minWid:mw,minHei:mh,maxWid:xw,maxHei:xh,hCenter:hc,vCenter:vc})}function configure(o){_mw=(o.minWid)?o.minWid:_mw;_mh=(o.minHei)?o.minHei:_mh;_xw=(typeof o.maxWid!=UNDEF)?o.maxWid:_xw;_xh=(typeof o.maxHei!=UNDEF)?o.maxHei:_xh;_hc=(o.hCenter||(_hc==true&&o.hCenter==null))?true:false;_vc=(o.vCenter||(_vc==true&&o.vCenter==null))?true:false;if(o.target&&(o.target!=_t)){_t=o.target;swfobject.addDomLoadEvent(initFit)}else{startFit()}}function initFit(){html.style.height=doc.body.style.height="100%";html.style.overflow="auto";doc.body.style.margin=doc.body.style.padding="0";swfobject.createCSS("#"+_t,"width:100%; height:100%");if(swfobject.getObjectById(_t)){_ft=swfobject.getObjectById(_t)}else{if(NS){_ft=doc.getElementById(_t).getElementsByTagName("object")[0]}else{_ft=doc.getElementById(_t)}}startFit()}function startFit(){setSize();if(!_re){addResizeEvent(setSize);_re=1}}function stopFit(w,h){if(_re){removeResizeEvent(setSize);_re=0;_ft.style.top=_ft.style.left="auto";_ft.style.marginTop=_ft.style.marginLeft="0";var w=(w==null)?"100%":w,h=(h==null)?"100%":h;setWidth(w);setHeight(h);if(WK){html.focus()}}}function addResizeEvent(fn){if(win.addEventListener){win.addEventListener("resize",fn,false)}else{if(win.attachEvent){win.attachEvent("onresize",fn)}}}function removeResizeEvent(fn){if(win.removeEventListener){win.removeEventListener("resize",fn,false)}else{if(win.detachEvent){win.detachEvent("onresize",fn)}}}function setWidth(w){_ft.style.width=(isNaN(w))?w:w+"px"}function setHeight(h){_ft.style.height=(isNaN(h))?h:h+"px"}function setSize(){var iw=(NS)?win.innerWidth:doc.body.clientWidth,ih=(NS)?win.innerHeight:doc.body.clientHeight;if(_xw&&iw>=_xw){setWidth(_xw);setPosition(0,1)}else{if(iw>_mw&&(iw<_xw||!_xw)){setWidth("100%")}else{setWidth(_mw)}setPosition(0,0)}if(_xh&&ih>=_xh){setHeight(_xh);setPosition(1,1)}else{if(ih>_mh&&(ih<_xh||!_xh)){setHeight("100%")}else{setHeight(_mh)}setPosition(1,0)}if(WK){html.focus()}}function setPosition(t,m){if(t){if(m&&_vc){_ft.style.top="50%";_ft.style.marginTop=-(_xh*0.5)+"px"}else{_ft.style.top="auto";_ft.style.marginTop="0"}}else{if(m&&_hc){_ft.style.left="50%";_ft.style.marginLeft=-(_xw*0.5)+"px"}else{_ft.style.left="auto";_ft.style.marginLeft="0"}}}function getValueOf(p){var o={target:_t,minWid:_mw,minHei:_mh,maxWid:_xw,maxHei:_xh,hCenter:_hc,vCenter:_vc};return o[p]}return{fit:fit,configure:configure,startFit:startFit,stopFit:stopFit,addResizeEvent:addResizeEvent,removeResizeEvent:removeResizeEvent,getValueOf:getValueOf}}();



//////////////////////////////////////////////////////////////////////// COOKIES ////////////////////////////////////////////////////////////////////////

		function setCookie(name, value, domain){
			var today = new Date();
			today.setTime(today.getTime());
		
			// * 1000 for milliseconds
			expires = (60 * 1000) * (60 * 60 * 24);
			var expires_date = new Date(today.getTime() + (expires));
		
			document.cookie = name + "=" + escape(value) +
			((expires) ? ";expires=" + expires_date.toGMTString() : "" ) + ";path=/";
			((domain!="") ? ";domain=" + domain : "");
		}
		
		function getCookie(check_name){
		
			var a_all_cookies = document.cookie.split( ';' );
			var a_temp_cookie = '';
			var cookie_name = '';
			var cookie_value = '';
			
			for (i = 0; i < a_all_cookies.length; i++){
				a_temp_cookie = a_all_cookies[i].split( '=' );
				cookie_name = a_temp_cookie[0].replace(/^\s+|\s+$/g, '');
				if (cookie_name == check_name){
					if (a_temp_cookie.length > 1){
						cookie_value = unescape( a_temp_cookie[1].replace(/^\s+|\s+$/g, '') );
					}
		
					return cookie_value;
					break;
				}
				a_temp_cookie = null;
				cookie_name = '';
			}
		
			return null;
		}
		
		function deleteCookie(name, domain){
			if(getCookie(name)){
				document.cookie = name + "=" + ";path=/" +
				(( domain) ? ";domain=" + domain : "" ) +
				";expires=Thu, 01-Jan-1970 00:00:01 GMT";
			}
		}


//////////////////////////////////////////////////////////////////////// GET URL VARS ////////////////////////////////////////////////////////////////////////

function getVar(varName){
	var urlHalves = String(document.location).split('?');
	if(urlHalves[1]){
		var urlVars = urlHalves[1].split('&');
		for(var i=0; i<=(urlVars.length); i++){
			if(urlVars[i]){
				var urlVarPair = urlVars[i].split('=');
				var value = urlVarPair[1].split("#");

				if(urlVarPair[0] == varName){return value[0];}
				else{return undefined;}
			}
			else{return undefined;}			
		}
	}
	else{return undefined;}
}


//////////////////////////////////////////////////////////////////////// DEBUGGER ////////////////////////////////////////////////////////////////////////
		
		
		function Debugger(){
		
			var initialized = false;
			var currentState = "collapsed";
			
			Debugger.initialize = function(){
				if(getVar("debugMode") != undefined){
					
					var c = document.createElement("link");
					c.href = "_css/debugger.css";
					c.rel = "stylesheet";
					c.type="text/css";
					document.getElementsByTagName("head")[0].appendChild(c);
					
					var d = document.createElement("div");
					d.id = "debugger";
					d.innerHTML = "<div id=\"debugTab\" onMouseDown=\"Debugger.expandCollapse()\"> &lt; <\/div><div id=\"debugOutput\"><\/div>"
					document.getElementsByTagName("body")[0].appendChild(d);

					var e = document.createElement("script");
					e.src = "_js/tween.js";
					e.type="text/javascript";
					document.getElementsByTagName("head")[0].appendChild(e);

					initialized = true;
				}
			}

			Debugger.trace = function(val){
				if(initialized){
					findDOM("debugOutput",0).innerHTML += val + "<br />";
				}
			}
			
			Debugger.destroy = function(){
				alert("destroying...");	
			}
			
			Debugger.expand = function(){
				var _tween = new Tween(findDOM("debugger",1),'width',Tween.regularEaseOut,25,600,.3,'px');				
				_tween.start();
				_tween.onMotionFinished = function(){;}
				findDOM("debugTab",0).innerHTML = " &gt; ";
				Debugger.currentState = "expanded";
			}

			Debugger.collapse = function(){
				var _tween = new Tween(findDOM("debugger",1),'width',Tween.regularEaseOut,600,25,.3,'px');
				_tween.start();
				_tween.onMotionFinished = function(){;}
				findDOM("debugTab",0).innerHTML = " &lt; ";
				Debugger.currentState = "collapsed";
			}

			Debugger.expandCollapse = function(){
				if(Debugger.currentState == "expanded"){Debugger.collapse();}
				else{Debugger.expand();}
			}
		}
		
		var debuggerInstance = new Debugger();
		
		//////////////////////////////////////////////////////////////////////// FINDDOM ////////////////////////////////////////////////////////////////////////
		
		var isDHTML = 0;
		var isLayers = 0;
		var isAll = 0;
		var isID = 0;
		 
		if(document.getElementById){isID = 1; isDHTML = 1;}
		else{
			if(document.all){isAll = 1; isDHTML = 1;}
			else{
				browserVersion = parseInt(navigator.appVersion);
				if((navigator.appName.indexOf('Netscape') != -1) && (browserVersion == 4)){
					isLayers = 1;
					isDHTML = 1;
				}
			}
		}
		 
		if(navigator.appName != "Netscape" || navigator.appName < 5){var tr_display_state = "inline";}
		else{var tr_display_state = "table-row";}
		
		function findDOM(objectID,withStyle){
			if(withStyle == 1){
				if(isID){
					return (document.getElementById(objectID).style);
				}
				else{
					if(isAll){return (document.all[objectID].style);}
					else{
						if(isLayers){return (document.layers[objectID]);}
					}
				}
			}
			else{
				if(isID){return (document.getElementById(objectID));}
				else{
					if(isAll){return (document.all[objectID]);}
					else{
						if(isLayers){return (document.layers[objectID]);}
					}
				}
			}
		} 

///////////////////////////////////////////////////////////////////////// POP UP ////////////////////////////////////////////////////////////////////////


		function popWin(linkURL, width, height){
			NewWindow=window.open(linkURL,'newWin','width='+ width +',height='+ height +',left=0,top=0,toolbar=No,location=No,scrollbars=No,status=No,resizable=No,fullscreen=No'); 
			NewWindow.focus();
			screen_height = window.screen.availHeight;
			screen_width = window.screen.availWidth;
			left_point = parseInt(screen_width/2)-(width/2);
			top_point = parseInt(screen_height/2)-(height/2);
			setTimeout('NewWindow.moveTo(left_point,top_point)',100);
			void(0);
		}