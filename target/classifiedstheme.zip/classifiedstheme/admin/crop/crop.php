<?php 
foreach($_GET as $key => $val){
	$$key = $val;
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
	<html xmlns="http://www.w3.org/1999/xhtml">
        <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
        <title>PremiumPress Image Cropper</title>
		<link type="text/css" rel="stylesheet" href="_css/stylez.css" />
 
        <script type="text/javascript" src="_js/utilities.js"></script>
		<script language="javascript" type="text/javascript">
			var flashvars = {};
			flashvars.imageSrc = 'http://<?=$imageSrc?>';
			flashvars.startWidth = '<?=$startWidth?>';
			flashvars.startHeight = '<?=$startHeight?>';
			flashvars.minWidth = '<?=$minWidth?>';
			flashvars.minHeight = '<?=$minHeight?>';
			flashvars.maxWidth = '<?=$maxWidth?>';
			flashvars.maxHeight = '<?=$maxHeight?>';
			flashvars.resizeWidth = '<?=$resizeWidth?>';
			flashvars.resizeHeight = '<?=$resizeHeight?>';
			flashvars.forceAspect = '<?=$forceAspect?>';
			flashvars.processInBackground = '<?=$processInBackground?>';
			flashvars.extraArgs = "{imageQuality: '<?=$imageQuality?>'}";
			
			<?php if(isset($saveAsLocal) && $saveAsLocal == "true"){?>
			flashvars.saveAs = 'local';
			<?php }?>

			var params = {scale: "noscale", salign: "TL", allowScriptAccess: "always", allowFullScreen: "true", allowNetworking: "all", wmode: "opaque", bgcolor: "#cccccc"};
			var attributes = {id: "brackets"};
	
			swfobject.embedSWF("ImageCropper.swf", attributes.id, "100%", "100%", "9.0.0", "_swf/expressInstall.swf", flashvars, params, attributes);
			// can't use swffit for this site, because it messes up vertical alignment...
			//swffit.fit(attributes.id, 1000, 750);
		</script>		
    </head>
    <body>

		<div id="brackets" style="margin-left:auto; margin-right: auto">
			Please download Flash Player 9 to view this site:
			<p><a href="http://www.adobe.com/go/getflashplayer"><img src="http://www.adobe.com/images/shared/download_buttons/get_flash_player.gif" alt="Get Adobe Flash player" width="112" height="33" border="0" /></a></p>
		</div>
    </body>
</html>