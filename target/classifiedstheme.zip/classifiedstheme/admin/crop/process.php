<?php 

if(!function_exists("FilterPath")){

	function FilterPath(){
		$path=dirname(realpath($_SERVER['SCRIPT_FILENAME']));
		$path_parts = pathinfo($path);
		return $path;
	}
}

function premiumpress_rotateImage($srcImg, $degrees){

	if($degrees == 0){return $srcImg;}

	$srcWidth = imagesx($srcImg);
	$srcHeight = imagesy($srcImg);

	$newWidth = $srcHeight;
	$newHeight = $srcWidth;
	if($degrees == 180){$newWidth = $srcWidth; $newHeight = $srcHeight;}

	$newImg = imagecreatetruecolor($newWidth, $newHeight);
	imagealphablending($newImg, false);

	if($degrees == 90){for($x = 0; $x < $srcWidth; $x ++){for($y = 0; $y < $srcHeight; $y ++){imagesetpixel($newImg, $newWidth - $y - 1, $x, imagecolorat($srcImg, $x, $y));};};}
	elseif($degrees == 180){for($x = 0; $x < $srcWidth; $x ++){for($y = 0; $y < $srcHeight; $y ++){imagesetpixel($newImg, $newWidth - $x - 1, $newHeight - $y - 1, imagecolorat($srcImg, $x, $y));};};}
	elseif($degrees == 270){for($x = 0; $x < $srcWidth; $x ++){for($y = 0; $y < $srcHeight; $y ++){imagesetpixel($newImg, $y, $newHeight - $x - 1, imagecolorat($srcImg, $x, $y));};};}
	else{$newImg = $srcImg;}
	return $newImg;
}

if(isset($_REQUEST['imageSrc'])){

	$te = explode("themes",$_SERVER['SCRIPT_FILENAME']);
	$tf = explode("admin",trim($te[1])); 
	$themeName = str_replace("\\","",str_replace("\\\\","",str_replace("/","",str_replace("////","",$tf[0]))));
	

$pp = explode($themeName,FilterPath()); 
foreach($_REQUEST as $key => $val){$$key = $val;}
if(!isset($imageQuality)){$imageQuality = 90;}
$tmp = explode("/", $imageSrc);
$fileName = $tmp[count($tmp)-1];


$tmp = explode(".", $imageSrc);
$extension = strtolower($tmp[count($tmp)-1]);

if($extension == "jpg" || $extension == "jpeg"){
	$orig_image = imagecreatefromjpeg($imageSrc);
}
elseif($extension == "png"){
	$orig_image = imagecreatefrompng($imageSrc);
}
elseif($extension == "gif"){
	$orig_image = imagecreatefromgif($imageSrc);
}
else{
	echo "Unsupported file format... ({$extension})";
	exit();
}

$orig_width = imagesx($orig_image);
$orig_height = imagesy($orig_image);

$new_width = round($orig_width * $imageScale);
$new_height = round($orig_height * $imageScale);

$new_image = imagecreatetruecolor($new_width, $new_height);
imagecopyresampled($new_image, $orig_image, 0, 0, 0, 0, $new_width, $new_height, $orig_width, $orig_height);

$new_image = premiumpress_rotateImage($new_image, $imageRotation);

$cropped_image = imagecreatetruecolor($cropWidth, $cropHeight);
imagecopyresized($cropped_image, $new_image, 0, 0, $cropStartX, $cropStartY, $new_width, $new_height, $new_width, $new_height);

// generate cropped image
ob_start();
imagejpeg($cropped_image, NULL, $imageQuality);
$contents = ob_get_contents();
ob_end_clean();

if($saveAs == "local"){

	// Start sending headers
	header("Pragma: public"); // required
	header("Expires: 0");
	header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
	header("Cache-Control: private",false); // required for certain browsers
	header("Content-Transfer-Encoding: binary");
	header("Content-Type: " . $mimetype);
	header("Content-Length: " . $filesize);
	header("Content-Disposition: attachment; filename=\"" . $fileName . "\";");

	echo $contents;
	exit();
}

else{
	if($saveAs == $imageSrc){

	$saveAs = $pp[0].$themeName."/thumbs/" . $fileName;
	
	}
	$file = fopen($saveAs, "w");
	fwrite($file, $contents);
	fclose($file);
}

?>

<a href="#" onclick="window.close();"style="color: #FF6633">Image save successful. Click here to close this window</a>

<?php  } ?>