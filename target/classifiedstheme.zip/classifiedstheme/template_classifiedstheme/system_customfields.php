<?php



/* ============================ PREMIUM PRESS CUSTOM FIELD FUNCTION ======================== */

if(!function_exists('get_custom_field')) {
	function get_custom_field($field) {
		global $post;
		$custom_field = get_post_meta($post->ID, $field, true);
		echo $custom_field;
	}
}

/* ============================ PREMIUM PRESS CUSTOM FIELD FUNCTION ======================== */

function premiumpress_customfields_box() {
	if( function_exists( 'add_meta_box' )) {

	add_meta_box( 'premiumpress_customfields_0', __( 'Listing Options', 'sp' ), 'premiumpress_classifiedstheme', 'post', 'normal', 'high' );
 
	
		add_meta_box( 'premiumpress_customfields_5', __( 'Article Options', 'sp' ), 'premiumpress_article', 'article_type', 'normal', 'high' );
	add_meta_box( 'premiumpress_customfields_7', __( 'FAQ Options', 'sp' ), 'premiumpress_faq', 'faq_type', 'normal', 'high' );

	}
}

/* ============================ PREMIUM PRESS CUSTOM FIELD FUNCTION ======================== */
 
function premiumpress_classifiedstheme(){

	global $post;
	
	$ThisPack 	= get_post_meta($post->ID, 'packageID', true);
	
 	$packdata 	= get_option("packages");
	$cf1 		= get_option("customfielddata"); 
 	$tdC =1;  
	
	$fea 		= get_post_meta($post->ID, 'featured', true);
	if($fea == "yes"){ $a1 = 'selected'; $a2=""; }else{$a1 = ''; $a2="selected"; } 


	// Use nonce for verification ... ONLY USE ONCE!
	echo '<input type="hidden" name="sp_noncename" id="sp_noncename" value="' . 
	wp_create_nonce( plugin_basename(__FILE__) ) . '" />';
	
	echo '<div id="premiumpress_box1" class="premiumpress_box premiumpress_box-100" style="width:680px !important;"><div class="premiumpress_boxin" style="width:680px !important;"><div class="header">
<h3 style="background:none;font-size:18px;margin-left:0px;padding-left:0px;"><img src="../wp-content/themes/classifiedstheme/images/premiumpress/h-ico/open alt.png" align="absmiddle"> Options</h3>							 
<ul>
	<li><a rel="premiumpress_tab1" href="#" class="active">Listing Data</a></li>
	<li><a rel="premiumpress_tab2" href="#">Custom Fields</a></li>
    <li><a rel="premiumpress_tab3" href="#">Image Setup</a></li>
    <li><a rel="premiumpress_tab4" href="#">Package Setup</a></li>
    <li><a rel="premiumpress_tab5" href="#">Extra</a></li> 
</ul>
</div>

<div id="premiumpress_tab1" class="content">';

	echo '<table width="100%"  border="0"><tr width="50%"><td valign="top">';
	
		echo '<label style="font-size:14px; line-height:30px;">' . __("<b>Item SKU</b> <small>(optional, used for CSV import/update)</small>", 'sp' ) . '</label><br />';
		echo '<input type="text" name="field[SKU]" value="'.get_post_meta($post->ID, 'SKU', true).'" style="font-size:14px;padding:5px; width:95%; background:#e7fff3;"/><br /><br />';
 
		echo '<label style="font-size:14px; line-height:30px;">' . __("<b>Featured Classified</b> <small>(yes/no, highlighted in search results)</small>", 'sp' ) . '</label><br />';
		echo '<select name="field[featured]" style="font-size:14px;padding:5px; width:95%; background:#e7fff3;">
		<option value="yes" '.$a1.'>yes - hightlight this listing</option>
		<option value="no" '.$a2.'>no</option></select><br /><br />';
		
		
		echo '<label style="font-size:14px; line-height:30px;">' . __("<b>Country</b> ", 'sp' ) . '</label><br />';
		
		
		
		$cntry = '  <select name="field[country]"  style="font-size:14px;padding:5px; width:95%; background:#e7fff3;">
				<option value="'.get_post_meta($post->ID, 'country', true).'" selected="selected">'.get_post_meta($post->ID, 'country', true).'
				</option>';
				$allCountriesQuery = "Select Name from wp_country";
				$resule = mysql_query($allCountriesQuery);
				while($data = mysql_fetch_assoc($resule)){
					$cntry .=  "<option value=\"".$data['Name']."\">".$data['Name']."</option>";
				}
				
				$cntry .= '</select>';
				
	echo $cntry;
			echo '</span>
			    </div><br/><br/>';
		echo '<label style="font-size:14px; line-height:30px;">' . __("<b>State</b> ", 'sp' ) . '</label><br />
		<input type="text" name="field[state]" value="'.get_post_meta($post->ID, 'state', true).'" style="font-size:14px;padding:5px; width:95%; background:#e7fff3;" /><br /><br />';
		echo '<label style="font-size:14px; line-height:30px;">' . __("<b>Price</b>  ", 'sp' ) . '</label><br />';
		echo get_option("currency_code").'<input type="text" name="field[price]" value="'.get_post_meta($post->ID, 'price', true).'" style="font-size:14px;padding:5px; width:95%; background:#e7fff3;"/><br /><br />';

	echo '</td><td width="50%" valign="top">';


	echo '<label style="font-size:14px; line-height:30px;">' . __("<b>Hits/View Counter</b> ", 'sp' ) . '</label><br />';
		echo '<input type="text" name="field[hits]" value="'.get_post_meta($post->ID, 'hits', true).'" style="font-size:14px;padding:5px; width:95%; background:#e7fff3;" /><br /><br />';
		
		echo '<label style="font-size:14px; line-height:30px;">' . __("<b>Map Location</b> (optional) ", 'sp' ) . '</label><br />';
		echo "<div style='padding-top:15px;'>&nbsp;</div>";
		echo '<input type="text" name="field[map_location]" value="'.get_post_meta($post->ID, 'map_location', true).'" style="font-size:14px;padding:5px; width:95%; background:#e7fff3;" /><br /><br />';
		
		
		
		echo '<label style="font-size:14px; line-height:30px;">' . __("<b>Zip Code</b> ", 'sp' ) . '</label><br />';
		echo '<input type="text" name="field[zip]" value="'.get_post_meta($post->ID, 'zip', true).'" style="font-size:14px;padding:5px; width:95%; background:#e7fff3;" /><br /><br />';
		
		echo '<label style="font-size:14px; line-height:30px;">' . __("<b>City</b> ", 'sp' ) . '</label><br />';
		//
		//echo '<input type="text" name="field[city]" value="'.get_post_meta($post->ID, 'city', true).'" style="font-size:14px;padding:5px; width:95%; background:#e7fff3;" /><br /><br />';
		$allcityQuery = "Select Name from wp_city order by Name Asc";
				$cityData = mysql_query($allcityQuery);
		$display_city = '<select name="field[city]"  style="font-size:14px;padding:5px; width:95%; background:#e7fff3;">
				<option value="'.get_post_meta($post->ID, 'country', true).'" selected="selected">'.get_post_meta($post->ID, 'city', true).'
				</option>';
				
				while($data = mysql_fetch_assoc($cityData)){
					$display_city .=  "<option value=\"".$data['Name']."\">".$data['Name']."</option>";
				}
				$display_city .= '</select>';
		echo $display_city;
		
	echo '</td></tr></table>';

echo '</div>

<div id="premiumpress_tab2" class="content">';

	echo '<table width="100%"  border="0">';


	for($i=1; $i < 20; $i++){ if($cf1[$i]['enable'] ==1){

		if($tdC == 1){ echo '<tr> ';}

			echo '<td width="50%" valign="top">';
		
			$Value= get_post_meta($post->ID, $cf1[$i]['key'], true);
		
			echo '<label style="font-size:14px; line-height:30px;"><b>' . stripslashes($cf1[$i]['name'] ) . '</b></label><br />';
		
			switch($cf1[$i]['type']){
				 case "textarea": {
					echo '<textarea class="adfields" name="'.$cf1[$i]['key'].'" style="font-size:14px;padding:5px; width:95%; background:#e7fff3; height:60px;">';
					echo $Value;
					echo '</textarea>';
				 } break;
				 case "list": {
					$listval = $Value; 
					$listvalues = explode(",",$cf1[$i]['value']);
					echo '<select name="'.$cf1[$i]['key'].'" style="font-size:14px;padding:5px; width:95%; background:#e7fff3;">';
					foreach($listvalues as $value){ 
						if($listval ==  $value){ 
						echo '<option value="'.$value.'" selected>'.$value.'</option>'; 
						}else{
						echo '<option value="'.$value.'">'.$value.'</option>'; 
						}
					}
					echo '</select>';		
		
				 } break;
				 default: {
					echo '<input type="text" style="font-size:14px;padding:5px; width:95%; background:#e7fff3;" name="'.$cf1[$i]['key'].'" size="55" maxlength="100" value="'.$Value.'">';
				 }	
				}
	
			echo '<br /><br />';	
		echo '</td>';

		echo '<input type="hidden"  name="custom['.$i.'][name]" value="'.$cf1[$i]['key'].'" />';

		if($tdC == 2){ echo '</tr> '; $tdC=1; }else{ $tdC++; }
	 	 
		

		}
	}


echo '</table>';

echo '</div>

<div id="premiumpress_tab3" class="content">';

	echo '<div id="DisplayImages" style="display:none;"></div><input type="hidden" id="searchBox1" name="searchBox1" value="" /> <table width="100%"  border="0"><tr width="50%"><td valign="top">';

		echo '<label style="font-size:14px; line-height:30px;">' . __("<b>Main Image</b>", 'sp' ) . '</label><br />';
		echo '<input type="text" name="field[image]" id="g_image" value="'.get_post_meta($post->ID, 'image', true).'" style="font-size:14px;padding:5px; width:95%; background:#e7fff3;"/><br /><br />';
		?>
		<a href='javascript:void(0);' onClick="toggleLayer('DisplayImages'); add_image_next(0,'<?php echo get_option("imagestorage_path"); ?>','<?php echo get_option("imagestorage_link"); ?>','g_image');"><img src="<?php echo $GLOBALS['template_url']; ?>/images/premiumpress/led-ico/find.png" align="absmiddle"> View Uploaded Images</a> <a href="admin.php?page=images" target="_blank" style="margin-left:50px;"><img src="<?php echo $GLOBALS['template_url']; ?>/images/premiumpress/led-ico/monitor.png" align="absmiddle"> Upload Image </a> 
		<br />
		<?php

		echo '<label style="font-size:14px; line-height:30px;">' . __("<b>Featured Image</b> <small>(used for homepage slider)</small>", 'sp' ) . '</label><br />';
		echo '<input type="text" name="field[featured_image]" id="g_featured_image" value="'.get_post_meta($post->ID, 'featured_image', true).'" style="font-size:14px;padding:5px; width:95%; background:#e7fff3;"/><br /><br />';

		?>
		<a href='javascript:void(0);' onClick="toggleLayer('DisplayImages'); add_image_next(0,'<?php echo get_option("imagestorage_path"); ?>','<?php echo get_option("imagestorage_link"); ?>','g_featured_image');"><img src="<?php echo $GLOBALS['template_url']; ?>/images/premiumpress/led-ico/find.png" align="absmiddle"> View Uploaded Images</a>  <a href="admin.php?page=images" target="_blank" style="margin-left:50px;"><img src="<?php echo $GLOBALS['template_url']; ?>/images/premiumpress/led-ico/monitor.png" align="absmiddle"> Upload Image </a>
		<br />
		<?php

	echo '</td><td width="50%" valign="top">';

		echo '<label style="font-size:14px; line-height:30px;">' . __("<b>Gallery Images</b> <small>(seperate multiple images with a comma)</small>", 'sp' ) . '</label><br />';
		echo '<textarea name="field[images]" id="g_images" style="font-size:10px;padding:5px; width:95%; background:#e7fff3; height:100px;" />'.str_replace(",",",\n",get_post_meta($post->ID, 'images', true)).'</textarea><br /><br />';
 
		?>
		<a href='javascript:void(0);' onClick="toggleLayer('DisplayImages'); add_image_next(0,'<?php echo get_option("imagestorage_path"); ?>','<?php echo get_option("imagestorage_link"); ?>','g_images');"><img src="<?php echo $GLOBALS['template_url']; ?>/images/premiumpress/led-ico/find.png" align="absmiddle"> View Uploaded Images</a>  <a href="admin.php?page=images" target="_blank" style="margin-left:50px;"><img src="<?php echo $GLOBALS['template_url']; ?>/images/premiumpress/led-ico/monitor.png" align="absmiddle"> Upload Image </a>
		<br />
		<?php

	echo '</td></tr></table>';
	
echo '</div>

<div id="premiumpress_tab4" class="content">';

	echo '<table width="100%"  border="0"><tr width="50%"><td valign="top">';

		echo '<label style="font-size:14px; line-height:30px;">' . __("<b>Package</b>", 'sp' ) . '</label><br />';

		echo '<select name="field[packageID]" style="font-size:14px;padding:5px; width:95%; background:#e7fff3;">
		<option value="1"'; if($ThisPack ==1){ echo 'selected'; } echo '>'.$packdata[1]['name'].'</option>
		<option value="2"'; if($ThisPack ==2){ echo 'selected'; } echo '>'.$packdata[2]['name'].'</option>
		<option value="3"'; if($ThisPack ==3){ echo 'selected'; } echo '>'.$packdata[3]['name'].'</option>
		<option value="4"'; if($ThisPack ==4){ echo 'selected'; } echo '>'.$packdata[4]['name'].'</option>
		<option value="5"'; if($ThisPack ==5){ echo 'selected'; } echo '>'.$packdata[5]['name'].'</option>
		<option value="6"'; if($ThisPack ==6){ echo 'selected'; } echo '>'.$packdata[6]['name'].'</option>
		<option value="7"'; if($ThisPack ==7){ echo 'selected'; } echo '>'.$packdata[7]['name'].'</option>
		<option value="8"'; if($ThisPack ==8){ echo 'selected'; } echo '>'.$packdata[8]['name'].'</option>
		</select><br /><br />';

	echo '</td><td width="50%" valign="top">';

		echo '<label style="font-size:14px; line-height:30px;">' . __("<b>Day's Till Expire</b> (numeric value)", 'sp' ) . '</label><br />';
		echo '<input type="text" name="field[expires]" value="'.get_post_meta($post->ID, 'expires', true).'" style="font-size:14px;padding:5px; width:95%; background:#e7fff3;" /><br /><br />';

 
 
	echo '</td></tr></table>';
	
echo '</div>

<div id="premiumpress_tab5" class="content">';

	echo '<table width="100%"  border="0"><tr width="50%"><td valign="top">';

	 
 
		echo '<label style="font-size:14px; line-height:30px;">' . __("<b>Email Address</b> (used for the claim listing feature)", 'sp' ) . '</label><br />';
		echo '<input type="text" name="field[email]" value="'.get_post_meta($post->ID, 'email', true).'" style="font-size:14px;padding:5px; width:95%; background:#e7fff3;" /><br /><br />';

	echo '</td><td width="50%" valign="top">';


 
 
	echo '</td></tr></table>';
	
echo '</div>

</div>



</div></div>
<div class="clear"></div>
';

} 
 
 
function premiumpress_faq(){

	global $post;

	$ThisPack = get_post_meta($post->ID, 'packageID', true);
 	$packdata = get_option("packages");

	// Use nonce for verification ... ONLY USE ONCE!
	echo '<input type="hidden" name="sp_noncename" id="sp_noncename" value="' . 
	wp_create_nonce( plugin_basename(__FILE__) ) . '" />';


	echo '<div id="DisplayImages" style="display:none;"></div><input type="hidden" id="searchBox1" name="searchBox1" value="" /> <table width="100%"  border="0"><tr width="50%"><td valign="top">';

		echo '<label style="font-size:14px; line-height:30px;">' . __("<b>Display Image</b> (example: imagename.jpg or http://../imagename.jpg)", 'sp' ) . '</label><br />';
		echo '<input type="text" name="field[image]" id="g_image" value="'.get_post_meta($post->ID, 'image', true).'" style="font-size:14px;padding:5px; width:95%; background:#e7fff3;"/><br /><br />';
		?>
		<a href='javascript:void(0);' onClick="toggleLayer('DisplayImages'); add_image_next(0,'<?php echo get_option("imagestorage_path"); ?>','<?php echo get_option("imagestorage_link"); ?>','g_image');"><img src="<?php echo $GLOBALS['template_url']; ?>/images/premiumpress/led-ico/find.png" align="absmiddle"> View Uploaded Images</a> <a href="admin.php?page=images" target="_blank" style="margin-left:50px;"><img src="<?php echo $GLOBALS['template_url']; ?>/images/premiumpress/led-ico/monitor.png" align="absmiddle"> Upload Image </a> 
		<br />
		<?php 

	
	echo '</td><td width="50%" valign="top">';

	echo '<label style="font-size:14px; line-height:30px;">' . __("<b>Search Description</b>  ", 'sp' ) . '</label><br />';
		echo '<input type="text" name="field[post_excerpt]" value="'.get_post_meta($post->ID, 'post_excerpt', true).'" style="font-size:14px;padding:5px; width:95%; background:#e7fff3;" /><br /><br />';




	echo '</td></tr></table>';

} 
 
function premiumpress_article(){

	global $post;

	$ThisPack = get_post_meta($post->ID, 'packageID', true);
 	$packdata = get_option("packages");

	// Use nonce for verification ... ONLY USE ONCE!
	echo '<input type="hidden" name="sp_noncename" id="sp_noncename" value="' . 
	wp_create_nonce( plugin_basename(__FILE__) ) . '" />';


	echo '<div id="DisplayImages" style="display:none;"></div><input type="hidden" id="searchBox1" name="searchBox1" value="" /> <table width="100%"  border="0"><tr width="50%"><td valign="top">';

		echo '<label style="font-size:14px; line-height:30px;">' . __("<b>Display Image</b> (example: imagename.jpg or http://../imagename.jpg)", 'sp' ) . '</label><br />';
		echo '<input type="text" name="field[image]" id="g_image" value="'.get_post_meta($post->ID, 'image', true).'" style="font-size:14px;padding:5px; width:95%; background:#e7fff3;"/><br /><br />';
		?>
		<a href='javascript:void(0);' onClick="toggleLayer('DisplayImages'); add_image_next(0,'<?php echo get_option("imagestorage_path"); ?>','<?php echo get_option("imagestorage_link"); ?>','g_image');"><img src="<?php echo $GLOBALS['template_url']; ?>/images/premiumpress/led-ico/find.png" align="absmiddle"> View Uploaded Images</a> <a href="admin.php?page=images" target="_blank" style="margin-left:50px;"><img src="<?php echo $GLOBALS['template_url']; ?>/images/premiumpress/led-ico/monitor.png" align="absmiddle"> Upload Image </a> 
		<br />
		<?php 

	
	echo '</td><td width="50%" valign="top">';

	echo '<label style="font-size:14px; line-height:30px;">' . __("<b>Search Description</b>  ", 'sp' ) . '</label><br />';
		echo '<input type="text" name="field[short_desc]" value="'.get_post_meta($post->ID, 'short_desc', true).'" style="font-size:14px;padding:5px; width:95%; height:60px; background:#e7fff3;" /><br /><br />';




	echo '</td></tr></table>';

} 

 

/* ============================ PREMIUM PRESS CUSTOM FIELD FUNCTION ======================== */

function premiumpress_postdata($post_id, $post) {
	
	if ( !wp_verify_nonce( $_POST['sp_noncename'], plugin_basename(__FILE__) )) {
		return $post->ID;
	}

	// Is the user allowed to edit the post or page?
	if ( 'page' == $_POST['post_type'] ) {
		if ( !current_user_can( 'edit_page', $post->ID ))
		return $post->ID;
	} else {
		if ( !current_user_can( 'edit_post', $post->ID ))
		return $post->ID;
	}

	$mydata = array();
 
	// CUSTOM FIELDS
	if(is_array($_POST['field']) ){
		foreach($_POST['field'] as $key=>$val){
			if(substr($val,0,1) == ","){
				$mydata[$key] = substr($val,1);	
			}else{
				$mydata[$key] = $val;	
			}						
		}	
	} 

	// CUSTOM FIELDS
	if(is_array($_POST['custom']) ){
		foreach($_POST['custom'] as $in_array){
	
			$mydata[$in_array['name']] = $_POST[$in_array['name']];				
		}	
	} 
 
	
	foreach ($mydata as $key => $value) {
		if( $post->post_type == 'revision' ) return;
		$value = implode(',', (array)$value); 
		if(get_post_meta($post->ID, $key, FALSE)) { 
			update_post_meta($post->ID, $key, $value);
		} else { 
			add_post_meta($post->ID, $key, $value);
		}
		if(!$value) delete_post_meta($post->ID, $key);
	}

}

/* ============================ PREMIUM PRESS CUSTOM FIELD FUNCTION ======================== */

add_action('admin_menu', 'premiumpress_customfields_box');
add_action('save_post',  'premiumpress_postdata', 1, 2);


/* ============================ PREMIUM PRESS CUSTOM FIELD FUNCTION ======================== */

add_filter( 'manage_posts_columns', 'premiumpress_columns' );
add_action('manage_posts_custom_column', 'premiumpress_custom_column', 10, 2); //Just need a single function to add multiple columns

add_filter('manage_posts_columns', 'scompt_custom_columnsDP');

function scompt_custom_columnsDP($defaults) {

   // unset($defaults['comments']);
   unset($defaults['author']);
    unset($defaults['tags']);
 
    return $defaults;
}
function premiumpress_columns($defaults) {

    $defaults['pak'] 		= __('Package');
    $defaults['image'] 		= __('Display Image');

    return $defaults;
}


function premiumpress_custom_column($column_name, $post_id) {

    global $wpdb, $PPT;

	$PACKAGE_OPTIONS = get_option("packages"); 

    if( $column_name == 'pak' ) {

			$pak = get_post_meta($post_id, "packageID", true);
			if ( !empty( $pak ) ) {

				print strip_tags($PACKAGE_OPTIONS[$pak]['name']);
			} else {
				_e('No Package Set');  //No Taxonomy term defined
			}

	} else if( $column_name == 'image' ) {   //Adding 2nd column

 
			//if ( !empty( $img ) && strlen($img) > 2 ) {
				echo "<img src='".$PPT->Image($post_id,"url")."' style='max-height:80px'>";
			//} else {
			//	_e('<font color="red">No Image Set</font>');
			//}

	} else {
            echo '<i>'.$column_name.'</i>'; //Only 2 columns, blank now.
        }

}


 

?>