<?php 
/*
LAST UPDATED: 27th March 2011
EDITED BY: MARK FAIL
*/ 

get_header();

	
//$reandomPosts = query_posts('orderby=rand&posts_per_page=4&meta_key=featured_image');
    function cksubcat($cat_id){
	$ckSubCatQuery = mysql_query("select count(t.term_id) as numRows from wp_terms as t LEFT JOIN wp_term_taxonomy as tt ON t.term_id = tt.term_id where tt.taxonomy = 'category' and tt.parent = '".$cat_id."'") or die(mysql_error());
	$ckSubCat = mysql_fetch_assoc($ckSubCatQuery);
        if($ckSubCat['numRows'] > 0) {
	    return true;
        } else {
	    return false;
        }
    }

?>

<style>

</style>
<div class="main_wraper">
    	<div class="inner_wraper">
        	<div class="top_wraper">
            	<div class="box_wrper">
               			<div class="top_bx_wrpaer">
                        	<div class="bottom_bx_wrpaer">
                            	<div class="mid_bx_wrpaer">
                                	<div style="float:left; height: 230px; width: 260px; background-color:#FEFEFE;">
					<?php
					    $querystr = " Select p.ID, p.post_type, pm.meta_key, pm.meta_value from wp_posts as p RIGHT JOIN wp_postmeta as pm ON p.ID = pm.post_id where pm.meta_key='image' and p.post_type != 'article_type' order by RAND() LIMIT 4";
					    $reandomPosts = $wpdb->get_results($querystr, OBJECT);
						foreach($reandomPosts as $rkey=>$rval) {
						   
					?>
						    <div style="margin: 5px; float: left; width:116px; height:102px; border: 1px solid black;">
							<a href="<?php echo get_permalink($rval->ID); ?>/"><img src="<?php echo bloginfo("template_url"); ?>/thumbs/<?php echo $rval->meta_value; ?>" style="height:102px; width:116px;" title="<?php echo $rval->post_title; ?>"  /></a>
							
							
							
						    </div>
					<?php 	} ?>
					</div>
                                </div>
                            </div>
                        </div>
                </div>
                <div class="box_wrper">
               			<div class="top_bx_wrpaer">
                        	<div class="bottom_bx_wrpaer">
                            	<div class="mid_bx_wrpaer">
					<div style="float:left; height: 230px; width: 260px; background-color:#FEFEFE;">
					<?php
					    $recentPostQuery = "Select p.ID, p.post_type, pm.meta_key, pm.meta_value from wp_posts as p RIGHT JOIN wp_postmeta as pm ON p.ID = pm.post_id where pm.meta_key='image' and p.post_type != 'article_type' order by p.ID DESC";
					    $recentPost = $wpdb->get_results($recentPostQuery, OBJECT);
					    
					?>
					<div style="margin: 5px; float: left; border: 1px solid black;">
                                	<a href="<?php echo get_permalink($recentPost[0]->ID); ?>/"><img src="<?php echo bloginfo("template_url"); ?>/thumbs/<?php echo $recentPost[0]->meta_value; ?>" style="height:218px; width:245px;" title="<?php echo $recentPost[0]->post_title; ?>"  /></a>
					</div>
					</div>
                                </div>
                            </div>
                        </div>
                </div>
                <div class="box_wrper">
               			<div class="top_bx_wrpaer">
                        	<div class="bottom_bx_wrpaer">
                            	<div class="mid_bx_wrpaer">
                                	<img src="<?php bloginfo("template_url"); ?>/images/product.png" alt="" />
                                </div>
                            </div>
                        </div>
                </div>
            </div>
            <div class="sec_wraper">
            	<div class="left_bx_wraper">
		<?php
			$listCatQuery = "select t.term_id, t.name from wp_terms as t LEFT JOIN wp_term_taxonomy as tt ON t.term_id = tt.term_id where tt.taxonomy = 'category' and tt.parent = '0'";
			$listCat = $wpdb->get_results($listCatQuery, OBJECT);
			foreach($listCat as $k=>$v) {
			    if(cksubcat($v->term_id)) {
		?>
				<div class="daynmic_bx">
				    <div class="header_wrper">
					    <div class="left_green">
						<div class="right_green">
						    <div class="mid_green">
							    <strong><?php echo ucfirst($v->name); ?></strong>
						    </div>
						</div>
					    </div>
					    <div class="content_wraper">
						    <ul>
						    <?php
							$listSubCatQuery = "select t.name from wp_terms as t LEFT JOIN wp_term_taxonomy as tt ON t.term_id = tt.term_id where tt.taxonomy = 'category' and tt.parent = '".$v->term_id."' limit 6";
							$listSubCat = $wpdb->get_results($listSubCatQuery, OBJECT);
							foreach($listSubCat as $lsKey=>$lsVal) { 
						    ?>
							<li><a href="#"><?php echo $lsVal->name; ?></a></li>
						    <?php } ?>
						    </ul>
						<a href="#">See more</a>
					    </div>
				    </div>
				</div>
		    <?php   }
			}
		    ?>
                    
                    
                    
                </div>
                <div class="right_bx_wraper">
                	<img src="<?php bloginfo("template_url"); ?>/images/add_tise.png" alt="#" />
                    <img src="<?php bloginfo("template_url"); ?>/images/add_tise.png" alt="#" />
                </div>
                	
            </div>
        </div>
    </div>
    <div class="recent_items">
	<div class="title">
    	<span>Recently Listed Items</span><a href="#">See More</a>
    </div>
    <div class="image_holder">
    	<ul>
	    <?php $RecListItemQuery = " Select p.ID, p.post_type, pm.meta_key, pm.meta_value from wp_posts as p RIGHT JOIN wp_postmeta as pm ON p.ID = pm.post_id where pm.meta_key='image' and p.post_type != 'article_type' order by p.ID DESC LIMIT 16";
		    $RecListItems = $wpdb->get_results($RecListItemQuery, OBJECT);
		    
		    foreach($RecListItems as $key=>$val) {
			
			
	    ?>
		<li>
		    <div class="img_container">
			<a href="<?php echo get_permalink($val->ID); ?>">
			    <img src="<?php bloginfo("template_url"); ?>/thumbs/<?php echo $val->meta_value; ?>" alt="Item1" />
			</a>
		    </div>
		</li>
	    <?php
		    }
	    ?>
        </ul>
    </div>
<?php get_footer(); ?>