<?php
/*
LAST UPDATED: 27th March 2011
EDITED BY: MARK FAIL
*/
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>

<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />

<title><?php wp_title('&laquo;', true, 'right'); ?> <?php bloginfo('name'); ?></title>    


<?php /*------------------- JAVASCRIPT INCLUDES ----------------------*/ ?>
<?php wp_deregister_script( 'jquery' ); ?>
<script type="text/javascript" src="<?php echo PPT_PATH; ?>js/jquery.js"></script>
<?php wp_enqueue_script( 'jquery' ); ?>



<?php if(isset($post->ID) && $post->ID == '75') { ?>
<link rel="stylesheet" type="text/css" href="<?php echo get_bloginfo("template_url"); ?>/ajax-file-upload/styles.css" />
<script type="text/javascript" src="<?php echo get_bloginfo("template_url"); ?>/ajax-file-upload/js/ajaxupload.3.5.js" ></script>
<script type="text/javascript">
jQuery(function(){
	var btnUpload=jQuery('#upload');
	var status=jQuery('#status');
	new AjaxUpload(btnUpload, {
		action: '<?php echo get_bloginfo("template_url"); ?>/ajax-file-upload/upload-file.php',
		name: 'uploadfile',
		onSubmit: function(file, ext) {
			 if (! (ext && /^(jpg|png|jpeg|gif)$/.test(ext))) {
				// extension is not allowed 
				status.text('Only JPG, PNG or GIF files are allowed');
				return false;
			}
			jQuery('#status').html('<img src="<?php echo get_bloginfo("template_url"); ?>/uploads/ajax-loader.gif" />');
		},
		onComplete: function(file, response) {
			var str;
			//On completion clear the status
			status.text('');
			//Add uploaded file to list
			if(response==="success") {
				str = '<div class="img_container"> <div class="img-area"> <img src="<?php echo get_bloginfo("template_url"); ?>/uploads/'+file+'" alt="" style="height:100px; width: 150px;" /></div> <div class="img-text">'+file+'</div></div>';
				jQuery('div#files').append(str).addClass('success');
			} else {
				str = 'File already exist';
				jQuery('div#duplicateFileMsg').hide().html('File already exist.').fadeIn('slow').delay(2000).hide(1);
			}
		}
	});
});
	//var sub_cat_div = document.getElementById('subCatDiv');
	//var cat_opt_val_div = document.getElementById('catOptValDiv');
	//var detail_div = document.getElementById('details');
	function checkSubCat(id) {
		var catId;
		catId = jQuery('#'+id).val()
		if(catId == "") {
			if(jQuery("#catOptValDiv").is(':hidden')  == false) {
				jQuery("#catOptValDiv").hide();
			}
			if(jQuery("#details").is(':hidden')  == false) {
				jQuery("#details").hide();
			}
			if(jQuery("#subCatDiv").is(':hidden')  == false) {
				jQuery("#subCatDiv").hide();
			}
			alert("Please select category");
		} else if(catId == "none") {
			if(jQuery("#catOptValDiv").is(':hidden')  == false) {
				jQuery("#catOptValDiv").hide();
			}
			if(jQuery("#details").is(':hidden')  == false) {
				jQuery("#details").hide();
			}
			alert("Please select category");
		} else {
			jQuery.post("<?php echo get_bloginfo('template_url'); ?>/custom_ajax.php", { categoryId: catId, action: 'check_sub_categories' },
			function( returnData ) {
				if(returnData == 1) {
					getSubCategories(id);
				} else {
					getCaTOptVal(id);
				}
			});
		}
	}
	
	function ckParentId(id,type) {
		var catId;
		catId = jQuery('#'+id).val();
		jQuery.post("<?php echo get_bloginfo('template_url'); ?>/custom_ajax.php", { categoryId: catId, action: 'return_sub_categories' },
		function( returnData ) {
				if(returnData == '0') {
					if(jQuery("#subCatDiv").is(':hidden')  == false) {
						jQuery("#subCatDiv").html("");
					}
				}
		});
	}
		
	function getSubCategories(id) {
		var catId = jQuery('#'+id).val();
		jQuery.post("<?php echo get_bloginfo('template_url'); ?>/custom_ajax.php", { categoryId: catId, action:'get_sub_category' },
		function(responseData) {
			
			if(jQuery("#catOptValDiv").is(':hidden')  == false) {
				jQuery("#catOptValDiv").hide();
			}
			
			if(jQuery("#details").is(':hidden')  == false) {
				jQuery("#details").hide();
			}
			//alert(jQuery("#subCatDiv").is(':hidden'));
			if(jQuery("#subCatDiv").is(':hidden')) {
				jQuery("#subCatDiv").show();
			}
			jQuery("#subCatDiv").html(responseData);
		});
	}
	
	function getCaTOptVal(id) {
		var catId = jQuery('#'+id).val();
		jQuery.post("<?php echo get_bloginfo('template_url'); ?>/custom_ajax.php", { categoryId: catId },
		function( rData ) {
			if(rData != "") {
				var tmArr = new Array();
				tmArr = rData.split("[exp_data]");
				ckParentId(id,'No');
				if(jQuery("#catOptValDiv").is(':hidden')) {
					jQuery("#catOptValDiv").show();
				}
				
				if(jQuery("#details").is(':hidden')) {
					jQuery("#details").show();
				}
				jQuery("#catOptValDiv").html(tmArr[0]);
				if(tmArr[1] != "") {
					jQuery("#details").html(tmArr[1]);
				}
			} else {
				var tmArr = new Array();
				tmArr[0] = "";
				tmArr[1] = "";
				jQuery("#catOptValDiv").html(tmArr[0]);
				//document.getElementById("catOptValDiv").innerHTML = tmArr[0];
				jQuery("#details").html(tmArr[1]);
				//document.getElementById("details").innerHTML = tmArr[1];
			}
		});
	}
	function ckValData(theFormObj) {
		var i = 0;
		var flag =0;
		var value;
		var cls_exist;
		jQuery('#post_an_ad').find(':input').each(function() {
			//alert(jQuery('.ad_price').attr("checked"));
			value = jQuery("input[@name=ad_price]:checked").val();
			//alert(value);
			cls_exist = jQuery('.ad_price').hasClass('ad_price');
			//alert(cls_exist);
			if(!value && cls_exist) {
				flag = 1;
				jQuery("#price_container").css('border-color', '#FF0000');
			}
			//alert(jQuery(this).val());
			if(jQuery(this).val() == "" || jQuery(this).val() == 'none') {
				if(jQuery(this).attr('class') == 'required_field') {
					flag = 1;
					jQuery(this).css('border-color', '#FF0000');
					if(i == 0) {
						jQuery(this).focus();
					}
				i++;
				}
			} else {
				jQuery(this).css('border-color', '#ECEDED');
			}
		});
		if(flag == 0)
			jQuery('#post_an_ad').submit();
	}
			
	function checkImgEmpty(ahor_obj) {
		//alert(ahor_obj);
		//alert(jQuery("#files").html());
		if(jQuery("#files").html() == "") {
			jQuery("#upload").css('border-color', '#FF0000');
			return false;
		}
		//var a = "<?php echo get_bloginfo('url'); ?>/?page_id=75&act=s3";
		
	}
</script>
<?php } ?>
<?php /*------------------- HOME PAGE INCLUDES ----------------------*/  ?>


<?php if(is_home()) { ?>
	<script type='text/javascript' src='<?php echo PPT_PATH; ?>js/jquery.siteFeature.js'></script>
	<link rel="stylesheet" href="<?php echo PPT_PATH; ?>css/css.fslider.css" type="text/css" media="screen" />
	<script type="text/javascript">$(document).ready(function(){$('#preFeature').siteFeature();	}); </script>
<?php } ?>

<?php /*------------------- LINK INCLUDES ----------------------*/ ?>

<link rel="stylesheet" type="text/css" href="<?php echo PPT_PATH; ?>css/css.premiumpress.css" media="screen" />
<link rel="stylesheet" href="<?php echo $GLOBALS['template_url']; echo "/template_".strtolower(PREMIUMPRESS_SYSTEM)."/styles.css"; ?>" type="text/css" media="screen" />

<link rel="stylesheet" href="<?php echo $GLOBALS['template_url']; ?>/themes/<?php $ThisTheme = $GLOBALS['premiumpress']['theme'];  if(strlen($ThisTheme) < 2){ $ThisTheme = strtolower(PREMIUMPRESS_SYSTEM)."_default"; } echo $ThisTheme;  ?>/css/styles.css" type="text/css"  />
<link rel="stylesheet" href="<?php echo $GLOBALS['template_url']; ?>/themes/<?php $ThisTheme = $GLOBALS['premiumpress']['theme'];  if(strlen($ThisTheme) < 2){ $ThisTheme = strtolower(PREMIUMPRESS_SYSTEM)."_default"; } echo $ThisTheme;  ?>/css/customRightSideBar.css" type="text/css"  />

<link rel="shortcut icon" href="<?php echo get_option("faviconLink"); ?>" type="image/x-icon" />
<?php if($GLOBALS['premiumpress']['display_themecolumns'] =="3" && !isset($GLOBALS['nosidebar']) && !isset($GLOBALS['nosidebar-left']) ){ ?>
<link rel="stylesheet" type="text/css" href="<?php echo PPT_PATH; ?>css/css.3columns.css" media="screen" />
<?php } ?>    
<?php /*------------------- PACKAGES PAGE ----------------------*/ ?>

<?php if(isset($GLOBALS['tpl-add'])){ ?>
<link rel="stylesheet" type="text/css" href="<?php echo PPT_PATH; ?>css/css.packages.css" media="screen" />  
<!--[if IE]>
	<script src="<?php echo PPT_PATH; ?>/js/html5.js"></script>
<![endif]-->

<script type="text/javascript" src="<?php echo $GLOBALS['template_url']; ?>/PPT/ajax/actions.js"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['template_url']; ?>/PPT/js/jquery.wwiconified.js"></script>
<link rel="stylesheet" href="<?php echo $GLOBALS['template_url']; ?>/PPT/js/jquery.wwiconified1.css" media="screen" type="text/css" />
<?php } ?>
<?php /*------------------- SINGLE PAGE ----------------------*/ ?>

<?php if(is_single()){ $GLOBALS['mapType'] = get_option("display_googlemaps"); if($GLOBALS['mapType'] == "yes2" && strlen(get_post_meta($post->ID, "map_location", true)) > 2){ ?>
	<link rel="stylesheet" type="text/css" href="<?php echo PPT_PATH; ?>css/css.maps.css" media="screen" />  
    <script src="http://maps.google.com/maps?file=api&amp;v=2&amp;sensor=true&amp;key=<?php echo get_option("google_maps_api"); ?>" type="text/javascript"></script> 
    <script type='text/javascript' src='<?php echo PPT_PATH; ?>js/jquery.maps.js'></script> 
    
        <script type="text/javascript"> 
            window.onload = function(){
                var mymap = new MeOnTheMap({
                    container: "map_sidebar2",
                    html: '<center><?php echo $post->post_title ?></center>',
                    address: "<?php echo get_post_meta($post->ID, "map_location", true); ?>",
                    zoomLevel: 13
                });
 
                mymap.adjustMapCenter({
                    x: 0,
                    y: -80
                });
			 
				
            } 
        </script>
    
<?php  } } ?>
    
<?php echo stripslashes(get_option("google_webmaster_code")); ?>

<?php wp_head(); ?> 

<?php
	
	if($_REQUEST['page_id'] == "102" || $_REQUEST['page_id'] == "99" || $_REQUEST['page_id'] == "104" || is_home()) {
?>
	<script type="text/javascript" src="<?php echo PPT_PATH; ?>js/jquery.validate.js"></script>
	<script type="text/javascript" language="javascript">
		jQuery.validator.methods.equal = function(value, element, param) {
			if(value == param)
				return false;
				return true;
		};
		jQuery.validator.setDefaults({
				errorPlacement: function(error, element) {
				    error.appendTo('#invalid-' + element.attr('id'));
				}
		});
		
		jQuery(document).ready(function() {
			// validate signup form on keyup and submit
			jQuery("#customeKeySearch").validate({
				rules: {
					custom_search: {
						required: true,
						equal: "Ex. Red, Leather, GPS"
					}
				},
				messages: {
					custom_search: {
						required: "Please enter keyword.",
						equal: "Please enter keyword."
					}
				}
			});
			
			jQuery("#priceSearch").validate({
				rules: {
					min_price: {
						required: true,
						equal: "Min. Price"
					},
					max_price: {
						required: true,
						equal: "Max. Price"
					}
				},
				messages: {
					min_price: {
						required: "Enter min price.",
						equal: "Enter min price."
					},
					max_price: {
						required: "Enter max price.",
						equal: "Enter max price."
					}
				}
			});
			jQuery("#locationSearch").validate({
				rules: {
					location_search: "required"
				},
				messages: {
					location_search: "Please enter zipcode."
				}
			});
			
		});
		//jQuery(document).ready(function() { 
		//	
		//});
	</script>
<?php
	}
	
?>
</head> 
<?php //print_r($PPT); echo "<pre>"; print_r(get_included_files()); echo "</pre>"; ?>
<body <?php if(is_home()){ print "id='PPTHomePage'"; }elseif(is_single()){ print "id='PPTSinglePage-".$post->post_type."'"; }elseif(is_page()){ print "id='PPTPage'"; } ?>>
	<div class="wrapper w_960"> 
		<div id="header" class="full">
			<?php /* <div id="hpages">
			    <ul> 
			     <?php echo $PPT->Pages(); ?>
			    <li><b><a href="<?php echo $GLOBALS['bloginfo_url']; ?>/" title="<?php bloginfo('name'); ?>"><?php echo SPEC($GLOBALS['_LANG']['_home']) ?></a></b></li>
			    </ul>
			</div> */?>
			<div class="clearfix"></div>
			<div class="f_half left" id="logo">
				<a href="<?php echo $GLOBALS['bloginfo_url']; ?>/" title="<?php bloginfo('name'); ?>">
					<img src="<?php echo $PPT->Logo(); ?>" alt="<?php bloginfo('name'); ?>" />
				</a>
			</div>
			<div class="left padding5" id="banner">
			     <?php //echo $PPT->Banner("top"); ?>
			</div>
			<div class="clearfix"></div>
		</div>
		<?php /* Commented by shavi on Mar,13 2012
		<div id="menudrop">
			<div class="full">
				<?php if(has_nav_menu('PPT-CUSTOM-MENU-PAGES')){ wp_nav_menu( array( 'theme_location' => 'PPT-CUSTOM-MENU-PAGES', 'depth'=>'1', 'before'=>'',  'after'=>'', 'menu_class' => 'menu' ) ); }else{ ?>
					<ul class="menu">
					    <?php echo $ThemeDesign->LAY_NAVIGATION(); ?>
					</ul>
				<?php } ?>
			</div> 
		</div> */ ?>
        

        <div class="full">
        <div id="submenubar">
            <form method="get"  action="<?php echo $GLOBALS['bloginfo_url']; ?>/" name="searchBox" id="searchBox">
              <table width="100%" border="0" id="SearchForm">
              <tr>
                <td><input style="width: 250px;" type="text" value="<?php echo SPEC($GLOBALS['_LANG']['_head1']) ?>" name="s" id="s" onfocus="this.value='';"/></td>
                <td style="padding:0px 20px; "><select id="catsearch" name="cat"><option value="">---------</option><?php echo $PPT->CategoryList(); ?></select></td>
                <td><div class="searchBtn" onclick="document.searchBox.submit();"> &nbsp;</div> </td>
                <td ><?php if(get_option("display_advanced_search") ==1){ ?><div id="sadvanced"><a href="javascript:void();" onClick="$('#AdvancedSearchBox').show();"><small><?php echo SPEC($GLOBALS['_LANG']['_head2']) ?></small></a></div><?php } ?></td>
              </tr>
            </table>
            </form>
     
            <?php /* Commented by shavi on Mar,13 2012 
            <ul class="submenu_account">            
            <?php  if ( $user_ID ){ ?>
            <li><a href="<?php echo wp_logout_url(); ?>" title="<?php echo SPEC($GLOBALS['_LANG']['_head3']) ?>"><?php echo SPEC($GLOBALS['_LANG']['_head3']) ?></a></li>
            <li><a href="<?php echo $GLOBALS['premiumpress']['dashboard_url']; ?>" title="<?php echo SPEC($GLOBALS['_LANG']['_head4']) ?>"><?php echo SPEC($GLOBALS['_LANG']['_head4']) ?></a></li>
            <li><b><?php echo $current_user->user_login; ?></b></li>
            <?php  }else{ ?>
            
            <li><a href="<?php echo $GLOBALS['bloginfo_url']; ?>/wp-login.php" title="<?php echo SPEC($GLOBALS['_LANG']['_head5']) ?>"><?php echo SPEC($GLOBALS['_LANG']['_head5']) ?></a> |  <a href="<?php echo $GLOBALS['bloginfo_url']; ?>/wp-login.php?action=register" title="<?php echo SPEC($GLOBALS['_LANG']['_head6']) ?>"><?php echo SPEC($GLOBALS['_LANG']['_head6']) ?></a></li>
            
            <?php } ?>
            </ul>
	   */ ?>
        
         	<a href="<?php echo $GLOBALS['premiumpress']['submit_url']; ?>" id="submitButton" title="add classifieds"><img src="<?php echo $GLOBALS['template_url']; ?>/template_classifiedstheme/images/submitlisting.png" alt="add classifieds" /></a>
         
        </div>
	<div id="menudrop">
		<div class="full">
			<ul class="menu">
				<li>
					<b><a href="<?php echo $GLOBALS['bloginfo_url']; ?>/" title="<?php bloginfo('name'); ?>"><?php echo SPEC($GLOBALS['_LANG']['_home']) ?></a></b>
				</li>
				<?php echo $PPT->Pages(); ?>
			</ul>
			<div class="sett-stuff">
				<img src="<?php echo $GLOBALS['template_url']; ?>/template_classifiedstheme/images/sell-your-stuff-img.png" width="238" height="70" alt="" />
			</div>
		</div> 
	</div>
        
        
        </div>
        
 
		<div id="page" class="clearfix full">
        
        
        <?php if(get_option("display_advanced_search") ==1 ){  PPT_AdvancedSearch('preset-default');  } ?>
 
  
		<?php if(get_option("PPT_slider") =="s1"  && is_home() && !isset($_GET['s']) && !isset($_GET['search-class']) ){ echo $PPTDesign->SLIDER(); } ?> 
         
         
        
        <div id="content">
	