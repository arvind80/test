<?php

/*
LAST UPDATED: 27th March 2011
EDITED BY: MARK FAIL
*/
ob_start();
if($_GET['page_id'] == 13) {
	if ( !is_user_logged_in() ) {
		header("Location:".get_bloginfo("url")."/?page_id=210");
		exit;
	}	
}


get_header( ); ?> 

<div class="middleSidebar left">

	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
                                
    <h1><?php the_title(); ?></h1>
    
    <div class="entry">
    
    <?php the_content(); ?>     
    
    </div>		
    
    <?php endwhile; endif; ?>

</div>
 
 
<?php get_footer(); ?>