<?php 
/*
LAST UPDATED: 27th March 2011
EDITED BY: MARK FAIL
*/

if(!isset($GLOBALS['nosidebar'])){ get_sidebar(); } ?>
 
    </div> <!-- end CONTENT -->

</div> <!-- end SIDEBAR -->


</div>
    <div id="footer" class="clearfix full">
        <div class="w_960" style="margin:0 auto;">
	<div class="b_third_col col first_col" style="padding-left:15px;"> 
		    <p>Buying or selling anything? Find the best deals on new and used autos, electronics, real-estate and much more.</p>
	    <h2>Search by City</h2>
	    <div class="links">
		    <ul>
			<?php
			    //$tbl_country = $wpdb->prefix.country;
			    //$allCountryQuery = "select Name from ".$tbl_country." limit 0,25";
			    //$country_list = $wpdb->get_results($allCountryQuery, OBJECT);
			    ////echo "<pre>"; print_r($country_list); echo "</pre>";
			    //$i = 0;
			    //
			    //foreach($country_list as $key=>$value) { http://localhost/wordpress/?page_id=99
			?>
			    <li><a href="http://localhost/wordpress/?page_id=180&act=ser&data=Ontario">Ontario:</a></li>
			    <li><a href="http://localhost/wordpress/?page_id=180&act=ser&data=Barrie">Barrie</a> </li>
			    <li><a href="http://localhost/wordpress/?page_id=180&act=ser&data=Brantford">Brantford</a> </li>
			    <li><a href="http://localhost/wordpress/?page_id=180&act=ser&data=Guelph">Guelph</a> </li>
			    <li><a href="http://localhost/wordpress/?page_id=180&act=ser&data=Hamilton">Hamilton</a> </li>
			    <li><a href="http://localhost/wordpress/?page_id=180&act=ser&data=Kingston">Kingston</a> </li>
			    <li><a href="http://localhost/wordpress/?page_id=180&act=ser&data=Kitchener/Waterloo">Kitchener/Waterloo</a> </li>
			    <li><a href="http://localhost/wordpress/?page_id=180&act=ser&data=Oshawa">Oshawa</a> </li>
			    <li><a href="http://localhost/wordpress/?page_id=180&act=ser&data=Ottawa-Gatineau">Ottawa-Gatineau</a> </li>
			    <li><a href="http://localhost/wordpress/?page_id=180&act=ser&data=St. Catharines-Niagara">St. Catharines-Niagara</a> </li>
			    <li><a href="http://localhost/wordpress/?page_id=180&act=ser&data=Sudbury">Sudbury</a> </li>
			    <li><a href="http://localhost/wordpress/?page_id=180&act=ser&data=Toronto-GTA">Toronto-GTA</a> </li>
			    <li><a href="http://localhost/wordpress/?page_id=180&act=ser&data=Thunder Bay">Thunder Bay</a> </li>
			    <li><a href="http://localhost/wordpress/?page_id=180&act=ser&data=Windsor">Windsor</a> </li>
			    <li>
				<a href="http://localhost/wordpress/?page_id=180&act=ser&data=British Columbia" style="padding-right:10px;">British Columbia:</a><a href="http://localhost/wordpress/?page_id=180&act=ser&data=Abbotsford">Abbotsford</a>
			    </li>
			    
			    <li><a href="http://localhost/wordpress/?page_id=180&act=ser&data=Kelowna">Kelowna</a> </li>
			    <li><a href="http://localhost/wordpress/?page_id=180&act=ser&data=Vancouver">Vancouver</a> </li>
			    <li><a href="http://localhost/wordpress/?page_id=180&act=ser&data=Victoria">Victoria</a> </li>
			    <li><a href="http://localhost/wordpress/?page_id=180&act=ser&data=Nanaimo">Nanaimo</a> </li>
			    <li><a href="http://localhost/wordpress/?page_id=180&act=ser&data=Courtenay">Courtenay</a> </li>
			    <li>
				<a href="http://localhost/wordpress/?page_id=180&act=ser&data=Alberta" style="padding-right:10px;">Alberta:</a><a href="http://localhost/wordpress/?page_id=180&act=ser&data=Calgary">Calgary</a>
			    </li>
			    <li><a href="http://localhost/wordpress/?page_id=180&act=ser&data=Edmonton">Edmonton</a> </li>
			    <li><a href="http://localhost/wordpress/?page_id=180&act=ser&data=Lethbridge">Lethbridge</a> </li>
			    <li><a href="http://localhost/wordpress/?page_id=180&act=ser&data=Red Deer">Red Deer</a> </li>
			    <li>
				<a href="http://localhost/wordpress/?page_id=180&act=ser&data=Saskatchewan" style="padding-right:10px;">Saskatchewan:</a><a href="http://localhost/wordpress/?page_id=180&act=ser&data=Regina">Regina</a>
			    </li>
			    <li><a href="http://localhost/wordpress/?page_id=180&act=ser&data=Saskatoon">Saskatoon</a> </li>
			    <li>
				<a href="http://localhost/wordpress/?page_id=180&act=ser&data=Manitoba" style="padding-right:10px;">Manitoba:</a><a href="http://localhost/wordpress/?page_id=180&act=ser&data=Winnipeg">Winnipeg</a>
			    </li>
			    <li><a href="http://localhost/wordpress/?page_id=180&act=ser&data=Brandon">Brandon</a> </li>
			<?php
			    //$i++;
			    //}
			?>
		</ul>
	    </div>
	</div>
	<div class="clearfix"></div>
	<div class="full" id="copyright">
           <p style="padding:0px 0px 15px 15px !important;">&copy; 2012 Postme.ca.All rights reserved.</p>
        </div>
	    <?/*<div style="color: #FF0000; width: 100%;">
		<div id="message">
		    <div style="padding:15px  0px 10px 10px; font-size:11pt; font-weight:bold;">
			Buying or selling anything? Find the best deals on new and used autos, electronics, real-estate and much more.
		    </div>
		    <div style="padding:10px 0px 10px 10px; font-size:17pt; font-weight:bold;">
			Search by City
		    </div>
		    <div style="padding:10px 0px 10px 10px; font-size:11pt; font-weight:bold;">
			<div style="float:left: padding-left:10px;">
			<?php
			    $tbl_country = $wpdb->prefix.country;
			    $allCountryQuery = "select Name from ".$tbl_country." limit 0,29";
			    $country_list = $wpdb->get_results($allCountryQuery, OBJECT);
			    //echo "<pre>"; print_r($country_list); echo "</pre>";
			    $i = 0;
			    
			    foreach($country_list as $key=>$value) {
			?>
			    <div style="padding-right:8px; float:left;">
				<?php echo $value->Name; if($i!=(count($country_list)-1)) echo "|"; ?>
			    </div>
			
			</div>
		    </div>
		</div>
	    </div>*/ ?>
        <?php /* <div class="b_third_col col first_col" style="padding-left:15px;"> 
             <?php echo stripslashes(get_option("footer_text")); ?>
            </div> 
                            
            <?php $ArticleData = $PPT->Articles(10); if(strlen($ArticleData) > 5){ ?>
            <div class="b_third_col col"> 
                         
                <h3><?php echo SPEC($GLOBALS['_LANG']['_rarticles']) ?></h3>                
                <ul class="recentarticles"><?php echo $ArticleData; ?></ul>
            </div> 
            <?php } ?> 
                            
            <div class="b_third_col col last_col">                
               <br />
                <?php echo $PPT->Banner("footer");  ?>             
            </div> 
            
            
        <div class="clearfix"></div>
                        
        <div id="copyright" class="full">
            <p>&copy; <?php echo date("Y"); ?> <?php echo get_option("copyright"); ?> <?php $PPT->Copyright(); ?></p>
        </div> */ ?>
    </div> 
        
 

</div>  <!-- end WRAPPER -->

        

 

<?php /*------------------- JAVASCRIPT INCLUDES ----------------------*/ ?>

<script type="text/javascript" src="<?php echo $GLOBALS['template_url']; echo "/PPT/ajax/actions.js"; ?>"></script> 
<script type="text/javascript" src="<?php echo PPT_PATH; ?>js/custom.js"></script> 
<script type="text/javascript" src="<?php echo PPT_PATH; ?>js/validation.js"></script>
<script type="text/javascript" src="<?php echo $GLOBALS['template_url']; echo "/template_".strtolower(PREMIUMPRESS_SYSTEM)."/js/_defaults.js" ?>"></script>

<?php /*------------------- HOME PAGE -----------------------*/ ?>

<?php if(isset($GLOBALS['s2'])){ ?>
<script src="<?php echo PPT_PATH; ?>js/jquery.s3Slider.js" type="text/javascript"></script> 
<script type="text/javascript">	$(document).ready(function() {	$('#featured-item').s3Slider({timeOut: 6000	});}); </script> 
<?php } ?>


<?php /*------------------- SINGLE PAGE -----------------------*/ ?>

<?php if(is_single()){ ?>
 
    
<link rel="stylesheet" type="text/css" href="<?php echo PPT_PATH; ?>js/lightbox/themes/default/jquery.lightbox.css" />
<!--[if IE 6]><link rel="stylesheet" type="text/css" href="<?php echo PPT_PATH; ?>js/lightbox/themes/default/jquery.lightbox.ie6.css" /><![endif]-->    
<script type="text/javascript" src="<?php echo PPT_PATH; ?>js/lightbox/jquery.lightbox.min.js"></script>   
<script type="text/javascript">
          jQuery(document).ready(function(){
            jQuery('.lightbox').lightbox();
          });
</script>
      
 
<script type="text/javascript"> 
 
$(document).ready(function() {
 
	//Default Action
	$(".tab_content").hide(); //Hide all content
	$("ul.tabs li:first").addClass("active").show(); //Activate first tab
	$(".tab_content:first").show(); //Show first tab content
	
	//On Click Event
	$("ul.tabs li").click(function() {
		$("ul.tabs li").removeClass("active"); //Remove any "active" class
		$(this).addClass("active"); //Add "active" class to selected tab
		$(".tab_content").hide(); //Hide all tab content
		var activeTab = $(this).find("a").attr("href"); //Find the rel attribute value to identify the active tab + content
		$(activeTab).fadeIn(); //Fade in the active content
		return false;
		
	});
 
});
</script>
<?php } ?>



<?php /*------------------- _TPL_ADD PAGE -----------------------*/ ?>


<?php if(isset($GLOBALS['tpl-add'])){ ?> 
<?php if(isset($_POST['action']) || isset($_GET['eid']) ){ ?> 
	<script>
    $(document).ready(function() { 
    <?php if(isset($_GET['eid']) && !isset($_POST['step1']) && !isset($_POST['step3'])){ ?>$('#step3box').hide();$('#steptable').hide();
    <?php }elseif(isset($_POST['step1'])){ ?>$('#step2box').hide();$('#step3box').show();
    <?php }elseif(isset($_POST['step3'])){ ?>$('#step2box').hide();$('#step4box').show();
    <?php }else{ ?>$('#step3box').show();<?php } ?>
    });
    </script>
<?php } } ?>



<?php wp_footer(); ?>


<?php echo stripslashes(get_option("analytics_code")); ?>
<?php echo stripslashes(get_option("google_adsensetracking_code")); ?> 
</body>
</html>