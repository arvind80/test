<?php
session_start();
include('../../../../wp-config.php');
$uploaddir = ABSPATH."wp-content/themes/classifiedstheme/uploads/";
$file = $uploaddir . basename($_FILES['uploadfile']['name']); 
foreach($_SESSION['post_ad_data']['ad_images'] as $key=>$val) {
  if($val == $_FILES['uploadfile']['name']) {
      unset($_SESSION['post_ad_data']['ad_images'][$key]);
  }
}
if(!file_exists($file)) {
  if (move_uploaded_file($_FILES['uploadfile']['tmp_name'], $file)) {
      $_SESSION['post_ad_data']['ad_images'][] = $_FILES['uploadfile']['name'];
      echo "success";
  } else {
      echo "error";
  }
}
?>