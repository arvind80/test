<?php
    if(isset($_POST)) {
        switch ($_GET['action']) {
            case 'add_option' :
                if($_POST['cat_option_name'] != "") {
                    $duplicateOptionQuery = @mysql_query("select option_id from wp_option where option_name = '".$_POST['cat_option_name']."'") or die(msyql_error());
                    if(mysql_num_rows($duplicateOptionQuery) > 0) {
                        $msg = "Already Exist.";    
                    } else {
                        $optionQuery = @mysql_query("insert into wp_option set option_name = '".$_POST['cat_option_name']."', added = NOW()") or die(mysql_error());
                    }
                } else {
                    $msg = "Please enter option name.";
                }
                
            break;
            case 'edit_option' :
                $optQuery = @mysql_query("select option_id, option_name from wp_option where option_id = '".$_POST['option_id']."' ") or die(mysql_error());
                $optQueryData = mysql_fetch_assoc($optQuery);
            break;
        
            case 'update_option':
                $updateRes = @mysql_query("update wp_option set option_name='".$_POST['optName']."' where option_id = '".$_POST['option_id']."'") or die(mysql_error());
                
            ?>
            <script type="text/javascript">
                    window.location.href('admin.php?page=manage_cat_attr_admin');
            </script>
            <?php
            break;
            case 'cancel_option' :
                echo "I am in";
            ?>
                <script type="text/javascript">
                    window.location.href('admin.php?page=manage_cat_attr_admin');
                </script>
            <?
            break;
            case 'delete_option':
                $deleteRes = @mysql_query("delete from wp_option where option_id = '".$_POST['option_id']."'") or die(mysql_error());
                echo "Testing"; die();
            ?>
                <script type="text/javascript">
                    window.location.href('admin.php?page=manage_cat_attr_admin');
                </script>
            <?php
            break;
        }
    }
?>
<script type="text/javascript">
    function hrfAction(opId, eleId){
        document.getElementById('frm_action'+opId).action = "admin.php?page=manage_cat_attr_admin&action="+eleId;
        document.getElementById('frm_action'+opId).submit();
        
    }
    function updateAction(opId, eleId){
        document.getElementById('frm_action'+opId).action = "admin.php?page=manage_cat_attr_admin&action="+eleId;
        document.getElementById('frm_action'+opId).submit();
        
    }
    function redirMethod(opId, eleId){
            document.getElementById('frm_action'+opId).action = "admin.php?page=manage_cat_attr_admin&action="+eleId;
            document.getElementById('frm_action'+opId).submit();
            
    }
    function deleteMethod(opId, eleId) {
            document.getElementById('frm_action'+opId).action = "admin.php?page=manage_cat_attr_admin&action="+eleId;
            document.getElementById('frm_action'+opId).submit();
            
    }
</script>
<style>
    th.row_heading {
        border-top:1px solid #000;
        border-bottom:1px solid #000;
        background-color:#737373;
        color: #FFF;
    }
    td.row_heading {
        border-top:1px solid #000;
        border-bottom:1px solid #000;
        background-color:#737373;
        color: #FFF;
        text-align: center;
    }
    tr#data_odd {
        background-color:#FCFCFC;
        color: #555562;
        text-align: center;
    }
    tr#data_even {
        background-color:#EAF2FA;
        color: #555562;
        text-align: center;
    }
    tr#data_odd  td{
        
        padding: 4px 0px;
    }
    tr#data_even  td{
        
        padding: 4px 0px;
    }
</style>
<div style="padding: 20px 0px 0px 20px; width:95%;">
    <div style="font-size:20px; font-weight:bold;">
        Manage Options
    </div>
</div>
<div style="width:75%; margin: 0 auto;">
    <div style="padding:20px 0px 0px 0px;">
        <div id="main_table">
            <div id="hideit" style="text-align: center; color: #FF0000; font-family: vardana; font-size:12px;">
                <?php
                    if(isset($msg) && $_GET['action'] == "add_option") {
                        echo $msg;
                    ?>
                    <script type="text/javascript">
                        function hideIt(){
                            document.getElementById("hideit").style.display = "none";
                        }
                        setTimeout("hideIt()", 5000);
                    </script>
                    <?php
                    }
                ?>
            </div>
            <table cellpadding="0" cellspacing="1" border="0" width="100%">
                <tr>
                    <th class="row_heading">ID</td>
                    <th class="row_heading">Option Name</td>
                    <th class="row_heading">Action</td>
                </tr>
                <?php
                    $optionQuery = @mysql_query("select option_id, option_name from wp_option") or die(msyql_error());
                    if(mysql_num_rows($optionQuery) > 0) {
                        $i = 0;
                        while($optData = mysql_fetch_assoc($optionQuery)) {
                            if($i%2 == 0)
                                $rowStyle = "data_odd";
                            else
                                $rowStyle = "data_even";
                ?>
                    <form name="frm_action<?php echo $i+1; ?>" id="frm_action<?php echo $i+1; ?>" action="" method="POST">
                    <tr id="<?php echo $rowStyle; ?>">
                    
                        <td id="optId<?php echo $optData['option_id']; ?>">
                            <?php echo $i+1; ?>
                        </td>
                        <?php if(isset($_GET['action']) && $_GET['action'] == "edit_option" && $optQueryData['option_id'] == $optData['option_id']) {
                                   
                        ?>
                        <td id="optName<?php echo $optData['option_id']; ?>" style="text-align:left; padding-left:20px;">
                            <div>
                                <input size="50" type="text" name="optName" id="optName" value="<?php echo $optQueryData['option_name']; ?>" />
                            </div>
                        </td>
                        <?php       } else { ?>
                        <td id="optName<?php echo $optData['option_id']; ?>">
                            <?php echo $optData['option_name']; ?>
                        </td>
                        <?php       
                                }
                        ?>
                        <td>
                                <input type="hidden" id="option_id" name="option_id" value="<?php echo $optData['option_id']; ?>">
                                <?php if(isset($_GET['action']) && $_GET['action'] == "edit_option" && $optQueryData['option_id'] == $optData['option_id']) {
                                        
                                ?>
                                        <input type="button" id="update_option" name="update_option" onclick="updateAction('<?php echo $optData["option_id"]; ?>', this.id);" value="Save" />
                                        <input onclick="redirMethod('<?php echo $optData["option_id"]; ?>', this.id);" type="submit" id="cancel_option" name="cancel_option" value="Cancel" />
                                <?php   } else { ?>
                                
                                        <input type="button" id="edit_option" name="edit_option" onclick="hrfAction('<?php echo $optData["option_id"]; ?>', this.id);" value="Edit" />
                                        
                                        <input onclick="deleteMethod(document.getElementById(''),'<?php echo $optData["option_id"]; ?>', this.id);" type="button" id="delete_option" name="delete_option" value="Delete" />
                                        
                                <?php   
                                      }
                                ?>
                                
                           
                        </td>
                    </tr>
                    </form>
                <?php
                        $i++;
                        }
                    } else {
                ?>
                <tr id="<?php echo $rowStyle; ?>">
                    <td colspan="3" style="text-align: center; padding: 10px 0px; font-size: 16px;">
                        No Record Found
                    </td>
                </tr>
                <?php
                    }
                ?>
                <form action="admin.php?page=manage_cat_attr_admin&action=add_option" method="POST" name="cat_value_frm" id="cat_value_frm">
                <tr id="<?php echo $rowStyle; ?>">
                    <td style="border-top:1px solid #000;">
                        <?php echo $i+1; ?>
                    </td>
                    <td style="text-align: left !important; border-top:1px solid #000;">
                            <div style="padding-left: 30px;">
                                <input type="text" name="cat_option_name" id="cat_value" />    
                            </div>
                    </td>
                    <td style="border-top:1px solid #000;">
                            <input type="submit" name="submit_option" value="Insert" />
                    </td>
                </tr>
                </form>
            </table>
        </div>
    </div>
</div>