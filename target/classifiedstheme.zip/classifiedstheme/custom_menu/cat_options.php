<?php
    if($_GET['currentpage'])
        $cPage = $_GET['currentpage'];
    else
        $cPage = '1';
        
    if($_GET['currPage'])
        $currPage1 = $_GET['currPage'];
    else
        $currPage1 = '1';
        
    // common functions
        function list_opt_name($id = "") {
            $optArray = Array(); $j = 0;
            if($id!="") {
                $catOptQuery = @mysql_query("select option_id, option_name from wp_category_options order by option_id asc") or die(msyql_error());
            } else {
                $catOptQuery = @mysql_query("select option_id, option_name from wp_category_options order by option_id asc") or die(msyql_error());
            }
            
            while($optData = mysql_fetch_assoc($catOptQuery)) {
                $optArray[$j][] = $optData['option_id'];
                $optArray[$j][] = $optData['option_name'];
                $j++;
            }
            return $optArray;
        }
    // end common funcitons
    if(isset($_POST)) {
        switch ($_GET['action']) {
            case 'add_option' :
                if($_POST['cat_option_name'] != "") {
                    $duplicateCatOptionQuery = @mysql_query("select option_id from wp_category_options where option_name = '".$_POST['cat_option_name']."'") or die(msyql_error());
                    if(mysql_num_rows($duplicateCatOptionQuery) > 0) {
                        $msg = "Already Exist.";    
                    } else {
                        $catOptionAddQuery = @mysql_query("insert into wp_category_options set option_name = '".$_POST['cat_option_name']."', added = NOW()") or die(mysql_error());
                        header("location:".get_bloginfo('url')."/wp-admin/admin.php?page=cat_options.php&action=success&currentpage=".$_GET['currentpage']);
                        exit();
                    }
                } else {
                    $msg = "Please enter option name.";
                }
            break;
            case 'edit_option' :
                $catOptionEditQuery = @mysql_query("select option_id, option_name from wp_category_options where option_id = '".$_POST['option_id']."' ") or die(mysql_error());
                $catOptionData = mysql_fetch_assoc($catOptionEditQuery);
            break;
        
            case 'update_option':
                $updateRes = @mysql_query("update wp_category_options set option_name='".$_POST['optName']."' where option_id = '".$_POST['option_id']."'") or die(mysql_error());
                header("location:".get_bloginfo('url')."/wp-admin/admin.php?page=cat_options.php&currentpage=".$_GET['currentpage']);
                exit();
            break;
        
            case 'cancel_option' :
                header("location:".get_bloginfo('url')."/wp-admin/admin.php?page=cat_options.php&currentpage=".$_GET['currentpage']);
                exit();
            break;
        
            case 'delete_option':
                $ckDataQuery = @mysql_query("select id from wp_cat_opt_value_to_pro_opt where option_id = '".$_POST['option_id']."'") or die(mysql_error());
                if(mysql_num_rows($ckDataQuery) > 0) {
                    $deleteRes = @mysql_query("delete wp_category_options, wp_category_options_values, wp_cat_opt_value_to_pro_opt from wp_category_options INNER JOIN wp_cat_opt_value_to_pro_opt INNER JOIN wp_category_options_values where wp_category_options.option_id = wp_cat_opt_value_to_pro_opt.option_id and wp_category_options_values.option_value_id = wp_cat_opt_value_to_pro_opt.option_value_id and wp_category_options.option_id = '".$_POST['option_id']."'") or die(mysql_error());
                } else {
                    $deleteRes = @mysql_query("delete from wp_category_options where option_id = '".$_POST['option_id']."'") or die(mysql_error());    
                }
                header("location:".get_bloginfo('url')."/wp-admin/admin.php?page=cat_options.php&currentpage=".$_GET['currentpage']);
                exit();
            break;
        
                // Code for option values section
                
            case 'add_option_value' :
                if($_POST['option_value_name'] != "") {
                        $catOptValQuery = @mysql_query("insert into wp_category_options_values set option_value_name = '".$_POST['option_value_name']."', added = NOW()") or die(mysql_error());
                        $optValLastId =  mysql_insert_id();
                        $catOpt_to_cat_ValQuery = @mysql_query(" insert into wp_cat_opt_value_to_pro_opt set option_id = '".$_POST['cat_option_id']."', option_value_id = '".$optValLastId."' ") or die(mysql_error());
                        header("location:".get_bloginfo('url')."/wp-admin/admin.php?page=cat_options.php&currPage=".$_GET['currPage']);
                        exit();
                } else {
                    $msg1 = "Please enter option value name.";
                }                
            break;
        
            case 'edit_option_value' :
                //print_r($_POST); die();
                $catOptValEditQuery = @mysql_query("select option_value_id, option_value_name from wp_category_options_values where option_value_id = '".$_POST['option_value_id']."' ") or die(mysql_error());
                $catOptValData = mysql_fetch_assoc($catOptValEditQuery);
                //print_r($catOptValData); die();
            break;
        
            case 'update_option_value':
                $updateOptValRes = @mysql_query("update wp_category_options_values set option_value_name='".$_POST['optName']."' where option_value_id = '".$_POST['option_value_id']."'") or die(mysql_error());
                $updateRes = @mysql_query("update wp_cat_opt_value_to_pro_opt set option_id='".$_POST['cat_option_id']."' where id = '".$_POST['id']."'") or die(mysql_error());
                header("location:".get_bloginfo('url')."/wp-admin/admin.php?page=cat_options.php&currPage=".$_GET['currPage']);
                exit();
            break;
        
            case 'cancel_option' :
                header("location:".get_bloginfo('url')."/wp-admin/admin.php?page=cat_options.php&currPage=".$_GET['currPage']);
                exit();
            break;
        
            case 'delete_option_value':
                //print_r($_POST); die();
                $deleteRes = @mysql_query("delete from wp_cat_opt_value_to_pro_opt where id = '".$_POST['id']."'") or die(mysql_error());
                $deleteRes1 = @mysql_query("delete from wp_category_options_values where option_value_id = '".$_POST['option_value_id']."'") or die(mysql_error());
                header("location:".get_bloginfo('url')."/wp-admin/admin.php?page=cat_options.php&currPage=".$_GET['currPage']);
                exit();
            break;
        }
    }
    // Start pagination on category option table
    $sql = "select count(*) from wp_category_options";
    $result = @mysql_query($sql) or trigger_error("SQL", E_USER_ERROR);
    $r = mysql_fetch_row($result);
    $numrows = $r[0];
    // number of rows to show per page
    $rowsperpage = 10;
    // find out total pages
    $totalpages = ceil($numrows / $rowsperpage);
    // get the current page or set a default
    if (isset($_GET['currentpage']) && is_numeric($_GET['currentpage'])) {
       // cast var as int
       $currentpage = (int) $_GET['currentpage'];
    } else {
       // default page num
       $currentpage = 1;
    } // end if
    // if current page is greater than total pages...
    if ($currentpage > $totalpages) {
       // set current page to last page
       $currentpage = $totalpages;
    } // end if
    // if current page is less than first page...
    if ($currentpage < 1) {
       // set current page to first page
       $currentpage = 1;
    } // end if
    // the offset of the list, based on current page
    $offset = ($currentpage - 1) * $rowsperpage;
    
    
    // Start pagination on category option value table
    
    $sqlOptionValue = "select count(co_to_cov.id) from wp_cat_opt_value_to_pro_opt as co_to_cov INNER JOIN wp_category_options as co ON co.option_id = co_to_cov.option_id INNER JOIN wp_category_options_values as cov ON cov.option_value_id = co_to_cov.option_value_id";
    $result1 = @mysql_query($sqlOptionValue) or trigger_error("SQL", E_USER_ERROR);
    $res = mysql_fetch_row($result1);
    $numrows1 = $res[0];
    // number of rows to show per page
    $rowsperpage1 = 10;
    // find out total pages
    $totalpages1 = ceil($numrows1 / $rowsperpage1);
    // get the current page or set a default
    if (isset($_GET['currPage']) && is_numeric($_GET['currPage'])) {
       // cast var as int
       $currentpage1 = (int) $_GET['currPage'];
    } else {
       // default page num
       $currentpage1 = 1;
    } // end if
    // if current page is greater than total pages...
    if ($currentpage1 > $totalpages1) {
       // set current page to last page
       $currentpage1 = $totalpages1;
    } // end if
    // if current page is less than first page...
    if ($currentpage1 < 1) {
       // set current page to first page
       $currentpage1 = 1;
    } // end if
    
    // the offset of the list, based on current page
    $offset1 = ($currentpage1 - 1) * $rowsperpage1;
    
?>
<style>
    th.row_heading {
        border-top:1px solid #000;
        border-bottom:1px solid #000;
        background-color:#737373;
        color: #FFF;
        padding:4px 0px;
    }
    td.row_heading {
        border-top:1px solid #000;
        border-bottom:1px solid #000;
        background-color:#737373;
        color: #FFF;
        text-align: center;
    }
    tr#data_odd {
        background-color:#FCFCFC;
        color: #555562;
        text-align: center;
    }
    tr#data_even {
        background-color:#EAF2FA;
        color: #555562;
        text-align: center;
    }
    tr#data_odd  td{
        
        padding: 4px 0px;
    }
    tr#data_even  td{
        
        padding: 4px 0px;
    }
    a:hover {
        color:#21759B;
    }
    a:visited {
        color:#21759B;
    }
    a:active {
        color:#21759B;
    }
    a:link {
        color:#21759B;
    }
</style>
<script type="text/javascript">
    function btnActions(frmAct, eleId,btnAct,cPage) {
        
        if(btnAct == "update") {
            frmAct.action = "admin.php?page=cat_options.php&action="+eleId+'&currentpage='+cPage;
            frmAct.submit();
        } else if(btnAct == "delete") {
            
            frmAct.action = "admin.php?page=cat_options.php&action="+eleId+'&currentpage='+cPage;
            frmAct.submit();
            
        } else if(btnAct == "cancel") {
            
            frmAct.action = "admin.php?page=cat_options.php&action="+eleId+'&currentpage='+cPage;
            frmAct.submit();
            
        } else if(btnAct == "edit") {
            frmAct.action = "admin.php?page=cat_options.php&action="+eleId+'&currentpage='+cPage;
            frmAct.submit();
            
        }
        if(btnAct == "update_value") {
            frmAct.action = "admin.php?page=cat_options.php&action="+eleId+'&currPage='+cPage;
            frmAct.submit();
        } else if(btnAct == "delete_value") {
            
            frmAct.action = "admin.php?page=cat_options.php&action="+eleId+'&currPage='+cPage;
            frmAct.submit();
            
        } else if(btnAct == "cancel_value") {
            
            frmAct.action = "admin.php?page=cat_options.php&action="+eleId+'&currPage='+cPage;
            frmAct.submit();
            
        } else if(btnAct == "edit_value") {
            frmAct.action = "admin.php?page=cat_options.php&action="+eleId+'&currPage='+cPage;
            frmAct.submit();
            
        }  
    }
    function hideId(){
        document.getElementById("hideid").style.display = "none";
    }
</script>
<div style="padding: 20px 0px 0px 20px; width:95%;">
    <div style="font-size:20px; font-weight:bold;">
        Category Options
    </div>
</div>
<div style="width:75%; margin: 0 auto;">
    <div style="padding:20px 0px 0px 0px;">
        <div id="main_table">
            <div id="hideid" style="text-align: center; color: #FF0000; font-family: vardana; font-size:12px;">
                <?php
                    $flag = 0;
                    if(isset($msg) && $_GET['action'] == "add_option") {
                        $flag = 1;
                        echo $msg;
                    } else if($_GET['action'] == "success") {
                        $flag = 1;
                        echo "Successfuly added";
                    }
                    if($flag == 1) {
                    ?>
                        <script type="text/javascript">
                            setTimeout("hideId()", 5000);
                        </script>
                    <?php
                    }
                    
                ?>
            </div>
            <table cellpadding="0" cellspacing="1" border="0" width="100%">
                <tr>
                    <th class="row_heading" style="width:10%;">ID</td>
                    <th class="row_heading" style="width:60%;">Option Name</td>
                    <th class="row_heading" style="width:30%;">Action</td>
                </tr>
                <?php
                    $emptyRows = 0;
                    $catOptionQuery = @mysql_query("select option_id, option_name from wp_category_options limit $offset, $rowsperpage") or die(msyql_error());
                    
                    if(mysql_num_rows($catOptionQuery) > 0) {
                        $i = 0;
                        while($catOptData = mysql_fetch_assoc($catOptionQuery)) {
                            if($i%2 == 0)
                                $rowStyle = "data_odd";
                            else
                                $rowStyle = "data_even";
                ?>
                    <form name="frm_action<?php echo $i+1; ?>" id="frm_action<?php echo $i+1; ?>" action="" method="POST">             
                    <tr id="<?php echo $rowStyle; ?>">
                        <td id="optId<?php echo $catOptData['option_id']; ?>">
                            <?php echo $i+1; ?>
                        </td>
                        <?php if(isset($_GET['action']) && $_GET['action'] == "edit_option" && $catOptionData['option_id'] == $catOptData['option_id']) {
                                   
                        ?>
                        <td id="optName<?php echo $catOptData['option_id']; ?>" style="text-align:left; padding-left:20px;">
                            <div>
                                <input  type="text" name="optName" id="optName" value="<?php echo $catOptionData['option_name']; ?>" />
                            </div>
                        </td>
                        <?php       } else { ?>
                        <td id="optName<?php echo $catOptData['option_id']; ?>">
                            <?php echo $catOptData['option_name']; ?>
                        </td>
                        <?php       
                                }
                        ?>
                        <td>
                                
                                <input type="hidden" id="option_id" name="option_id" value="<?php echo $catOptData['option_id']; ?>">
                                <?php if(isset($_GET['action']) && $_GET['action'] == "edit_option" && $catOptionData['option_id'] == $catOptData['option_id']) {
                                        
                                ?>
                                        <input type="button" id="update_option" name="update_option" onclick="btnActions(document.getElementById('frm_action<?php echo $i+1; ?>'), this.id, 'update', '<? echo $cPage; ?>');" value="Save" />
                                        <input onclick="btnActions(document.getElementById('frm_action<?php echo $i+1; ?>'), this.id, 'cancel', '<? echo $cPage; ?>');" type="submit" id="cancel_option" name="cancel_option" value="Cancel" />
                                <?php   } else { ?>
                                
                                        <input type="button" id="edit_option" name="edit_option" onclick="btnActions(document.getElementById('frm_action<?php echo $i+1; ?>'), this.id, 'edit', '<? echo $cPage; ?>');" value="Edit" />
                                        
                                        <input onclick="btnActions(document.getElementById('frm_action<?php echo $i+1; ?>'), this.id, 'delete', '<? echo $cPage; ?>');" type="button" id="delete_option" name="delete_option" value="Delete" />
                                <?php   
                                      }
                                ?>
                        </td>
                    </tr>
                    </form>
                <?php
                        $i++;
                        }
                    } else {
                        $emptyRows = 1;
                ?>
                <tr id="<?php echo $rowStyle; ?>">
                    <td colspan="3" style="text-align: center; padding: 10px 0px; font-size: 16px;">
                        No Record Found
                    </td>
                </tr>
                <?php
                    }
                ?>
                <form action="admin.php?page=cat_options.php&action=add_option&currentpage=<?php echo $cPage; ?>" method="POST" name="cat_value_frm" id="cat_value_frm">
                <tr id="<?php echo $rowStyle; ?>">
                    <td style="border-top:1px solid #000; text-align: center;">
                        <?php echo $i+1; ?>
                    </td>
                    <td style="text-align: left !important; border-top:1px solid #000;">
                            <div style="padding-left: 30px;">
                                <input type="text" name="cat_option_name"  id="cat_value" />    
                            </div>
                    </td>
                    <td style="border-top:1px solid #000;  text-align: center;">
                            <input type="submit" name="submit_option" value="Insert" />
                    </td>
                </tr>
                <?php if($emptyRows == 0) { ?>
                <tr>
                    <td colspan="3" style="text-align: center;">
                    <?php
                         if ($currentpage == 1) 
                         {
                            echo "&laquo; <a href='javascript:;' class='dullAnchor' style='text-decoration:none;cursor: default;'>First</a> ";
                           
                            echo " ";
                           
                            $previous = $currentpage-1;
                           
                            echo "&lsaquo; <a href='javascript:;' class='dullAnchor' style='text-decoration:none;cursor: default;'> Previous</a> &nbsp;&nbsp;";
                         } 
                        
                         else 
                        
                         {
                        
                            echo "&nbsp;&nbsp;&laquo; <a href='{$_SERVER['PHP_SELF']}?page=cat_options.php&currentpage=1' style='text-decoration:none;'><strong>First</strong></a> ";
                           
                            echo " ";
                           
                            $previous = $currentpage-1;
                           
                            echo "&lsaquo; <a href='{$_SERVER['PHP_SELF']}?page=cat_options.php&currentpage=$previous' style='text-decoration:none;'><strong>Previous</strong></a> ";
                        
                         }
                        if ($currentpage == $totalpages)  {
                            echo "&nbsp;&nbsp; <a href='javascript:;' class='dullAnchor' style='cursor: default; text-decoration:none;'>
                                        Next
                                    </a> &rsaquo;";
                           
                            echo " ";
                           
                            echo " <a href='javascript:;' class='dullAnchor' style='cursor: default; text-decoration:none;'>
                                        Last
                                    </a> &raquo;";
                        } 
                       
                        else {
                       
                        $next = $currentpage+1;
                       
                        echo "&nbsp;&nbsp; <a href='{$_SERVER['PHP_SELF']}?page=cat_options.php&currentpage=$next' style='text-decoration:none;'>
                                    <strong>Next<strong>
                                </a> &rsaquo;";
                       
                        echo " ";
                       
                        echo " <a href='{$_SERVER['PHP_SELF']}?page=cat_options.php&currentpage=$totalpages' style=' text-decoration:none;'>
                                    <strong>Last<strong>
                                </a> &raquo;";
                       
                        }
                        
                    ?>
                    </td>
                </tr>
                <?php } ?>
                </form>
            </table>
        </div>
    </div>
</div>


<!--                                Code Added for category option value                                    -->

<div style="padding: 20px 0px 0px 20px; width:95%;">
    <div style="font-size:20px; font-weight:bold;">
        Option Values
    </div>
</div>
<div style="width:75%; margin: 0 auto;">
    <div style="padding:20px 0px 0px 0px;">
        <div id="main_table">
            <div id="hideid1" style="text-align: center; color: #FF0000; font-family: vardana; font-size:12px;">
                <?php
                    if(isset($msg1) && $_GET['action'] == "add_option_value") {
                        echo $msg1;
                    ?>
                    <script type="text/javascript">
                        function hideid1(){
                            document.getElementById("hideid1").style.display = "none";
                        }
                        setTimeout("hideid1()", 5000);
                    </script>
                    <?php
                    }
                ?>
            </div>
            <table cellpadding="0" cellspacing="1" border="0" width="100%">
                <tr>
                    <th class="row_heading" style="width:10%;">ID</td>
                    <th class="row_heading" style="width:30%;">Option Name</td>
                    <th class="row_heading" style="width:40%;">Option Value</td>
                    <th class="row_heading" style="width:20%;">Action</td>
                </tr>
                <?php
                    $emptyRecords = 0;
                    $catOptValListingQuery = @mysql_query("select co_to_cov.id, co.option_id, co.option_name, cov.option_value_id, cov.option_value_name from wp_cat_opt_value_to_pro_opt as co_to_cov INNER JOIN wp_category_options as co ON co.option_id = co_to_cov.option_id INNER JOIN wp_category_options_values as cov ON cov.option_value_id = co_to_cov.option_value_id limit $offset1, $rowsperpage1") or die(msyql_error());
                    if(mysql_num_rows($catOptValListingQuery) > 0) {
                        $j = 0;
                        while($catOptValListingData = mysql_fetch_assoc($catOptValListingQuery)) {
                            if($j%2 == 0)
                                $rowStyle = "data_odd";
                            else
                                $rowStyle = "data_even";
                ?>
                    <form name="frmAction<?php echo $j+1; ?>" id="frmAction<?php echo $j+1; ?>" action="" method="POST">
                    <input type="hidden" id="option_value_id" name="option_value_id" value="<?php echo $catOptValListingData['option_value_id']; ?>">
                    <input type="hidden" id="option_id" name="option_id" value="<?php echo $catOptValListingData['option_id']; ?>">
                    <input type="hidden" name="id" value="<?php echo $catOptValListingData['id']; ?>" />
                    <tr id="<?php echo $rowStyle; ?>">
                        <td id="optId<?php echo $j+1; ?>" style="text-align: center;">
                            <?php echo $j+1; ?>
                        </td>
                        <?php if(isset($_GET['action']) && $_GET['action'] == "edit_option_value" && $catOptValListingData['option_value_id'] == $catOptValData['option_value_id']) {
                                        $tmpArr1 = list_opt_name();
                        ?>
                            
                            <td id="optName<?php echo $catOptValListingData['option_id']; ?>">
                            <?php //echo $_POST['option_id']."shavi"; print_r($tmpArr1); ?>
                                
                                <select name="cat_option_id">
                                
                                  <?php foreach($tmpArr1 as $key=>$value) {
                                            if($value[0] == $_POST['option_id']) {
                                                $selected = "selected='selected'";
                                            } else {
                                                $selected = "";
                                            }
                                    ?>
                                            <option value="<?php echo $value[0]; ?>" <?php echo $selected; ?>>
                                                <?php echo $value[1]; ?>
                                            </option>
                                  <?php }  ?>
                                </select>
                            </td>
                            <td id="optName<?php echo $catOptValListingData['id']; ?>" style="text-align:left; padding-left:20px;">
                                    <input  type="text" name="optName" id="optName" value="<?php echo $catOptValData['option_value_name']; ?>" />
                            </td>
                        <?php  } else { ?>
                            <td id="optName<?php echo $catOptValListingData['option_id']; ?>">
                                <?php echo $catOptValListingData['option_name']; ?>
                            </td>
                            <td id="optName<?php echo $catOptValListingData['option_id']; ?>">
                                <?php echo $catOptValListingData['option_value_name']; ?>
                            </td>
                        <?php       
                                }
                        ?>
                        
                        <td>   
                                <?php if(isset($_GET['action']) && $_GET['action'] == "edit_option_value" && $catOptValListingData['option_value_id'] == $catOptValData['option_value_id']) {
                                ?>
                                        <input type="button" id="update_option_value" name="update_option_value" onclick="btnActions(document.getElementById('frmAction<?php echo $j+1; ?>'), this.id, 'update_value', '<? echo $currPage1; ?>');" value="Save" />
                                        <input onclick="btnActions(document.getElementById('frmAction<?php echo $j+1; ?>'), this.id, 'cancel_value', '<? echo $currPage1; ?>');" type="submit" id="cancel_option_value" name="cancel_option_value" value="Cancel" />
                                <?php   } else { ?>
                                        <input type="button" id="edit_option_value" name="edit_option_value" onclick="btnActions(document.getElementById('frmAction<?php echo $j+1; ?>'), this.id, 'edit_value', '<? echo $currPage1; ?>');" value="Edit" />
                                        <input onclick="btnActions(document.getElementById('frmAction<?php echo $j+1; ?>'), this.id, 'delete_value', '<? echo $currPage1; ?>');" type="button" id="delete_option_value" name="delete_option_value" value="Delete" />
                                <?php   
                                      }
                                ?>
                        </td>
                    </tr>
                    </form>
                <?php
                        $j++;
                        }
                    } else {
                        $emptyRecords = 1;
                ?>
                <tr id="<?php echo $rowStyle; ?>">
                    <td colspan="4" style="text-align: center; padding: 10px 0px; font-size: 16px;">
                        No Record Found
                    </td>
                </tr>
                <?php
                    } 
                ?>
                
                
                <?php
                    $catOptQuery = @mysql_query("select option_id, option_name from wp_category_options order by option_id asc") or die(msyql_error());
                    if(mysql_num_rows($catOptQuery) > 0) {
                ?>  
                <form action="admin.php?page=cat_options.php&action=add_option_value&currPage=<?php echo $currPage1; ?>" method="POST" name="cat_option_value_frm" id="cat_option_value_frm">
                    <tr id="<?php echo $rowStyle; ?>">
                        <td style="border-top:1px solid #000;">
                            <?php echo $j+1; ?>
                        </td>
                        <td style="text-align: left !important; border-top:1px solid #000; padding-left:20px; ">
                                <?php
                                        $tmpArr = list_opt_name();
                                ?>
                                <select name="cat_option_id">
                                  <?php foreach($tmpArr as $key=>$value) { ?>
                                    <option value="<?php echo $value[0]; ?>">
                                        <?php echo $value[1]; ?>
                                    </option>
                                  <?php } ?>
                                </select>
                        </td>
                        <td style="text-align: left !important; border-top:1px solid #000; padding-left:20px;">
                            <input type="text" name="option_value_name" id="option_value_name" size="25" />
                        </td>
                        <td style="border-top:1px solid #000;  text-align: center;">
                                <input type="submit" name="submit_option_value" value="Insert" />
                        </td>
                    </tr>
                </form>
                <?php
                    }
                ?>
                <?php if($emptyRecords == 0) { ?>
                <tr>
                    <td colspan="4" style="text-align: center;">
                    <?php
                         if ($currentpage1 == 1) 
                         {
                            echo "&laquo; <a href='javascript:;' class='dullAnchor' style='text-decoration:none;cursor: default;'>First</a> ";
                           
                            echo " ";
                           
                            $previous1 = $currentpage1-1;
                           
                            echo "&lsaquo; <a href='javascript:;' class='dullAnchor' style='text-decoration:none;cursor: default;'> Previous</a> &nbsp;&nbsp;";
                         } 
                        
                         else 
                        
                         {
                        
                            echo "&nbsp;&nbsp;&laquo; <a href='{$_SERVER['PHP_SELF']}?page=cat_options.php&currPage=1' style='text-decoration:none;'><strong>First</strong></a> ";
                           
                            echo " ";
                           
                            $previous1 = $currentpage1-1;
                           
                            echo "&lsaquo; <a href='{$_SERVER['PHP_SELF']}?page=cat_options.php&currPage=$previous1' style='text-decoration:none;'><strong>Previous</strong></a> ";
                        
                         }
                         
                        if ($currentpage1 == $totalpages1)  {
                            echo "&nbsp;&nbsp; <a href='javascript:;' class='dullAnchor' style='cursor: default; text-decoration:none;'>
                                        Next
                                    </a> &rsaquo;";
                           
                            echo " ";
                           
                            echo " <a href='javascript:;' class='dullAnchor' style='cursor: default; text-decoration:none;'>
                                        Last
                                    </a> &raquo;";
                        } 
                       
                        else {
                       
                        $next1 = $currentpage1+1;
                       
                        echo "&nbsp;&nbsp; <a href='{$_SERVER['PHP_SELF']}?page=cat_options.php&currPage=$next1' style='text-decoration:none;'>
                                    <strong>Next<strong>
                                </a> &rsaquo;";
                       
                        echo " ";
                       
                        echo " <a href='{$_SERVER['PHP_SELF']}?page=cat_options.php&currPage=$totalpages1' style=' text-decoration:none;'>
                                    <strong>Last<strong>
                                </a> &raquo;";
                       
                        }
                    ?>
                    </td>
                </tr>
                <?php } ?>
            </table>
        </div>
    </div>
    
</div>