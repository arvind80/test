<?php
    if($_POST['field_type'] == "drop-down") {
        $str = '
                <div style="width:100%; float: left; padding:20px 0px 0px 0px;">
                    <div style="float: left; width:144px; text-align: right;">
                        <label style="padding-right:5px; font-size:14px;">Values : </label>
                    </div>
                    <div style="width: 400px; float:left; padding-left: 5px;">
                        <input type="text" name="drop_down_value[]" value="" class="txtField" size="28" />
                        <input type="hidden" value="0" id="cddval" />
                        <div id="ddval" style="padding:5px 0px;"></div>
                        <div style="text-align: right; width:250px; padding-top:10px;">
                            <a href="javascript:;" onclick="addElement(\'text\', \'drop_down_value\', \'txtField\', \'ddval\', \'cddval\');">add More</a>
                        </div>
                    </div>
                </div>
        ';
    }
    echo $str;
?>