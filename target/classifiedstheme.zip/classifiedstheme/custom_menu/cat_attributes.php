
<?php global $PPT;
    //error_reporting(E_ALL);
    //ini_set('display_errors', '1');
?>
<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_url'); ?>/custom_menu/flexdropdown.css" />
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/custom_menu/flexdropdown.js"></script>
<?php
    // common functions
        function list_opt_name($id = "") {
            $optArray = Array(); $j = 0;
            if($id!="") {
                $catOptQuery = @mysql_query("select option_id, option_name from wp_category_options") or die(mysql_error());
            } else {
                $catOptQuery = @mysql_query("select option_id, option_name from wp_category_options") or die(mysql_error());
            }
            
            while($optData = mysql_fetch_assoc($catOptQuery)) {
                $optArray[$j][] = $optData['option_id'];
                $optArray[$j][] = $optData['option_name'];
                $j++;
            }
            return $optArray;
        }
        function list_opt_value_name($id = "") {
            $optValArray = Array();
            $j = 0;
            if($id!="") {
                $catOptValQuery = @mysql_query("select option_value_id, option_value_name from wp_category_options_values") or die(mysql_error());
            } else {
                $catOptValQuery = @mysql_query("select option_value_id, option_value_name from wp_category_options_values") or die(mysql_error());
            }
            
            while($optValData = mysql_fetch_assoc($catOptValQuery)) {
                $optValArray[$j][] = $optValData['option_value_id'];
                $optValArray[$j][] = $optValData['option_value_name'];
                $j++;
            }
            return $optValArray;
        }
    // end common funcitons
    if(isset($_POST)) {
        if(isset($_GET['action'])) {
        switch ($_GET['action']) {
            case 'add_attrubute' :
                    $catAttrAddQuery = @mysql_query("insert into wp_category_attributes set category_id = '".$_POST['cat']."', option_id = '".$_POST['option_name']."', option_value_id = '".$_POST['option_name_value']."'") or die(mysql_error());
                    if($catAttrAddQuery) {
                        $_SESSION['action'] = "add";
                    }
                    header("location:".get_bloginfo('url')."/wp-admin/admin.php?page=manage_cat_attr_admin&message=add");
                    exit();
            break;
            case 'delete_attribute' :
                    $delCatAttrQuery = @mysql_query("delete from wp_category_attributes where category_attributes_id = '".$_POST['cat_attr_id']."'") or die(mysql_error());
                    header("location:".get_bloginfo('url')."/wp-admin/admin.php?page=manage_cat_attr_admin&message=delete");
                    exit();
            break;
            case 'update_attribute' :
                    $updateRes = @mysql_query("update wp_category_attributes set category_id='".$_POST['cat']."', option_id='".$_POST['option_name']."', option_value_id='".$_POST['option_name_value']."' WHERE category_attributes_id= '".$_POST['cat_attr_id']."'") or die(mysql_error());
                    header("location:".get_bloginfo('url')."/wp-admin/admin.php?page=manage_cat_attr_admin&message=update");
                    exit();
            break;
        }
        }
    }
?>
<style>
    th.row_heading {
        border-top:1px solid #000;
        border-bottom:1px solid #000;
        background-color:#737373;
        color: #FFF;
        padding:4px 0px;
    }
    td.row_heading {
        border-top:1px solid #000;
        border-bottom:1px solid #000;
        background-color:#737373;
        color: #FFF;
        text-align: center;
    }
    tr#data_odd {
        background-color:#FCFCFC;
        color: #555562;
        text-align: center;
    }
    tr#data_even {
        background-color:#EAF2FA;
        color: #555562;
        text-align: center;
    }
    tr#data_odd  td{
        
        padding: 4px 0px;
    }
    tr#data_even  td{
        
        padding: 4px 0px;
    }
    li, dd {
        margin-bottom: 0px !important;
    }
</style>
<script type="text/javascript">
    function btnActions(frmAct, eleId,btnAct) {
        //alert("test"); return false;
        if(btnAct == "update") {
            
            frmAct.action = "admin.php?page=manage_cat_attr_admin&action="+eleId;
            frmAct.submit();
            
        } else if(btnAct == "delete") {
            frmAct.action = "admin.php?page=manage_cat_attr_admin&action="+eleId;
            frmAct.submit();
            
        } else if(btnAct == "cancel") {
            
            frmAct.action = "admin.php?page=manage_cat_attr_admin&action="+eleId;
            frmAct.submit();
            
        } else {
            frmAct.action = "admin.php?page=manage_cat_attr_admin&action="+eleId;
            frmAct.submit();
            
        }       
    }
    function hideId(){
        document.getElementById("hideid").style.display = "none";
    }
</script>
<?php //print_r($PPT); echo "<pre>"; print_r(get_included_files()); echo "</pre>"; ?>
<div style="padding: 20px 0px 0px 20px; width:95%;">
    <div style="font-size:20px; font-weight:bold;">
        Category Attributes
    </div>
</div>
<div style="width:75%; margin: 0 auto;">
    <div style="padding:20px 0px 0px 0px;">
        <div id="main_table">
            <div id="hideid" style="text-align: center; color: #FF0000; font-family: vardana; font-size:12px;">
                <?php
                    $flag = 0;
                    if(isset($_GET['message']) && $_GET['message'] == "delete") {
                        $flag = 1;
                        echo "Record deleted successfully";                
                    } else if(isset($_GET['message']) && $_GET['message'] == "add") {
                        $flag = 1;
                        echo "Record add successfully";
                    }
                    else if(isset($_GET['message']) && $_GET['message'] == "update") {
                        $flag = 1;
                        echo "Record udpate successfully";
                    }
                    if($flag == 1) {
                    ?>
                        <script type="text/javascript">
                            setTimeout("hideId()","5000");
                        </script>
                    <?php    
                    }
                ?>
            </div>
            <table cellpadding="0" cellspacing="1" border="0" width="100%">
                <tr>
                    <th class="row_heading" style="width:5%;">ID</td>
                    <th class="row_heading" style="width:25%;">Category Name</td>
                    <th class="row_heading" style="width:20%;">Option Name</td>
                    <th class="row_heading" style="width:20%;">Option Value</td>
                    <th class="row_heading" style="width:30%;">Action</td>
                </tr>
                <?php
                    $i = 0;
                    $catAttrQuery = @mysql_query("select ca.category_attributes_id, t.term_id, t.name, co.option_id, co.option_name, cov.option_value_id, cov.option_value_name from wp_category_attributes as ca INNER JOIN wp_terms as t ON ca.category_id = t.term_id INNER JOIN wp_term_taxonomy as tt ON t.term_id = tt.term_id INNER JOIN wp_category_options AS co ON co.option_id = ca.option_id LEFT JOIN wp_category_options_values as cov ON cov.option_value_id = ca.option_value_id and tt.taxonomy = 'category'") or die(mysql_error());
                    if(mysql_num_rows($catAttrQuery) > 0) {
                        
                        while($catAttData = mysql_fetch_assoc($catAttrQuery)) {
                            if($i%2 == 0)
                                $rowStyle = "data_odd";
                            else
                                $rowStyle = "data_even";
                ?>
                    <form name="frm_action<?php echo $i+1; ?>" id="frm_action<?php echo $i+1; ?>" action="" method="POST">
                        <input type="hidden" name="cat_attr_id" value="<?php echo $catAttData['category_attributes_id']; ?>" />
                        <input type="hidden" name="cat_id" value="<?php echo $catAttData['term_id']; ?>" />
                        <input type="hidden" name="cat_opt_id" value="<?php echo $catAttData['option_id']; ?>" />
                        <input type="hidden" name="cat_opt_val_id" value="<?php echo $catAttData['option_value_id']; ?>" />
                    <tr id="<?php echo $rowStyle; ?>">
                        <td id="optId<?php echo $i+1; ?>">
                            <?php echo $i+1; ?>
                        </td>
                        <?php if(isset($_GET['action']) && $_GET['action'] == "edit_attribute" && $catAttData['category_attributes_id'] == $_POST['cat_attr_id']) {
                                   
                        ?>
                        
                        <td style="text-align: left !important;">
                            <div style="padding-left: 10px;">
                                <select id="catsearch" name="cat"><?php echo $PPT->CategoryListWithoutCnt($_POST['cat_id']); ?></select>
                            </div>
                        </td>
                        
                        <td style="text-align: left !important;">
                            <div style="padding-left: 10px;">
                                <?php
                                        $tmpArr = list_opt_name();
                                ?>
                                <select name="option_name" style="width: 170px;">
                                  <?php foreach($tmpArr as $key=>$value) {
                                            if($value[0] == $_POST['cat_opt_id']) {
                                                $selected = "selected='selected'";
                                            } else {
                                                $selected = "";
                                            }
                                    ?>
                                    <option value="<?php echo $value[0]; ?>" <?php echo $selected; ?>>
                                        <?php echo $value[1]; ?>
                                    </option>
                                  <?php } ?>
                                </select>
                            </div>
                        </td>
                        
                        <td id="optName<?php echo $i+1; ?>">
                            <?php
                                    $tmpArr2 = list_opt_value_name();
                            ?>
                            <select name="option_name_value" style="width: 170px;">
                            <?php foreach($tmpArr2 as $ke=>$val) {
                                    if($val[0] == $_POST['cat_opt_val_id']) {
                                        $selected = "selected='selected'";
                                    } else {
                                        $selected = "";
                                    }
                            ?>
                                <option value="<?php echo $val[0]; ?>" <?php echo $selected; ?>>
                                    <?php echo $val[1]; ?>
                                </option>
                              <?php } ?>
                            </select>
                        </div>
                        </td>
                        
                        <?php  } else { ?>
                        <td id="optName<?php echo $i+1; ?>">
                            <?php echo $catAttData['name']; ?>
                        </td>
                        <td id="optName<?php echo $i+1; ?>">
                            <?php echo $catAttData['option_name']; ?>
                        </td>
                        <td id="optName<?php echo $i+1; ?>">
                            <?php echo $catAttData['option_value_name']; ?>
                        </td>
                        <?php       
                                }
                        ?>
                        <td>
                                <?php if(isset($_GET['action']) && $_GET['action'] == "edit_attribute" && $catAttData['category_attributes_id'] == $_POST['cat_attr_id']) { ?>
                                        <input type="button" id="update_attribute" name="update_attribute" onclick="btnActions(document.getElementById('frm_action<?php echo $i+1; ?>'), this.id, 'update');" value="Save" />
                                        <input onclick="btnActions(document.getElementById('frm_action<?php echo $i+1; ?>'), this.id, 'cancel');" type="submit" id="cancel_option" name="cancel_option" value="Cancel" />
                                <?php   } else { ?>
                                
                                        <input type="button" id="edit_attribute" name="edit_attribute" onclick="btnActions(document.getElementById('frm_action<?php echo $i+1; ?>'), this.id);" value="Edit" />
                                        
                                        <input onclick="btnActions(document.getElementById('frm_action<?php echo $i+1; ?>'), this.id, 'delete');" type="button" id="delete_attribute" name="delete_attribute" value="Delete" />
                                <?php   
                                      }
                                ?>
                        </td>
                    </tr>
                    </form>
                <?php
                        $i++;
                        }
                    } else {
                ?>
                <tr id="<?php echo $rowStyle; ?>">
                    <td colspan="5" style="text-align: center; padding: 10px 0px; font-size: 16px;">
                        No Record Found
                    </td>
                </tr>
                <?php
                    }
                ?>
                <form action="admin.php?page=manage_cat_attr_admin&action=add_attrubute" method="POST" name="cat_attr_frm" id="cat_attr_frm">
                <tr id="<?php echo $rowStyle; ?>">
                    <td style="border-top:1px solid #000;">
                        <?php echo $i+1; ?>
                    </td>
                    <td style="padding-top:5px; text-align: left !important; border-top:1px solid #000; vertical-align: top;" valign="top">
                        <div style="padding-left:10px;">
                            <select id="catsearch" name="cat"><?php echo $PPT->CategoryListWithoutCnt(); ?></select>
                        </div>
                    </td>
                    <td style="text-align: left !important; border-top:1px solid #000;">
                        <div style="padding-left: 10px;">
                            <?php
                                    $tmpArr = list_opt_name();
                            ?>
                            <select name="option_name" style="width: 170px;">
                              <?php foreach($tmpArr as $key=>$value) { ?>
                                <option value="<?php echo $value[0]; ?>">
                                    <?php echo $value[1]; ?>
                                </option>
                              <?php } ?>
                            </select>
                        </div>
                    </td>
                    <td style="text-align: left !important; border-top:1px solid #000;">
                        <div style="padding-left: 10px;">
                            <?php
                                    $tmpArr1 = list_opt_value_name();
                            ?>
                            <select name="option_name_value" style="width: 170px;">
                              <?php foreach($tmpArr1 as $k=>$v) { ?>
                                <option value="<?php echo $v[0]; ?>">
                                    <?php echo $v[1]; ?>
                                </option>
                              <?php } ?>
                            </select>
                        </div>
                    </td>
                    <td style="padding-top:1px; border-top:1px solid #000; text-align: center;">
                            <input type="submit" name="submit_option" value="Insert" />
                    </td>
                </tr>
                </form>
            </table>
        </div>
    </div>
</div>