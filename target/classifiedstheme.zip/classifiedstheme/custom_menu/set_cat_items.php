<?php
	global $PPT;
	if(isset($_GET['action']) && $_GET['action'] == "delete") {
	    $sql = "delete from wp_category_item_fields where id='".$_GET['row_id']."'";
	    $delete_query = @mysql_query($sql) or die(mysql_error());
	    header("location:admin.php?page=set_cat_items.php&id=".$_GET['c_id']."");
	    exit;
	}
	if(isset($_POST) && $_POST['field_name'] != "") {
	    if($_POST['required'] == 'on') 
		$field_require = 'Yes';
	    else
		$field_require = 'No';
	    $sql = "insert into wp_category_item_fields (category_id, field_name, field_value_type, field_value, required) values(
	    '".$_POST['cat_id']."', '".$_POST['field_name']."', '".$_POST['field_type']."'";
	    if($_POST['field_type'] == "drop-down") {
		$sql .= ", '".serialize($_POST['drop_down_value'])."'";
	    } else if($_POST['field_type'] == "text-area") {
		$sql .= ", 'text-area'";
	    } else {
		$sql .= ", 'text-box'";
	    }
	    $sql .= " ,'".$field_require."')";
	    $insetCatFields = @mysql_query($sql ) or die(mysql_error());
	    header("location:admin.php?page=set_cat_items.php&id=".$_POST['cat_id']."");
	    exit;
	}
?>
<link rel="stylesheet" type="text/css" href="<?php echo get_bloginfo('template_url'); ?>/custom_menu/cus_stylesheet.css" />
<script type="text/javascript">
	function change_type(id) {
	    var catId = jQuery('#'+id).val();
	    jQuery.post("<?php echo get_bloginfo('template_url'); ?>/custom_menu/ajax.php", { field_type: catId },
	    function( rData ) {
		    if(!rData == "") {
			jQuery("#dropDownValueDiv").show();
			document.getElementById("dropDownValueDiv").innerHTML = rData;
		    } else {
			jQuery("#dropDownValueDiv").hide();
		    }
	    });
	}
	function addElement(fieldType, fieldName, className, ctrl1, ctrl2) {
		var ni = document.getElementById(ctrl1);
		var numi = document.getElementById(ctrl2);
		var num = (document.getElementById(ctrl2).value -1)+ 2;
		numi.value = num;
		var divIdName = ctrl1+num;
		var newdiv = document.createElement('div');
		newdiv.setAttribute("id",divIdName);
		newdiv.setAttribute('style','padding:5px 0px;');
		if (fieldType == 'text') {
			newdiv.innerHTML = "<input type=\""+ fieldType +"\" size=\"28\" name=\""+ fieldName +"[]\" value=\"\" class= \""+ className +"\" /> [<b><a href=\"javascript:;\" onclick=\"removeElement(\'"+divIdName+"\', \'"+ctrl1+"\')\">x</a></b>]"; 
		ni.appendChild(newdiv);
		}
	}
	function removeElement(divNum, ctrl1) {
		var d = document.getElementById(ctrl1);
		var olddiv = document.getElementById(divNum);
		d.removeChild(olddiv);
	}
	function ckFrmData(){
	    if(jQuery("#field_name").val() == "") {
		alert("Please enter field name");
		return false;
	    }
	    return true;
	}
</script>
<div style="padding: 20px 0px 0px 20px; width:95%;">
    <div style="font-size:20px; font-weight:bold;">
        Set Category Fields
    </div>
</div>
<div style="width:75%; margin: 0 auto;">
    <div style="padding:20px 0px 0px 0px;">
        <div id="main_table">
            <table cellpadding="0" cellspacing="1" border="0" width="100%">
                <tr>
                    <th class="row_heading" style="width:5%;">ID</td>
                    <th class="row_heading" style="width:35%;">Category Name</td>
                    <th class="row_heading" style="width:10%;">Sub Categories</td>
                    <th class="row_heading" style="width:10%;">Add Details</td>
                </tr>
                <?php
                    $i = 0;
                    $catItemQuery = @mysql_query("select cif.id, cif.field_name, cif.field_value_type, cif.field_value from wp_category_item_fields as cif where category_id='".$_GET['id']."'") or die(mysql_error());
                    if(mysql_num_rows($catItemQuery) > 0) {
                        while($catItemData = mysql_fetch_assoc($catItemQuery)) {
                            if($i%2 == 0)
                                $rowStyle = "data_odd";
                            else
                                $rowStyle = "data_even";
                ?>
                    <tr id="<?php echo $rowStyle; ?>">
                        <td id="optId<?php echo $i+1; ?>">
                            <?php echo $i+1; ?>
                        </td>
                        <td id="cat_name_<?php echo $i+1; ?>">
                            <?php echo $catItemData['field_name']; ?>
                        </td>
                        <td id="optName<?php echo $i+1; ?>">
                            
                                <?php echo $catItemData['field_value_type']; ?>
                            
                        </td>
                        <td id="addDetails<?php echo $i+1; ?>">
                                <a href="admin.php?page=set_cat_items.php&action=delete&row_id=<?php echo $catItemData['id']; ?>&c_id=<?php echo $_GET['id']; ?>">Delete</a>
                        </td>
                    </tr>
                <?php
                        $i++;
                        }
                    } else {
                ?>
                <tr id="<?php echo $rowStyle; ?>">
                    <td colspan="5" style="text-align: center; padding: 10px 0px; font-size: 16px;">
                        No Record Found
                    </td>
                </tr>
                <?php
                    }
                ?>
            </table>
        </div>
    </div>
</div>
<div style="padding: 50px 0px 0px 20px; width:95%;">
    <div style="font-size:20px; font-weight:bold;">
        Add Category Fields
    </div>
</div>
<div style="width:75%; margin: 0 auto; ">
    <div style="padding:20px 0px 0px 0px;">
	<form method="POST" name="fieldOptVal" action="admin.php?page=set_cat_items.php" onSubmit="return ckFrmData()">
	    <input type="hidden" name="cat_id" value="<?php echo $_GET['id']; ?>" />
	    <!--<input type="text" name="cat_ids[]" value="1" />
	    <input type="text" name="cat_ids[]" value="2" />-->
	    <div style="width: 100%; padding:20px 0px 0px 0px;  float: left;">
		<div style="width:900px; float:left;">
		    <div style="width:148px; float:left; font-size:16px; text-align: right; padding-top:3px;">
			Enter Field Name :
		    </div>
		    <div style="width:300px; float:left; padding-left:10px;">
			<input type="text" size="28" name="field_name" id="field_name" />
		    </div>
		    <div style="width:250px; float:left; padding-left:10px;">
			<label style="font-size:16px;">Type : </label>
			<select id="field_type" name="field_type" style="width: 140px;" onchange="change_type(this.id);">
			    <option value="input">Input</option>
			    <option value="drop-down">Drop Down</option>
			    <option value="text-area">Text Area</option>
			</select>
		    </div>
		    <div style="width:120px; padding-top: 5px; float:left; padding-left:10px;">
			<label style="font-size:16px;">Required : </label>
			<input type="checkbox" name="required" name="required" checked="checked" style="vertical-align: bottom;" />
		    </div>
		</div>
		<div style="width:900px; clear:both; padding-left:10px;" id="dropDownValueDiv"></div>
		<div style="width:88%; clear:both; padding:25px 0px 0px 0px; text-align: right;">
		    <input type="submit" value="Submit" name="submit Button" />
		</div>
	    </div>
	</form>
    </div>
</div>

    
