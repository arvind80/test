<link rel="stylesheet" type="text/css" href="<?php echo get_bloginfo('template_url'); ?>/custom_menu/cus_stylesheet.css" />
<?php global $PPT; ?>

<?php
        
    function checkSubCategories($id){
        $myrows = @mysql_query( "select t.term_id from wp_terms as t LEFT JOIN wp_term_taxonomy as tt ON t.term_id = tt.term_id where tt.taxonomy = 'category' && tt.parent = '$id'") or die(mysql_error());
        if(mysql_num_rows($myrows) > 0) {
            return true;
        } else {
            return false;
        }
    }
?>
<script type="text/javascript">
    
</script>
<?php //print_r($PPT); echo "<pre>"; print_r(get_included_files()); echo "</pre>"; ?>
<div style="padding: 20px 0px 0px 20px; width:95%;">
    <div style="font-size:20px; font-weight:bold;">
        Category Items Management
    </div>
</div>
<div style="width:75%; margin: 0 auto;">
    <div style="padding:20px 0px 0px 0px;">
        <div id="main_table">
            <table cellpadding="0" cellspacing="1" border="0" width="100%">
                <tr>
                    <th class="row_heading" style="width:5%;">ID</td>
                    <th class="row_heading" style="width:35%;">Category Name</td>
                    <th class="row_heading" style="width:10%;">Sub Categories</td>
                    <th class="row_heading" style="width:10%;">Add Details</td>
                </tr>
                <?php
                    $i = 0;
                    $subCatQuery = @mysql_query("select t.term_id, t.name from wp_terms as t INNER JOIN wp_term_taxonomy as tt ON t.term_id = tt.term_id and tt.taxonomy = 'category' and tt.parent = '".$_GET['id']."'") or die(mysql_error());
                    if(mysql_num_rows($subCatQuery) > 0) {
                        while($subCatData = mysql_fetch_assoc($subCatQuery)) {
                            if($i%2 == 0)
                                $rowStyle = "data_odd";
                            else
                                $rowStyle = "data_even";
                ?>
                    <form name="frm_action<?php echo $i+1; ?>" id="frm_action<?php echo $i+1; ?>" action="" method="POST">
                    <tr id="<?php echo $rowStyle; ?>">
                        <td id="optId<?php echo $i+1; ?>">
                            <?php echo $i+1; ?>
                        </td>
                        
                        <td id="cat_name_<?php echo $i+1; ?>">
                            <?php echo $subCatData['name']; ?>
                        </td>
                        <td id="optName<?php echo $i+1; ?>">
                            <?php
                                if(checkSubCategories($subCatData['term_id'])) {
                            ?>
                                <a href="admin.php?page=sub_cats.php&id=<?php echo $subCatData['term_id']; ?>">Sub Cats</a>
                            <?php } else { ?>
                                    X
                            <?php } ?>
                        </td>
                        <td id="addDetails<?php echo $i+1; ?>">
                                <?php
                                        if(checkSubCategories($subCatData['term_id'])) {
                                ?>
                                        X
                                <?php
                                        } else {
                                ?>
                                    <a href="admin.php?page=set_cat_items.php&id=<?php echo $subCatData['term_id']; ?>">
                                        Set Fields
                                    </a>
                                <?php       
                                        }
                                ?>
                        </td>
                    </tr>
                    </form>
                <?php
                        $i++;
                        }
                    } else {
                ?>
                <tr id="<?php echo $rowStyle; ?>">
                    <td colspan="5" style="text-align: center; padding: 10px 0px; font-size: 16px;">
                        No Record Found
                    </td>
                </tr>
                <?php
                    }
                ?>
            </table>
        </div>
    </div>
</div>