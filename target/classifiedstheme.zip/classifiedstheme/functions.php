<?php
ob_start();

 	//date_default_timezone_set('America/Los_Angeles');
 
	define("PREMIUMPRESS_SYSTEM","ClassifiedsTheme");
	define("PREMIUMPRESS_VERSION","6.1.4");
	define("PREMIUMPRESS_VERSION_DATE","29th April, 2011");

	if(defined('TEMPLATEPATH')){ include("PPT/_config.php"); }
        function right_sidebar_custom() {
            $string = "<div class=\"rightSidebar left\" id=\"sidebar\" style=\"margin-left:0px !important; \">
                    <div class=\"sb-tp-heading\" style=\"padding-bottom:1px;\">Refine your Search</div>
                   <form method=\"POST\" action=".$GLOBALS['bloginfo_url']."/?page_id=104"." name=\"locationSearch\" id=\"locationSearch\">
                <div class=\"itembox\" style=\"width:196px !important;\">
                        <h2>Your Location</h2>
                        <div class=\"itemboxinner widget\" style=\"padding:15px 0px 25px 0px !important; background-color: #F1F2F1;  width:196px !important;\">
                        <div style=\"padding:10px 7px; width: 91%;\">
                            <div>
                                <input type=\"text\" name=\"location_search\" id=\"location_search\" style=\"width:170px; color: #000; border: 2px solid #F0F0F0;\" /><br/><label style=\"color: #000; font-size:11px;\">Postal Code</label>
                                <span id=\"invalid-location_search\"></span>
                            </div>
                            <div style=\"padding-top:10px; width:100%; float:left;\">
                                <div style=\"padding-top:15px; width:35px; float:left;\">Within</div>
                                <div style=\"float:left; width:60px; padding: 0 10px;\">
                                <select name=\"km_rang\" id=\"km_range\" style=\"width:60px;\">
                                    <option value=\"25\">25</option>
                                    <option value=\"50\">50</option>
                                    <option value=\"100\">100</option>
                                </select>
                                </div>
                                <div style=\"padding-top:15px; float:left;\">Miles</div>
                            </div>
                        </div>
                        <div style=\"padding:10px 10px 0px 10px; width: 90%; clear:both; text-align: right;\">
                            <input type=\"submit\" name=\"location_range_search\" id=\"location_range_search\" value=\"Search\" />
                        </div>		
                    </div>
                </div>
                </form>
                <form method=\"POST\"  action=".$GLOBALS['bloginfo_url']."/?page_id=102"." name=\"customeKeySearch\" id=\"customeKeySearch\">
                <div class=\"itembox\" style=\"width:196px !important;\">
                    <h2>Keyword</h2>
                    <div class=\"itemboxinner widget\" style=\"padding:15px 0px 25px 0px !important;background-color: #F1F2F1; width:196px !important;\">
                        <div style=\"padding:10px 7px; width: 91%; float: left;\">
                            <div>
                                <input type=\"text\" onblur=\"if(this.value == '') { this.value = 'Ex. Red, Leather, GPS'}\" onfocus=\"if(this.value == 'Ex. Red, Leather, GPS') { this.value = ''}\" name=\"custom_search\" id=\"custom_search\" value=\"Ex. Red, Leather, GPS\" style=\"width:170px; color: #000; border: 2px solid #F0F0F0;\" />
                                <span id=\"invalid-custom_search\"></span>
                            </div>
                        </div>
                        <div style=\"padding:0px 10px; width: 90%; text-align: right;\">
                            <input type=\"submit\" name=\"custome_keyword_search\" id=\"custome_keyword_search\" value=\"Search\" />
                        </div>		
                    </div>
                </div>
                </form>
                <form method=\"POST\"  action=".$GLOBALS['bloginfo_url']."/?page_id=99"." name=\"priceSearch\" id=\"priceSearch\">
                <div class=\"itembox\" style=\"width:196px !important;\">
                    <h2>Price</h2>
                    <div class=\"itemboxinner widget\" style=\"padding:15px 0px 25px 0px !important;background-color: #F1F2F1; width:196px !important;\">
                        <div style=\"padding:10px 10px;float: left;\">
                            <div style=\"float:left;\">
                                <div style=\"float:left\">
                                <input type=\"text\" onblur=\"if(this.value == '') { this.value = 'Min. Price'}\" onfocus=\"if(this.value == 'Min. Price') { this.value = ''}\"  id=\"min_price\" name=\"min_price\" value=\"Min. Price\" style=\"width:60px; font-size: 12px; height: 17px; color: #000; border: 2px solid #F0F0F0;\" />
                                </div>
                                <div style=\"float:left; padding:12px 5px 0px 5px;\">
                                <label style=\"font-size: 14px;\">to</label>
                                </div>
                                <div style=\"float:left\">
                                <input onblur=\"if(this.value == '') { this.value = 'Max. Price'}\" onfocus=\"if(this.value == 'Max. Price') { this.value = ''}\" type=\"text\" id=\"max_price\" name=\"max_price\" value=\"Max. Price\" style=\"width:60px; height: 17px; font-size: 12px; color: #000; border: 2px solid #F0F0F0;\" />
                                </div>
                                <span id=\"invalid-min_price\"></span>
                                <span id=\"invalid-max_price\"></span>
                            </div>
                        </div>
                        <div style=\"padding:0px 10px; width: 90%; text-align: right;\">
                            <input type=\"submit\" name=\"searchPrice\" value=\"Search\" />
                        </div>
                        
                    </div>
                </div>
                </form>
            </div>";
            return $string;
                
        }
        function custom_temp_footer() {
            $footerStr = '<div id="footer" class="clearfix full">
                            <div class="w_960" style="margin:0 auto;">
                            <div class="b_third_col col first_col" style="padding-left:15px;"> 
                                <p>Buying or selling anything? Find the best deals on new and used autos, electronics, real-estate and much more.</p>
                                <h2>Search by City</h2>
                                <div class="links">
                                        <ul>';
                                    //$tbl_country = $wpdb->prefix.country;
                                    //$allCountryQuery = "select Name from ".$tbl_country." limit 0,25";
                                    //$country_list = $wpdb->get_results($allCountryQuery, OBJECT);
                                    ////echo "<pre>"; print_r($country_list); echo "</pre>";
                                    //$i = 0;
                                    //
                                    //foreach($country_list as $key=>$value) { http://localhost/wordpress/?page_id=99
                            $footerStr .='<li><a href="http://localhost/wordpress/?page_id=180&act=ser&data=Ontario">Ontario:</a></li>
                                            <li><a href="http://localhost/wordpress/?page_id=180&act=ser&data=Barrie">Barrie</a> </li>
                                            <li><a href="http://localhost/wordpress/?page_id=180&act=ser&data=Brantford">Brantford</a> </li>
                                            <li><a href="http://localhost/wordpress/?page_id=180&act=ser&data=Guelph">Guelph</a> </li>
                                            <li><a href="http://localhost/wordpress/?page_id=180&act=ser&data=Hamilton">Hamilton</a> </li>
                                            <li><a href="http://localhost/wordpress/?page_id=180&act=ser&data=Kingston">Kingston</a> </li>
                                            <li><a href="http://localhost/wordpress/?page_id=180&act=ser&data=Kitchener/Waterloo">Kitchener/Waterloo</a> </li>
                                            <li><a href="http://localhost/wordpress/?page_id=180&act=ser&data=Oshawa">Oshawa</a> </li>
                                            <li><a href="http://localhost/wordpress/?page_id=180&act=ser&data=Ottawa-Gatineau">Ottawa-Gatineau</a> </li>
                                            <li><a href="http://localhost/wordpress/?page_id=180&act=ser&data=St. Catharines-Niagara">St. Catharines-Niagara</a> </li>
                                            <li><a href="http://localhost/wordpress/?page_id=180&act=ser&data=Sudbury">Sudbury</a> </li>
                                            <li><a href="http://localhost/wordpress/?page_id=180&act=ser&data=Toronto-GTA">Toronto-GTA</a> </li>
                                            <li><a href="http://localhost/wordpress/?page_id=180&act=ser&data=Thunder Bay">Thunder Bay</a> </li>
                                            <li><a href="http://localhost/wordpress/?page_id=180&act=ser&data=Windsor">Windsor</a> </li>
                                            <li>
                                                <a href="http://localhost/wordpress/?page_id=180&act=ser&data=British Columbia" style="padding-right:10px;">British Columbia:</a><a href="http://localhost/wordpress/?page_id=180&act=ser&data=Abbotsford">Abbotsford</a>
                                            </li>
                                            
                                            <li><a href="http://localhost/wordpress/?page_id=180&act=ser&data=Kelowna">Kelowna</a> </li>
                                            <li><a href="http://localhost/wordpress/?page_id=180&act=ser&data=Vancouver">Vancouver</a> </li>
                                            <li><a href="http://localhost/wordpress/?page_id=180&act=ser&data=Victoria">Victoria</a> </li>
                                            <li><a href="http://localhost/wordpress/?page_id=180&act=ser&data=Nanaimo">Nanaimo</a> </li>
                                            <li><a href="http://localhost/wordpress/?page_id=180&act=ser&data=Courtenay">Courtenay</a> </li>
                                            <li>
                                                <a href="http://localhost/wordpress/?page_id=180&act=ser&data=Alberta" style="padding-right:10px;">Alberta:</a><a href="http://localhost/wordpress/?page_id=180&act=ser&data=Calgary">Calgary</a>
                                            </li>
                                            <li><a href="http://localhost/wordpress/?page_id=180&act=ser&data=Edmonton">Edmonton</a> </li>
                                            <li><a href="http://localhost/wordpress/?page_id=180&act=ser&data=Lethbridge">Lethbridge</a> </li>
                                            <li><a href="http://localhost/wordpress/?page_id=180&act=ser&data=Red Deer">Red Deer</a> </li>
                                            <li>
                                                <a href="http://localhost/wordpress/?page_id=180&act=ser&data=Saskatchewan" style="padding-right:10px;">Saskatchewan:</a><a href="http://localhost/wordpress/?page_id=180&act=ser&data=Regina">Regina</a>
                                            </li>
                                            <li><a href="http://localhost/wordpress/?page_id=180&act=ser&data=Saskatoon">Saskatoon</a> </li>
                                            <li>
                                                <a href="http://localhost/wordpress/?page_id=180&act=ser&data=Manitoba" style="padding-right:10px;">Manitoba:</a><a href="http://localhost/wordpress/?page_id=180&act=ser&data=Winnipeg">Winnipeg</a>
                                            </li>
                                            <li><a href="http://localhost/wordpress/?page_id=180&act=ser&data=Brandon">Brandon</a> </li>';
			
			    //$i++;
			    //}
			
                        $footerStr .='  </ul>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                            <div class="full" id="copyright">
                               <p style="padding:0px 0px 15px 15px !important;">&copy; 2012 Postme.ca.All rights reserved.</p>
                            </div>
                        </div>
                </div> ';
                //end WRAPPER 
                        return $footerStr;
        }

function configure_menu() {
    add_menu_page("Category Attributes", "Category Attributes", 1, "manage_cat_attr_admin", "include_core");
}

function include_core() {
    include('custom_menu/cat_attributes.php');
}

function cat_options_actions() {
    
    add_submenu_page("manage_cat_attr_admin", "Options", "Options", 1, "cat_options.php","cat_options");
    
}

function cat_options(){
    include('custom_menu/cat_options.php');
}

function categories_items() {
    add_submenu_page("manage_cat_attr_admin", "Cat Items Fields", "Cat Item Fields", 1, "categories_items.php","categories_item");
}

function categories_item() {
    include('custom_menu/categories_items.php');
}

function subcategory() {
    add_submenu_page("manage_cat_attr_admin", "subcategory", "subcategory", 1, "sub_cats.php","sub_cat");
}

function sub_cat() {
    include('custom_menu/sub_cats.php');
}

function set_list_items() {
    add_submenu_page("manage_cat_attr_admin", "list Itms", "list Itms", 1, "set_cat_items.php","listItms");
}
function listItms() {
    include('custom_menu/set_cat_items.php');
}

add_action('admin_menu', 'configure_menu');

add_action('admin_menu', 'cat_options_actions');

add_action('admin_menu', 'categories_items');

add_action('admin_menu', 'subcategory');

add_action('admin_menu', 'set_list_items');

?>