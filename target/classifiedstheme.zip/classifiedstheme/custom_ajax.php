<?php
    include('../../../wp-config.php');
// Check Sub Category 
    if(isset($_POST['action']) && $_POST['action'] == 'check_sub_categories') {
        if($_POST['categoryId'] == '804840000000000000') {
            echo false;
        } else {
            $ckSubCatQuery = @mysql_query("select t.term_id from wp_terms as t INNER JOIN wp_term_taxonomy as tt ON t.term_id = tt.term_id where tt.taxonomy = 'category' && tt.parent = '".$_POST['categoryId']."'") or die(mysql_error());
            if(mysql_num_rows($ckSubCatQuery) > 0) {
                echo true;
            } else {
                echo false;
            }
        }
// Return true/false value of Sub Category 
    } else if(isset($_POST['action']) && $_POST['action'] == 'return_sub_categories'){
            $ckSubCatQuery = @mysql_query("select tt.parent, t.term_id from wp_terms as t INNER JOIN wp_term_taxonomy as tt ON t.term_id = tt.term_id where tt.taxonomy = 'category' && t.term_id = '".$_POST['categoryId']."'") or die(mysql_error());
            if(mysql_num_rows($ckSubCatQuery) > 0) {
                $data = mysql_fetch_assoc($ckSubCatQuery);
                echo $data['parent'];
            }
// Get Sub Category
    } else if(isset($_POST['action']) && $_POST['action'] == 'get_sub_category'){
            $getSubCatQuery = @mysql_query("select t.term_id, t.name from wp_terms as t INNER JOIN wp_term_taxonomy as tt ON t.term_id = tt.term_id where tt.taxonomy = 'category' && tt.parent = '".$_POST['categoryId']."'") or die(mysql_error());
            if(mysql_num_rows($getSubCatQuery) > 0) {
                $str =  '<div class="option">
				<div class="title">&nbsp;</div>
                                <select class="required_field" id="sub_cat_name" name="sub_cat_name" onchange="checkSubCat(this.id);">
			    <option value="none">Select Category</option>';
                            while($subCatData = mysql_fetch_assoc($getSubCatQuery)) {
                                $str .=  '<option value="'.$subCatData['term_id'].'">'.$subCatData['name'].'</option>';
                            }
                $str .=  '</select></div>';
                echo $str;
            }
// Get List Items
    } else {
        $catOptQuery = @mysql_query("select  DISTINCT co.option_id, ca.category_id, co.option_name  from wp_category_attributes as ca INNER JOIN wp_category_options as co ON co.option_id = ca.option_id where ca.category_id = '".$_POST['categoryId']."'") or die(mysql_error());
        if(mysql_num_rows($catOptQuery) > 0) {
            $i = 0;
            $data = "";
            while($cat_opt_data = mysql_fetch_assoc($catOptQuery)) {
                //echo "<pre>";
                //    print_r($cat_opt_data);
                //echo "</pre>";
                $data.='<div class="option">
                            <div class="title">'.$cat_opt_data['option_name'].'</div>
                            <select size="1" name="fieldOpt-'.strtolower(str_replace(' ','_',$cat_opt_data['option_name'])).'">';
                        $op_val_query = mysql_query("select cov.option_value_id, cov.option_value_name from wp_category_options_values as cov LEFT JOIN wp_category_attributes as ca ON ca.option_value_id = cov.option_value_id where ca.option_id = '".$cat_opt_data['option_id']."' and ca.category_id = '".$cat_opt_data['category_id']."'") or die(mysql_error());
                        
                        
                        while($tempDD = mysql_fetch_assoc($op_val_query)) {
                            $data.='<option value="'.strtolower(str_replace(' ','_',$tempDD['option_value_name'])).'">'.$tempDD['option_value_name'].'</option>';
                        }
                    $data.='</select>
                     </div>';
            }
            $data.='[exp_data]';
            
            $catItemQuery = @mysql_query("select field_name, field_value_type, field_value, required from wp_category_item_fields where category_id='".$_POST['categoryId']."' order by id ASC") or die(mysql_error());
        if(mysql_num_rows($catItemQuery) > 0) {
            $data .= '<div class="item_details">
                        <h2>Enter Your Item Details</h2>';
            while($row = mysql_fetch_array($catItemQuery)) {
                if($row['required'] == 'Yes') {
                    $reqCls = "class='required_field'";
                    $astSign = "<label style='color:#FF0000; font-size:10px;'>*</label>";
                }
                else {
                    $reqCls = "";
                    $astSign = "";
                }
                if($row['field_value_type'] == "text-area"){
                    $data .= '<div class="option" style="width:100%  !important;">';
                        $data .= '<div class="title" style="padding-top:0px !important;">'.$row['field_name'].' '.$astSign.'</div>';
                } else {
                    $data .= '<div class="option">';
                        $data .= '<div class="title">'.$row['field_name'].' '.$astSign.'</div>';
                }   
                            if($row['field_value_type'] == "drop-down") {
                                $data .='<select '.$reqCls.' id="'.strtolower(str_replace(' ','_',$row['field_name'])).'" name="'.strtolower(str_replace(' ','_',$row['field_name'])).'" style="color:#000000;height: 30px;width: 172px;">';
                                           $dropDownArr = unserialize($row['field_value']);
                                           for($i=0; $i < count($dropDownArr); $i++) {
                                                $data .='<option value="'.strtolower(str_replace(' ','_',$dropDownArr[$i])).'" >'.$dropDownArr[$i].'</option>';
                                           }
                                $data .='</select>';
                            } else if($row['field_value_type'] == "text-area"){
                                
                                $data .= '<textarea '.$reqCls.' id="'.strtolower(str_replace(' ','_',$row['field_name'])).'" name="'.strtolower(str_replace(' ','_',$row['field_name'])).'" rows="10" cols="62" style="border: 1px solid #ECEDED;"></textarea>';
                            } else {
                                $data .='<input '.$reqCls.' type="text" id="'.strtolower(str_replace(' ','_',$row['field_name'])).'" name="'.strtolower(str_replace(' ','_',$row['field_name'])).'" />';
                            }
                        
                $data .='</div>';
            } 
                $data .= '</div>';
        } else {
                $data .='<div class="item_details" style="text-align: center;">
                                    There is no item found in this category.
                        </div>';
        }
            echo $data;
        }
    }
?>